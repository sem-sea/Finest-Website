<?php
/**
 * "1-zip" auto-provisioning: activating this theme builds the full site
 * (pages, permalinks, taxonomy terms) with no manual setup.
 *
 * Every lesson from the case-study table in the WordPress Build Blueprint is
 * applied here on purpose:
 *  - ensure_page() uses get_posts(['post_parent'=>...]), never
 *    get_page_by_path(), so it finds child pages on a second run instead of
 *    creating "-2" duplicates.
 *  - The "done" flag is set from both the activation hook and the
 *    admin_init safety net, so a plugin activated after the theme doesn't
 *    leave provisioning permanently un-flagged.
 *  - permalink_structure is set (and rewrite rules flushed) on activation,
 *    or every internal link silently falls back to the homepage.
 *  - Custom taxonomy registration happens on init, and all provisioning
 *    that touches it runs on/after admin_init (after_switch_theme fires
 *    post-init in a real switch_theme() request); never on plugins_loaded.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the "Nieuws" category taxonomy used by native posts (The Finest
 * News uses core `post`, not a custom post type, so it gets archives/RSS/
 * categories for free; see functions.php comment).
 */
function finest_register_taxonomies() {
	register_taxonomy(
		'nieuws_categorie',
		'post',
		array(
			'labels' => array(
				'name'          => __( 'Nieuws categorieën', 'finest-impact' ),
				'singular_name' => __( 'Nieuws categorie', 'finest-impact' ),
			),
			'hierarchical'      => true,
			'public'            => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'nieuws-categorie' ),
		)
	);
}
add_action( 'init', 'finest_register_taxonomies' );

/**
 * Klantverhalen (client stories) as their own post type, separate from
 * Nieuws so the two "vogue.nl-style" sections (Fase 1 briefing) don't mix
 * in one archive/category list.
 */
function finest_register_post_types() {
	register_post_type( 'klantverhaal', array(
		'labels' => array(
			'name'          => __( 'Klantverhalen', 'finest-impact' ),
			'singular_name' => __( 'Klantverhaal', 'finest-impact' ),
			'add_new_item'  => __( 'Nieuw klantverhaal toevoegen', 'finest-impact' ),
		),
		'public'       => true,
		// No native archive: the /klantverhalen/ page below (with its own
		// embedded wp:query block) IS the landing page for this post type.
		// A has_archive route at the same slug would silently win over that
		// page's rewrite rule and serve WP's bare archive template instead
		// of the real, editable page content (caught in clean-room testing:
		// the page provisioned fine, but /klantverhalen/ rendered "Archives:
		// Klantverhalen" from archive.html, not finest_klantverhalen_intro_content()).
		'has_archive'  => false,
		'rewrite'      => array( 'slug' => 'klantverhalen' ),
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-format-quote',
		'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'template'     => array(
			array( 'core/paragraph', array( 'placeholder' => 'Korte samenvatting van het klantverhaal…' ) ),
		),
	) );
}
add_action( 'init', 'finest_register_post_types' );

/**
 * Create a page if (and only if) it doesn't already exist at this exact
 * parent; safe to call on every activation.
 *
 * @param string $slug
 * @param string $title
 * @param string $content   Full block markup for post_content.
 * @param int    $parent_id
 * @param string $template  Optional "Template Name" block template slug.
 * @return int Post ID.
 */
function finest_ensure_page( $slug, $title, $content = '', $parent_id = 0, $template = '' ) {
	$existing = get_posts( array(
		'name'           => $slug,
		'post_type'      => 'page',
		'post_status'    => 'any',
		'post_parent'    => $parent_id,
		'posts_per_page' => 1,
	) );

	if ( ! empty( $existing ) ) {
		return $existing[0]->ID;
	}

	$page_id = wp_insert_post( array(
		'post_title'   => $title,
		'post_name'    => $slug,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_parent'  => $parent_id,
		'post_content' => $content,
	) );

	if ( $template && ! is_wp_error( $page_id ) ) {
		update_post_meta( $page_id, '_wp_page_template', $template );
	}

	return is_wp_error( $page_id ) ? 0 : $page_id;
}

/**
 * Create a term if it doesn't already exist. Idempotent like ensure_page().
 */
function finest_ensure_term( $name, $taxonomy, $parent_id = 0 ) {
	$existing = get_term_by( 'name', $name, $taxonomy );
	if ( $existing ) {
		return $existing->term_id;
	}
	$result = wp_insert_term( $name, $taxonomy, array( 'parent' => $parent_id ) );
	return is_wp_error( $result ) ? 0 : $result['term_id'];
}

/**
 * Sideload a theme asset photo into the media library as a real attachment,
 * once, so it is a normal, editable/replaceable WordPress image (not a
 * hardcoded theme-relative path baked into post_content). Idempotent: looks
 * up by exact attachment title before copying anything.
 *
 * @param string $filename Filename under /assets/img/{$subdir}/.
 * @param string $title    Attachment title (also used as the lookup key and
 *                          the default alt text).
 * @param string $subdir   Subdirectory under /assets/img/. Defaults to
 *                          'photography' for the original hero/section
 *                          photos; team headshots live under 'team'.
 * @return int Attachment ID, or 0 if the source file is missing or the
 *             upload failed.
 */
function finest_ensure_photo( $filename, $title, $subdir = 'photography' ) {
	$existing = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'title'          => $title,
		'posts_per_page' => 1,
	) );
	if ( ! empty( $existing ) ) {
		return $existing[0]->ID;
	}

	$subdir      = sanitize_file_name( $subdir );
	$filename    = sanitize_file_name( $filename );
	$source_path = FINEST_THEME_DIR . '/assets/img/' . $subdir . '/' . $filename;
	if ( ! file_exists( $source_path ) ) {
		return 0;
	}

	$filetype = wp_check_filetype( $filename, null );
	$upload   = wp_upload_bits( $filename, null, file_get_contents( $source_path ) );
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}

	$attachment_id = wp_insert_attachment( array(
		'post_mime_type' => $filetype['type'],
		'post_title'     => $title,
		'post_status'    => 'inherit',
	), $upload['file'] );

	if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
		return 0;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	$metadata = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
	wp_update_attachment_metadata( $attachment_id, $metadata );
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', $title );

	return $attachment_id;
}

/**
 * The actual provisioning run: pages, terms, front-page setting.
 * Safe to call more than once: every step is idempotent.
 */
function finest_provision_content() {
	require_once FINEST_THEME_DIR . '/inc/content-pages.php';

	// Nieuws categories from the briefing.
	$nieuws_categorieen = array(
		'Brands & People',
		'Industrie news',
		'Retail & store concepts',
		'Trends & innovatie',
		'Events & fairs',
		'Marketing',
		'Internationaal news',
	);
	foreach ( $nieuws_categorieen as $cat ) {
		finest_ensure_term( $cat, 'nieuws_categorie' );
	}

	// Every one of these pages opens with its own manually-authored <h1> in
	// post_content (so the hero styling/fi-reveal-lines treatment can differ
	// per page), so every one of them needs the 'page-onepager' template —
	// the default 'page' template also renders wp:post-title, which without
	// this produces two <h1> tags on the same page (caught in clean-room
	// testing: algemene-voorwaarden and privacyverklaring were shipping with
	// a duplicate heading).
	$home_id = finest_ensure_page( 'home', 'Home', finest_home_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'over-ons', 'Over ons', finest_over_ons_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'diensten', 'Diensten', finest_diensten_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'contact', 'Contact', finest_contact_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'algemene-voorwaarden', 'Algemene Voorwaarden', finest_algemene_voorwaarden_content(), 0, 'page-onepager' );
	finest_ensure_page( 'privacyverklaring', 'Privacyverklaring', finest_privacyverklaring_content(), 0, 'page-onepager' );
	finest_ensure_page( 'klantverhalen', 'Klantverhalen', finest_klantverhalen_intro_content(), 0, 'page-onepager' );
	finest_ensure_page( 'nieuws', 'The Finest News', finest_nieuws_intro_content(), 0, 'page-onepager' );

	// Homepage is a real page (so it's editable like any other page), set
	// as the static front page rather than left as the latest-posts default.
	if ( $home_id ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}

	// Deliberately NOT setting page_for_posts to the nieuws page: WordPress
	// treats a "Posts page" specially and renders the blog index in its
	// place, discarding that page's own post_content entirely. The nieuws
	// page already embeds its own wp:query block (postType "post", same
	// posts, same category support), so it gets the listing it needs while
	// staying a normal, fully-editable page like every other one here
	// (caught in clean-room testing: with page_for_posts set, visiting
	// /nieuws/ silently skipped finest_nieuws_intro_content() entirely).

	finest_ensure_primary_menu();
}

/**
 * Build the primary nav menu from the provisioned pages, only if a menu
 * isn't already assigned (avoids clobbering manual edits on re-activation).
 */
function finest_ensure_primary_menu() {
	if ( has_nav_menu( 'primary' ) ) {
		return;
	}

	$menu_name = 'Hoofdmenu';
	$menu_id   = wp_get_nav_menu_object( $menu_name );
	if ( ! $menu_id ) {
		$menu_id = wp_create_nav_menu( $menu_name );
	} else {
		$menu_id = $menu_id->term_id;
	}

	$items = array(
		'diensten'     => 'Diensten',
		'over-ons'     => 'Over ons',
		'klantverhalen' => 'Klantverhalen',
		'nieuws'       => 'Nieuws',
		'contact'      => 'Contact',
	);

	// Fetched once, outside the loop: this used to re-query every menu item
	// on every iteration (an avoidable N+1), and the menu doesn't change
	// mid-loop — nothing below this point inserts an item before the next
	// iteration reads $existing_items again except via the fresh append
	// below, which is accounted for separately.
	$existing_items = wp_get_nav_menu_items( $menu_id );

	foreach ( $items as $slug => $label ) {
		$page = get_page_by_path( $slug );
		if ( ! $page ) {
			continue;
		}
		$already_there = false;
		if ( $existing_items ) {
			foreach ( $existing_items as $item ) {
				if ( (int) $item->object_id === $page->ID ) {
					$already_there = true;
					break;
				}
			}
		}
		if ( ! $already_there ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => $label,
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page->ID,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );
		}
	}

	set_theme_mod( 'nav_menu_locations', array_merge(
		(array) get_theme_mod( 'nav_menu_locations', array() ),
		array( 'primary' => $menu_id )
	) );
}

/**
 * finest_category_pills() (inc/content-pages.php) only renders at
 * provisioning time, baked into the 'nieuws' page's post_content — so a
 * nieuws_categorie term added, renamed, or deleted afterward in wp-admin
 * would otherwise never show up in the pills row without someone manually
 * re-opening and re-saving that page in the block editor.
 *
 * This re-generates just the <div class="finest-pills"> markup and splices
 * it back into the page's existing post_content via regex, rather than
 * overwriting the whole page — the editor's own copy/heading edits
 * elsewhere on that page must survive this, not get silently clobbered by
 * a taxonomy change. Three cases:
 *  - pills block already present, terms still exist -> replace just the
 *    <div class="finest-pills"> markup in place.
 *  - pills block already present, zero terms left -> remove the whole
 *    (now-empty) wp:html block.
 *  - no pills block yet (e.g. zero terms at provisioning time, first term
 *    added afterward) -> insert a freshly-built one right before the
 *    grid's own wp:query block, which is never optional and always
 *    present on this page, so it's a stable anchor to insert against.
 * If even that anchor is missing (post_content edited into an unexpected
 * shape), this does nothing rather than guess further.
 */
function finest_resync_nieuws_pills() {
	$page = get_page_by_path( 'nieuws' );
	if ( ! $page ) {
		return;
	}

	require_once FINEST_THEME_DIR . '/inc/content-pages.php';
	$content     = $page->post_content;
	$div_pattern = '/<div class="finest-pills">.*?<\/div>/s';
	$pills       = finest_category_pills( 'nieuws_categorie' );

	if ( $pills ) {
		if ( preg_match( $div_pattern, $content ) ) {
			if ( ! preg_match( $div_pattern, $pills, $fresh ) ) {
				return;
			}
			$new_content = preg_replace( $div_pattern, $fresh[0], $content, 1 );
		} else {
			// No pills block exists yet on this page -- insert one, built
			// the same way finest_nieuws_intro_content() builds it, right
			// before the grid's wp:query block.
			$wrap = finest_category_pills_wrap( 'nieuws_categorie' );
			if ( ! $wrap || false === strpos( $content, '<!-- wp:query ' ) ) {
				return;
			}
			$new_content = preg_replace(
				'/<!-- wp:query /',
				$wrap . "\n\n" . '<!-- wp:query ',
				$content,
				1
			);
		}
	} else {
		// No terms left at all: remove the now-empty pills block (including
		// its wp:html block comments) if it's still there.
		$block_pattern = '/<!-- wp:html -->\s*<div class="finest-pills">.*?<\/div>\s*<!-- \/wp:html -->/s';
		if ( ! preg_match( $block_pattern, $content ) ) {
			return;
		}
		$new_content = preg_replace( $block_pattern, '', $content, 1 );
	}

	if ( null !== $new_content && $new_content !== $content ) {
		wp_update_post( array( 'ID' => $page->ID, 'post_content' => $new_content ) );
	}
}

/**
 * Fires on every nieuws_categorie create/edit/delete (and, harmlessly, on
 * every other taxonomy's term changes too — filtered out below). During
 * the very first theme activation this fires once per category in
 * finest_provision_content() before the 'nieuws' page itself exists yet;
 * finest_resync_nieuws_pills() simply no-ops in that case since
 * get_page_by_path() finds nothing, so the page's own provisioning call
 * (which already includes a freshly-built pills row) is unaffected.
 */
function finest_resync_nieuws_pills_on_term_change( $term_id, $tt_id, $taxonomy ) {
	if ( 'nieuws_categorie' !== $taxonomy ) {
		return;
	}
	finest_resync_nieuws_pills();
}
add_action( 'created_term', 'finest_resync_nieuws_pills_on_term_change', 10, 3 );
add_action( 'edited_term', 'finest_resync_nieuws_pills_on_term_change', 10, 3 );
add_action( 'delete_term', 'finest_resync_nieuws_pills_on_term_change', 10, 3 );

/**
 * Runs on theme activation. Permalinks are fixed here too: a fresh WP
 * install defaults to plain "?p=123" links, which silently sends every
 * pretty internal link ("/over-ons/") back to the homepage instead of
 * a 404 (Fase 5's single most important gotcha).
 */
function finest_on_activation() {
	finest_provision_content();

	if ( ! get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}

	update_option( 'finest_content_provisioned', '1' );
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'finest_on_activation' );

/**
 * Safety net: if some other activation order left provisioning unflagged
 * (e.g. a dependent plugin activated after the theme), run it once from
 * the admin. Never runs before init, so custom taxonomies are already
 * registered by the time this touches them.
 */
function finest_provision_content_once() {
	if ( get_option( 'finest_content_provisioned' ) ) {
		return;
	}
	finest_provision_content();
	update_option( 'finest_content_provisioned', '1' );
}
add_action( 'admin_init', 'finest_provision_content_once' );
