<?php
/**
 * Real page content (Gutenberg block markup) sourced from the client's own
 * "Website teksten + briefing versie def" document; nothing here is
 * invented (Fase 8). Legal pages are the one exception the client
 * explicitly approved: a concept, clearly marked as such, since no legal
 * text was supplied in the briefing.
 *
 * Every function returns plain block-comment markup so it round-trips
 * through the block editor exactly like content a person typed by hand.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Full-bleed, editable image block for a photo already sideloaded into the
 * media library via finest_ensure_photo(). fi-reveal is purely a motion hook
 * (see assets/js/motion.js) — removing it in the block editor just turns
 * off the entrance animation, the image itself is a normal attachment.
 *
 * Uses wp_get_attachment_image() rather than hand-building an <img> from
 * wp_get_attachment_image_url(): that's what actually gets WordPress's own
 * srcset/sizes (so a phone doesn't download the same bytes as a desktop)
 * and width/height (so the browser can reserve layout space before the
 * image loads, instead of the page jumping once it does — CLS).
 *
 * @param bool   $decorative    True for ambient brand photography that adds
 *                               no information beyond what the surrounding
 *                               copy already says (WCAG 2.2 SC 1.1.1 — such
 *                               images should carry alt="", not a media
 *                               library caption repeated as prose).
 * @param string $fetchpriority 'high' for the page's single LCP candidate
 *                               (the hero); left empty everywhere else.
 */
function finest_photo_block( $attachment_id, $decorative = false, $fetchpriority = '' ) {
	if ( ! $attachment_id ) {
		return '';
	}
	$alt  = $decorative ? '' : get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
	$attr = array(
		'class'    => "wp-image-{$attachment_id}",
		'alt'      => $alt,
		// These photos sit at the top of the page, not deep in a long
		// scroll — eager-loading reads better than core's lazy-by-default
		// here, and is required outright for the fetchpriority="high" case.
		'loading'  => false,
		'decoding' => 'async',
	);
	if ( $fetchpriority ) {
		$attr['fetchpriority'] = $fetchpriority;
	}
	$img = wp_get_attachment_image( $attachment_id, 'full', false, $attr );
	if ( ! $img ) {
		return '';
	}
	return <<<HTML
<!-- wp:image {"id":{$attachment_id},"sizeSlug":"full","linkDestination":"none","align":"full","className":"fi-reveal"} -->
<figure class="wp-block-image alignfull size-full fi-reveal">{$img}</figure>
<!-- /wp:image -->
HTML;
}

/**
 * Small, non-full-bleed portrait for a team member card. Same idea as
 * finest_photo_block() but aligned "none" (sits inside the column) and
 * tagged with finest-team-photo instead of fi-reveal, since the team grid
 * fades in as a group via its wrapping section, not per-photo.
 */
function finest_team_photo_block( $attachment_id ) {
	if ( ! $attachment_id ) {
		return '';
	}
	$img = wp_get_attachment_image(
		$attachment_id,
		'medium',
		false,
		array(
			'class'    => "wp-image-{$attachment_id}",
			'decoding' => 'async',
		)
	);
	if ( ! $img ) {
		return '';
	}
	return <<<HTML
<!-- wp:image {"id":{$attachment_id},"sizeSlug":"medium","linkDestination":"none","className":"finest-team-photo"} -->
<figure class="wp-block-image size-medium finest-team-photo">{$img}</figure>
<!-- /wp:image -->
HTML;
}

/**
 * Wraps a sequence of already-built blocks (heading/paragraphs/button) in a
 * two-column "explainer-grid" alongside a sticky scroll-driven canvas
 * diagram (assets/js/explainers.js), matching the four homepage sections
 * it's built for — $scene must be one of the keys explainers.js's `scenes`
 * map knows: stats | mess | hub | balance. The canvas itself is a `<canvas>`
 * element with no content of its own (aria-hidden), so it carries no
 * information not already present in $text_html — screen readers and
 * no-JS visitors get the identical copy, just without the animated
 * companion graphic (see explainers.js header comment: it degrades to a
 * static drawn end-state under prefers-reduced-motion, and to nothing at
 * all if JS/GSAP/ScrollTrigger never load, which is fine since aria-hidden
 * already takes it out of the accessibility tree either way).
 *
 * On mobile (<900px) the two-column CSS grid collapses to one column and
 * the canvas is no longer position:sticky (see .explainer-canvas in
 * style.css) — it scrolls normally above its text, which is why
 * explainers.js ties its scroll progress to two different ScrollTrigger
 * instances (gsap.matchMedia breakpoints) rather than one.
 *
 * @param string $scene     stats | mess | hub | balance.
 * @param string $text_html Pre-built block markup (heading/paragraphs/etc).
 * @param bool   $reverse   Alternates the grid column order for visual
 *                          rhythm down the page (see style.css
 *                          .explainer-grid--reverse).
 */
function finest_explainer_block( $scene, $text_html, $reverse = false ) {
	$scene_e = esc_attr( $scene );
	$class   = 'explainer-grid' . ( $reverse ? ' explainer-grid--reverse' : '' );
	return <<<HTML
<!-- wp:group {"className":"{$class}","layout":{"type":"constrained"}} -->
<div class="wp-block-group {$class}">

<!-- wp:html -->
<div class="explainer-canvas" data-scene="{$scene_e}" aria-hidden="true"><canvas></canvas></div>
<!-- /wp:html -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

{$text_html}

</div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->
HTML;
}

function finest_cta_button( $label = 'Plan een kennismaking', $url = '/contact/' ) {
	$url = esc_url( $url );
	$label = esc_html( $label );
	return <<<HTML
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="{$url}">{$label}</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
HTML;
}

function finest_home_page_content() {
	$hero_photo_id = finest_ensure_photo( 'fotografie-website2.jpg', 'The Finest Impact — portret 1' );

	$hero_open = '';
	$hero_close = "\n</div>\n<!-- /wp:cover -->";
	if ( $hero_photo_id ) {
		$hero_url = esc_url( wp_get_attachment_image_url( $hero_photo_id, 'full' ) );
		// Decorative (WCAG 2.2 SC 1.1.1): this is a dimmed ambient background
		// photo behind the hero headline, not content in its own right —
		// alt="" is correct here, not a repeated media-library caption.
		// fetchpriority="high" + decoding="async": this image is the page's
		// LCP candidate (it's the first thing painted, full-bleed, above
		// the fold on every device) — see the mobile-performance notes in
		// assets/js/motion.js's own header comment for the rest of this
		// theme's Core Web Vitals approach.
		//
		// Native Cover block: the client can swap this for a real video
		// later (Media panel → upload video) with zero code changes — the
		// block natively supports a video background, this just starts as
		// a photo one. fi-hero-video adds a slow, continuous Ken Burns
		// zoom (assets/js/motion.js doesn't touch it; it's a plain CSS
		// animation, so it's covered by the existing global
		// prefers-reduced-motion rule in style.css without extra wiring).
		$hero_open = <<<HTML
<!-- wp:cover {"url":"{$hero_url}","id":{$hero_photo_id},"dimRatio":50,"overlayColor":"zwart","minHeight":640,"contentPosition":"bottom left","textColor":"linnen","className":"fi-hero-video"} -->
<div class="wp-block-cover fi-hero-video is-position-bottom-left has-linnen-color has-text-color" style="min-height:640px">
<span aria-hidden="true" class="wp-block-cover__background has-zwart-background-color has-background-dim-50 has-background-dim"></span>
<img class="wp-block-cover__image-background wp-image-{$hero_photo_id}" alt="" fetchpriority="high" decoding="async" src="{$hero_url}" data-object-fit="cover"/>
<div class="wp-block-cover__inner-container">

HTML;
	} else {
		// Fallback if the sideload ever fails: same content, plain section,
		// no background photo, so the page still provisions correctly.
		$hero_open  = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|70\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
		$hero_open .= '<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
		$hero_close = "\n</div>\n<!-- /wp:group -->";
	}

	$hero = $hero_open . <<<'HTML'
<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">Own your spotlight</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Maximale marketingkracht. Optimale zorg.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">The Finest Impact is een compleet marketingteam in één platform. Marketing voor jouw merk die klaar is voor de toekomst.</p>
<!-- /wp:paragraph -->

HTML;
	$hero .= finest_cta_button( 'Plan een kennismaking', '/contact/' );
	$hero .= $hero_close;

	// First scroll-driven explainer ("stats"): the three lines that used to
	// live inside the hero, now their own section with a companion canvas
	// diagram (assets/js/explainers.js). No heading — same as the other
	// three explainer sections below, the canvas is the visual anchor.
	$stats_text = <<<'HTML'
<!-- wp:paragraph -->
<p>Meer zichtbaarheid. Meer continuïteit. Meer commerciële impact.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Van strategie en campagnes tot content, social media, e-mail, vindbaarheid en concurrentieanalyse. Het marketingteam is gepersonaliseerd voor jouw bedrijf en werkt samen vanuit jouw merk, jouw klanten en jouw commerciële doelen. Jij bepaalt de richting en houdt altijd de controle. De agents doen het uitvoerende werk.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Zo houd jij meer tijd over voor waar je écht goed in bent: klanten adviseren, brillen verkopen en de beste oogzorg bieden.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>The Finest Impact laat je marketing presteren.</strong></p>
<!-- /wp:paragraph -->
HTML;
	$stats  = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$stats .= '<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
	$stats .= finest_explainer_block( 'stats', $stats_text, false );
	$stats .= "\n</div>\n<!-- /wp:group -->";

	$herkenning_text = <<<'HTML'
<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Als opticien ligt je aandacht in de winkel</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Bij je klanten, je collectie, je team en de oogzorg die je biedt. Toch vraagt marketing iedere week opnieuw om aandacht.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Een nieuwe brillencollectie die onder de aandacht moet worden gebracht. Social media die bijgehouden moet worden. Een nieuwsbrief die nog verstuurd moet worden. Campagnes die op tijd moeten starten. En natuurlijk wil je die klant regelmatig terugbrengen naar de winkel.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In de praktijk ligt dat werk vaak bij één persoon die marketing naast alle andere werkzaamheden doet. Of verschillende marketing­werkzaamheden worden verdeeld over bureaus, freelancers en losse tools.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Voor je het weet wordt marketing iets wat gebeurt als er tijd over is en is de consistentie ver te zoeken. Vaak ontbreken niet de ideeën, maar de tijd en de capaciteit.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>En precies daar begint The Finest Impact.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-fi-outline"} -->
<div class="wp-block-button is-style-fi-outline"><a class="wp-block-button__link wp-element-button" href="/diensten/">Ontdek hoe het werkt</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
HTML;
	$herkenning  = "<!-- wp:group {\"backgroundColor\":\"zwart\",\"textColor\":\"linnen\",\"className\":\"is-style-fi-dark-section\",\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\",\"left\":\"var:preset|spacing|50\",\"right\":\"var:preset|spacing|50\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$herkenning .= '<div class="wp-block-group is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">' . "\n\n";
	$herkenning .= finest_explainer_block( 'mess', $herkenning_text, true );
	$herkenning .= "\n</div>\n<!-- /wp:group -->";

	$wat_is_text = <<<'HTML'
<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Alles wat je nodig hebt om marketing van de toekomst te runnen</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The Finest Impact brengt jouw marketing samen in één centrale omgeving; één dashboard waar jij iedere dag op kan inloggen om te zien wat er speelt. Misschien moet je iets doen, iets activeren of goedkeuren. Onder het genot van een kopje koffie heb jij het zo op orde en kan je focus naar de winkel.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Strategie, campagnes, content, social media, e-mailmarketing, vindbaarheid, marktinzichten en analyse werken niet langer los van elkaar, maar vanuit dezelfde kennis over jouw bedrijf, je concurrentie en je groeikansen. Goede marketing begint niet bij een losse post, advertentie of nieuwsbrief. Het begint bij weten wie je bent, wie je klanten zijn en wat je wilt bereiken. Daarom richten we The Finest Impact in rondom het DNA van jouw bedrijf.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daardoor hoef je niet iedere campagne opnieuw vanaf nul te bedenken en hoef je niet steeds verschillende partijen te briefen. Een volledige campagneplanning, opgebouwd vanuit jouw doelstellingen, met 360 graden materialen voor de juiste kanalen, in een oogopslag en gemakkelijk aan te bewerken wanneer jij dat nodig vindt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Je marketing krijgt één lijn en één duidelijke richting.<br><strong>Meer marketingkracht. Zonder een groter marketingteam.</strong></p>
<!-- /wp:paragraph -->
HTML;
	$wat_is  = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$wat_is .= '<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
	$wat_is .= finest_explainer_block( 'hub', $wat_is_text, false );
	$wat_is .= "\n</div>\n<!-- /wp:group -->";

	$opticiens_text = <<<'HTML'
<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Speciaal voor opticiens</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Jij bent opticien en je wilt gewoon resultaat. Meer verkopen.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>En dat snappen we. The Finest Impact is ontwikkeld voor opticiens die marketing professioneel willen aanpakken. Het doel is dat marketing consistent bijdraagt aan je bedrijf.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Jij kent je klanten. Jij weet welke collectie belangrijk is. Jij weet wat er in je winkel speelt. Jij bepaalt waar je naartoe wilt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Wij zorgen samen met ons platform dat die kennis wordt vertaald naar sterke marketing. Menselijke expertise bepaalt de strategie en bewaakt de kwaliteit. Slimme AI-technologie zorgt voor snelheid, capaciteit en uitvoering.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Jij brengt de kennis van je bedrijf. The Finest Impact brengt de marketingkracht.</strong></p>
<!-- /wp:paragraph -->
HTML;
	$opticiens  = "<!-- wp:group {\"backgroundColor\":\"klei\",\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\",\"left\":\"var:preset|spacing|50\",\"right\":\"var:preset|spacing|50\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$opticiens .= '<div class="wp-block-group has-klei-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">' . "\n\n";
	$opticiens .= finest_explainer_block( 'balance', $opticiens_text, true );
	$opticiens .= "\n</div>\n<!-- /wp:group -->";

	$faq = finest_faq_block();

	$stories = finest_stories_block();

	$slot = <<<'HTML'
<!-- wp:group {"backgroundColor":"zwart","textColor":"linnen","className":"is-style-fi-dark-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">

<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">Own your spotlight</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Professionele marketing vraagt geen volledige marketingafdeling</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Het vraagt marketing van de toekomst.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The Finest Impact combineert jouw kennis van je bedrijf met marketingexpertise en AI-technologie die het zware werk voor je doet. Zodat je zichtbaar blijft, sneller commerciële kansen benut en meer uit je marketing haalt. Terwijl jij kunt blijven doen waar jij het verschil maakt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>The Finest Impact laat je marketing presteren.</strong></p>
<!-- /wp:paragraph -->

HTML;
	$slot .= finest_cta_button( 'Plan een kennismaking', '/contact/' );
	$slot .= "\n</div>\n<!-- /wp:group -->";

	// The hero already uses "portret 1" as its cover background; this second
	// photo gets its own full-bleed moment between the "hub" and "balance"
	// explainer sections so the same image doesn't appear twice in a row.
	$photo_team = finest_photo_block( finest_ensure_photo( 'the_finest_impact1.jpg', 'The Finest Impact — portret 2' ), true );

	return implode( "\n\n", array_filter( array( $hero, $stats, $herkenning, $wat_is, $photo_team, $opticiens, $faq, $stories, $slot ) ) );
}

/**
 * "Optiek Stories" — a horizontally scrollable, GSAP-pinned rail of the
 * latest Klantverhalen, closing out the homepage. Deliberately a real
 * core/query block (not a PHP-built static snapshot like the sections
 * above): this runs fresh on every request, so a klantverhaal published
 * next month shows up here automatically with no need to ever re-save the
 * home page. core/query-no-results covers the empty state (a fresh
 * install has zero klantverhalen yet) the same way finest_klantverhalen_intro_content()
 * already does on its own page — "Nog geen klantverhalen gepubliceerd.",
 * not a broken-looking empty rail.
 *
 * The horizontal pin/scroll-snap treatment itself is CSS + the
 * `.finest-stories-query` hook in assets/js/motion.js (progressive
 * enhancement — the posts list is a normal vertical stack of readable
 * links with no JS at all, see .finest-stories-query in style.css).
 */
function finest_stories_block() {
	return <<<'HTML'
<!-- wp:group {"className":"finest-stories","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-stories" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--70)">

<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->
<div class="wp-block-group">
<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Optiek Stories</h2>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-fi-outline"} -->
<div class="wp-block-button is-style-fi-outline"><a class="wp-block-button__link wp-element-button" href="/klantverhalen/">Alle stories</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:query {"query":{"postType":"klantverhaal","perPage":6,"orderBy":"date","order":"desc"},"className":"finest-stories-query"} -->
<div class="wp-block-query finest-stories-query">

<!-- wp:post-template {"className":"finest-stories-track"} -->
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/5"} /-->
<!-- wp:post-title {"isLink":true,"fontSize":"medium"} /-->
<!-- wp:post-excerpt {"excerptLength":16} /-->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph -->
<p>Nog geen klantverhalen gepubliceerd. Zodra er verhalen worden toegevoegd in wp-admin, verschijnen ze hier automatisch.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

</div>
<!-- /wp:query -->

</div>
<!-- /wp:group -->
HTML;
}

function finest_faq_item( $question, $answer ) {
	$q = esc_html( $question );
	$a = esc_html( $answer );
	return <<<HTML
<!-- wp:details -->
<details class="wp-block-details"><summary>{$q}</summary>
<!-- wp:paragraph -->
<p>{$a}</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
HTML;
}

function finest_faq_block() {
	$items = array(
		array( 'Wat is The Finest Impact?', 'The Finest Impact is een compleet marketingteam in één platform, ontwikkeld voor de optiek. Het helpt je bij alles wat nodig is om je marketing structureel goed te organiseren. Van strategie en campagnes tot content, social media, e-mailmarketing, vindbaarheid, marktinzichten en analyse. Alles vertrekt vanuit jouw bedrijf, jouw klanten en jouw commerciële doelen. Zo krijg je meer marketingkracht, zonder zelf een volledige marketingafdeling op te bouwen.' ),
		array( 'Voor wie is The Finest Impact bedoeld?', 'Voor zelfstandige opticiens die marketing belangrijk vinden, maar merken dat het er in de praktijk te vaak bij wordt gedaan. Misschien ligt marketing nu bij jou als ondernemer. Misschien doet een medewerker het erbij. Of werk je met verschillende bureaus en freelancers. The Finest Impact brengt daar meer structuur, snelheid en samenhang in: één platform waarin jouw gehele marketingteam samenkomt.' ),
		array( 'Wat kan The Finest Impact voor mijn optiekbedrijf doen?', 'The Finest Impact helpt je om vooruit te kijken, campagnes op tijd te plannen, regelmatig zichtbaar te zijn, klanten opnieuw te activeren en beter gebruik te maken van kansen in je markt. Niet meer iedere week opnieuw bedenken wat je moet posten of welke actie je moet verzinnen. Je werkt vanuit een duidelijke marketinglijn.' ),
		array( 'Is The Finest Impact alleen bedoeld voor content en social media?', 'Nee. Content is maar één onderdeel van marketing. The Finest Impact helpt ook bij strategie, campagnes, klantactivatie, e-mailmarketing, lokale zichtbaarheid, vindbaarheid in Google en AI, marktontwikkelingen en het analyseren van wat werkt.' ),
		array( 'Werkt The Finest Impact met AI?', 'Ja, AI speelt een belangrijke rol. Maar The Finest Impact is niet ontwikkeld om simpelweg zoveel mogelijk content te produceren. AI wordt ingezet om sneller te kunnen onderzoeken, plannen, maken, analyseren en verbeteren. Jouw bedrijf, klanten en commerciële doelen blijven altijd het uitgangspunt.' ),
		array( 'Krijg ik dan van die typische AI-teksten?', 'Dat willen we juist voorkomen. The Finest Impact leert jouw merk, doelgroep, tone of voice, aanbod en manier van communiceren kennen. Daardoor ontstaat marketing die beter bij jouw merk past en niet klinkt alsof dezelfde tekst ook voor iedere andere opticien geschreven had kunnen zijn.' ),
		array( 'Heb ik nog wel zelf controle over mijn marketing?', 'Altijd. The Finest Impact is geen automatische marketingmachine die zelfstandig van alles publiceert. Zie het als een extra marketingteam naast je. Het platform helpt je denken, voorbereiden, maken en verbeteren. Jij bepaalt uiteindelijk wat past bij jouw bedrijf en wat naar buiten gaat.' ),
		array( 'Kan één medewerker hiermee werken?', 'Ja. Dat is juist één van de uitgangspunten. Je hoeft geen groot marketingteam of senior marketeer in dienst te hebben. Ook een ondernemer, marketingmedewerker of communicatiemedewerker kan met The Finest Impact werken. De kennis en slagkracht die normaal over meerdere specialisten verdeeld is, wordt veel toegankelijker.' ),
		array( 'Vervangt The Finest Impact mijn marketingbureau of marketeer?', 'Dat hoeft niet. Heb je een goede marketeer of een bureau waar je prettig mee werkt, dan kan The Finest Impact juist helpen om meer gedaan te krijgen. Tegelijkertijd kan het platform werkzaamheden overnemen die nu verspreid liggen over verschillende bureaus, freelancers en tools. Je bepaalt dus zelf wat je intern wilt organiseren en waar je externe expertise voor wilt blijven inzetten.' ),
		array( 'Hoe weet The Finest Impact wat bij mijn bedrijf past?', 'Daar begint onze samenwerking mee. Voordat we The Finest Impact voor je inrichten, kijken we naar je bedrijf, positionering, klanten, aanbod, huidige marketing en commerciële ambities. Wat staat al goed? Waar liggen kansen? Wat ontbreekt nog? Pas daarna richten we The Finest Impact in rondom jouw organisatie. Geen standaardpakket waarin iedere opticien hetzelfde krijgt.' ),
		array( 'Hoe starten we?', 'We beginnen met een Strategische Marketing Sessie. Daarin kijken we samen naar je huidige marketing, doelgroep, positionering, zichtbaarheid en commerciële doelen. Vervolgens bepalen we jouw belangrijke data en marketingstrategie, wat eerst aangescherpt moet worden en hoe The Finest Impact jouw marketing het beste kan ondersteunen. Daaruit ontstaat een duidelijke strategische richting voor de komende periode.' ),
		array( 'Kan The Finest Impact samenwerken met systemen die we al gebruiken?', 'Waar dat relevant is, kan The Finest Impact samenwerken met bestaande marketing- en bedrijfssystemen. Denk aan je kassasysteem, meta, nieuwsbrief e.d. Welke koppelingen zinvol zijn, verschilt per organisatie. Ons uitgangspunt is simpel: we koppelen niet omdat het technisch kan, maar alleen wanneer het jouw marketing daadwerkelijk beter, slimmer of makkelijker maakt.' ),
		array( 'Is onze informatie veilig?', 'Daar besteden we vanaf het begin veel aandacht aan. We kijken zorgvuldig naar welke informatie nodig is, wie toegang heeft en hoe bedrijfs- en klantinformatie wordt gebruikt. Daarbij geldt altijd: niet méér data gebruiken dan nodig is. Zeker wanneer systemen of klantgegevens met elkaar worden verbonden, moeten veiligheid en privacy goed geregeld zijn.' ),
		array( 'Wat levert The Finest Impact mij uiteindelijk op?', 'Niet simpelweg meer marketing. Maar betere marketing. Meer structuur. Meer continuïteit. Snellere uitvoering. Sterkere campagnes. Meer zichtbaarheid. Meer inzicht in wat werkt. Meer sales. En vooral: minder tijd kwijt zijn aan het organiseren van marketing. Zodat jij je kunt richten op waar je uiteindelijk het verschil maakt: je klanten, je winkel, je collectie, je sales en goede oogzorg.' ),
		array( 'Wat kost The Finest Impact?', 'The Finest Impact wordt ingericht rondom jouw organisatie. De investering hangt daarom af van waar je nu staat en wat nodig is om je marketing goed te organiseren. Tijdens een kennismaking kijken we eerst naar je huidige situatie en ambities. Daarna kunnen we heel concreet aangeven welke aanpak bij jouw organisatie past.' ),
		array( 'Kan ik eerst zien hoe het werkt?', 'Natuurlijk. Tijdens een demo laten we je zien hoe The Finest Impact werkt aan de hand van herkenbare situaties uit de optiek. Geen technische softwaretour, maar vooral: wat betekent dit voor jouw dagelijkse marketing?' ),
	);

	$out = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$out .= '<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
	$out .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Veelgestelde vragen</h2>\n<!-- /wp:heading -->\n\n";
	foreach ( $items as $item ) {
		$out .= finest_faq_item( $item[0], $item[1] ) . "\n\n";
	}
	$out .= finest_cta_button( 'Plan een demo', '/contact/' );
	$out .= "\n</div>\n<!-- /wp:group -->";
	return $out;
}

function finest_team_member_block( $name, $role, $phone, $linkedin, $photo_id = 0 ) {
	$name_e  = esc_html( $name );
	$role_e  = esc_html( $role );
	$phone_e = esc_html( $phone );
	$li_e    = esc_url( $linkedin );
	$photo   = finest_team_photo_block( $photo_id );
	// WCAG 2.2 SC 2.4.4: four cards in a row all ending in a bare
	// "LinkedIn" link are indistinguishable to anyone navigating by a
	// screen reader's links list (no surrounding context there) — an
	// aria-label gives each one a distinct, meaningful accessible name
	// without changing the visible link text.
	$li_label = esc_attr( sprintf( 'LinkedIn-profiel van %s (opent in nieuw tabblad)', $name ) );
	return <<<HTML
<!-- wp:column -->
<div class="wp-block-column">

{$photo}

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">{$name_e}</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">{$role_e}</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">{$phone_e}<br><a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a><br><a href="{$li_e}" target="_blank" rel="noopener" aria-label="{$li_label}">LinkedIn</a></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->
HTML;
}

function finest_over_ons_page_content() {
	$intro = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Marketing first. Technology powered. Human controlled.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Marketing wordt steeds belangrijker, maar voor veel ondernemers ook steeds moeilijker om goed te organiseren. Er zijn meer kanalen, meer data, meer technologie en meer mogelijkheden dan ooit. Maar tijd en capaciteit groeien niet automatisch mee.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Met meer dan 20 jaar ervaring in marketing en ruime kennis van de optiekbranche kennen we die werkelijkheid van heel dichtbij. We weten hoe belangrijk merk, strategie, creativiteit en commercieel inzicht zijn. We weten ook hoe vaak goede marketing blijft liggen omdat de dagelijkse praktijk voorgaat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Daarom hebben we The Finest Impact ontwikkeld.</strong></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->

<!-- wp:group {"backgroundColor":"zwart","textColor":"linnen","className":"is-style-fi-dark-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Marketing expertise en technologie horen bij elkaar</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Technologie kan veel, maar zonder richting, context en commercieel inzicht ontstaat vooral meer output. Daar geloven wij niet in.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Wij geloven in marketing die consistent is en klopt. Marketing die past bij je merk. Marketing die inspeelt op wat klanten nodig hebben. Marketing die zichtbaar maakt waar je voor staat. En marketing die uiteindelijk écht iets moet opleveren, namelijk sales.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daarom combineren we menselijke expertise met technologie. De mens bepaalt de strategie, bewaakt de kwaliteit en maakt de keuzes. The Finest Impact zorgt voor snelheid, structuur en uitvoeringskracht. Samen ontstaat marketing die efficiënt en consistent wordt en zorgt voor groei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Own your spotlight.</strong></p>
<!-- /wp:paragraph -->

HTML;
	$intro .= finest_cta_button( 'Maak kennis met The Finest Impact', 'mailto:info@thefinestimpact.com' );
	$intro .= "\n</div>\n<!-- /wp:group -->";

	$team = "\n\n<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$team .= '<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
	$team .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Ontmoet ons team</h2>\n<!-- /wp:heading -->\n\n";
	$team .= "<!-- wp:paragraph -->\n<p>De mensen achter The Finest Impact.</p>\n<!-- /wp:paragraph -->\n\n";
	$team .= "<!-- wp:columns -->\n<div class=\"wp-block-columns\">\n";
	$team .= finest_team_member_block( 'Karin Boon', 'Co-founder & Head of Growth', '+31 6 48 46 99 24', 'https://www.linkedin.com/in/karinboon/', finest_ensure_photo( 'karin.jpg', 'Karin Boon', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Manon van Gasteren', 'Co-founder & Head of Marketing', '+31 6 22 80 82 36', 'https://www.linkedin.com/in/manonvangasteren/', finest_ensure_photo( 'manon.jpg', 'Manon van Gasteren', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Ben Verschuur', 'Co-founder & Head of Technology', '+31 6 13 01 32 66', 'https://www.linkedin.com/in/benverschuur/', finest_ensure_photo( 'ben.jpg', 'Ben Verschuur', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Bo Seerden', 'Co-founder & Head of Engineering', '+31 6 19 25 11 93', 'https://www.linkedin.com/in/boseerden/', finest_ensure_photo( 'bo.jpg', 'Bo Seerden', 'team' ) ) . "\n";
	$team .= "</div>\n<!-- /wp:columns -->\n\n</div>\n<!-- /wp:group -->";

	return $intro . $team;
}

function finest_diensten_page_content() {
	$blok1 = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Van strategie naar marketing die presteert</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Goede marketing begint niet met technologie. Het begint met weten waar je staat, wie je klant is, waar je kansen liggen en wat nodig is om te groeien.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Met meer dan 20 jaar ervaring in marketing en ruime kennis van de optiekbranche weten we hoe marketing werkt, maar vooral ook wat er in de praktijk nodig is om die marketing daadwerkelijk te laten presteren.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daarom start The Finest Impact altijd vanuit jouw bedrijf. We brengen je marketing in kaart, bepalen samen de juiste richting, versterken wat nog ontbreekt en richten daarna jouw eigen marketingomgeving in.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Vanaf dat moment werk je structureel samen met The Finest Impact, onze marketingexpertise en gespecialiseerde marketing agents.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Menselijke expertise bepaalt de richting. Technologie zorgt voor snelheid, capaciteit en uitvoering.</strong></p>
<!-- /wp:paragraph -->

HTML;
	$blok1 .= finest_cta_button( 'Plan een kennismaking', '/contact/' );
	$blok1 .= "\n</div>\n<!-- /wp:group -->";

	$stappen = array(
		array( 'We brengen de situatie in kaart', 'We starten met een strategische marketing sessie. Daarin kijken we naar je huidige marketing, doelgroep, positionering, klantreis, zichtbaarheid en commerciële ambities. Het resultaat is een concrete marketing roadmap.' ),
		array( 'We versterken wat nog ontbreekt', 'Op basis van die marketing roadmap bepalen we wat eerst beter moet. Dat kan bijvoorbeeld gaan om positionering, branding, contentstrategie, social media, campagnes, SEO, lokale vindbaarheid of zichtbaarheid in AI.' ),
		array( 'We richten The Finest Impact in', 'Zodra de marketingbasis staat, bouwen we jouw eigen marketingomgeving. We vertalen je merk, doelgroep, tone of voice, aanbod, doelen en kennis naar The Finest Impact en richten de juiste agents, workflows, kwaliteitscontrole en koppelingen in.' ),
		array( 'We gaan ermee werken en optimaliseren', 'Daarna wordt The Finest Impact onderdeel van je dagelijkse marketing. Je team gebruikt de omgeving voor onder andere campagnes, content, klantcommunicatie, zichtbaarheid en analyse. Jullie kennis blijft leidend, terwijl The Finest Impact helpt om sneller, consistent en professioneler te werken. Zo ontstaat stap voor stap een marketingaanpak die niet alleen slimmer is ingericht, maar ook structureel blijft werken.' ),
	);

	$blok2 = "\n\n<!-- wp:group {\"backgroundColor\":\"klei\",\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\",\"left\":\"var:preset|spacing|50\",\"right\":\"var:preset|spacing|50\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$blok2 .= '<div class="wp-block-group has-klei-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">' . "\n\n";
	$blok2 .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Hoe gaan we te werk?</h2>\n<!-- /wp:heading -->\n\n";
	$blok2 .= "<!-- wp:paragraph -->\n<p>We werken in vier duidelijke stappen. Zo bouwen we niet zomaar iets, maar zorgen we dat iedere keuze aansluit op jouw organisatie, ambities en marketingdoelen.</p>\n<!-- /wp:paragraph -->\n\n";
	foreach ( $stappen as $i => $stap ) {
		$n = $i + 1;
		$blok2 .= "<!-- wp:heading {\"level\":3,\"fontSize\":\"medium\"} -->\n<h3 class=\"wp-block-heading has-medium-font-size\">{$n}. {$stap[0]}</h3>\n<!-- /wp:heading -->\n\n";
		$blok2 .= "<!-- wp:paragraph -->\n<p>{$stap[1]}</p>\n<!-- /wp:paragraph -->\n\n";
	}
	$blok2 .= "</div>\n<!-- /wp:group -->";

	return $blok1 . $blok2;
}

function finest_contact_page_content() {
	$content = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Plan een kennismaking</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Tijdens een kennismaking kijken we eerst naar je huidige situatie en ambities. Daarna kunnen we heel concreet aangeven welke aanpak bij jouw organisatie past.</p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class="wp-block-columns">

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Stuur een bericht</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[finest_contact_form]
<!-- /wp:shortcode -->

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Direct contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Karin Boon, Head of Growth<br>+31 6 48 46 99 24</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Manon van Gasteren, Head of Marketing<br>+31 6 22 80 82 36</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->
HTML;
	return $content;
}

function finest_klantverhalen_intro_content() {
	$intro = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--50)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Wat gebeurt er wanneer marketing wél structureel wordt?</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Daar willen we niet alleen over vertellen. We willen het laten zien.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In onze klantverhalen delen we hoe opticiens The Finest Impact gebruiken, wat er verandert in hun dagelijkse marketing en welk resultaat dat oplevert. Van tijdsbesparing en meer zichtbaarheid tot betere campagnes, meer klantactivatie en commerciële groei.</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->
HTML;

	// Same inherit:false correction as finest_nieuws_intro_content() — see
	// that function's comment for why inherit:true is a silent no-posts
	// bug on a regular Page. Reuses the .finest-blog-grid card styling
	// (style.css) for visual consistency with the Nieuws overview, even
	// though klantverhaal has no category taxonomy of its own.
	$grid = <<<'HTML'
<!-- wp:query {"query":{"postType":"klantverhaal","perPage":9,"orderBy":"date","order":"desc","inherit":false},"className":"finest-blog-grid"} -->
<div class="wp-block-query finest-blog-grid">

<!-- wp:post-template {"className":"finest-blog-grid__track"} -->
<!-- wp:group {"className":"finest-blog-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-blog-card">
<!-- wp:post-featured-image {"isLink":true,"className":"finest-blog-card__media"} /-->
<!-- wp:post-title {"isLink":true,"level":3,"fontSize":"medium","className":"finest-blog-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":18,"className":"finest-blog-card__excerpt"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph -->
<p>Nog geen klantverhalen gepubliceerd. In de WordPress-versie is dit een automatische lijst (query op het "Klantverhaal" post type) — zodra er verhalen worden toegevoegd in wp-admin, verschijnen ze hier vanzelf als kaarten met uitgelichte foto, titel en samenvatting.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"className":"finest-pagination"} -->
<!-- wp:query-pagination-previous {"label":"Vorige"} /-->
<!-- wp:query-pagination-numbers /-->
<!-- wp:query-pagination-next {"label":"Volgende"} /-->
<!-- /wp:query-pagination -->

</div>
<!-- /wp:query -->
HTML;

	return $intro . "\n\n" . $grid;
}

/**
 * Category "pills" row for the Nieuws overview — real links to each
 * nieuws_categorie archive (templates/archive.html), built from
 * get_terms() rather than hardcoded, so a category the client adds later
 * in wp-admin shows up here with zero code changes.
 */
function finest_category_pills( $taxonomy ) {
	$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return '';
	}
	$links = '';
	foreach ( $terms as $term ) {
		$url   = esc_url( get_term_link( $term ) );
		$name  = esc_html( $term->name );
		$links .= "<a class=\"finest-pill\" href=\"{$url}\">{$name}</a>\n";
	}
	return <<<HTML
<!-- wp:html -->
<div class="finest-pills">
{$links}</div>
<!-- /wp:html -->
HTML;
}

function finest_nieuws_intro_content() {
	$intro = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40)">

<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">The Finest News</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Blijf voor op wat er in de optiek gebeurt</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size" style="max-width:640px">De optiekwereld verandert snel. The Finest News volgt wat er gebeurt in Nederland én daarbuiten — en kijkt vooral naar de vraag: wat betekent dit voor jou als opticien?</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->
HTML;

	$pills = finest_category_pills( 'nieuws_categorie' );
	$pills_wrap = '';
	if ( $pills ) {
		$pills_wrap  = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"bottom\":\"var:preset|spacing|50\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
		$pills_wrap .= '<div class="wp-block-group" style="padding-bottom:var(--wp--preset--spacing--50)">' . "\n\n";
		$pills_wrap .= $pills;
		$pills_wrap .= "\n\n</div>\n<!-- /wp:group -->";
	}

	// inherit:false (the default — stated explicitly so the next person
	// doesn't "helpfully" add inherit:true back): this is a normal static
	// Page, not the designated "Posts page", so there is no main post
	// query here to inherit. A Query Loop with inherit:true on a page like
	// this silently falls back to the page's own single-page query — i.e.
	// it would render zero posts. className values below are the CSS
	// hooks for the editorial card grid in style.css (.finest-blog-grid).
	$grid = <<<'HTML'
<!-- wp:query {"query":{"postType":"post","perPage":9,"orderBy":"date","order":"desc","inherit":false},"className":"finest-blog-grid"} -->
<div class="wp-block-query finest-blog-grid">

<!-- wp:post-template {"className":"finest-blog-grid__track"} -->
<!-- wp:group {"className":"finest-blog-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-blog-card">
<!-- wp:post-featured-image {"isLink":true,"className":"finest-blog-card__media"} /-->
<!-- wp:post-terms {"term":"nieuws_categorie","fontSize":"label","className":"finest-blog-card__cat"} /-->
<!-- wp:post-title {"isLink":true,"level":3,"fontSize":"medium","className":"finest-blog-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":18,"className":"finest-blog-card__excerpt"} /-->
<!-- wp:post-date {"fontSize":"label","className":"finest-blog-card__date"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph -->
<p>Nog geen artikelen gepubliceerd. In de WordPress-versie is dit de normale blogfunctie (reguliere posts + categorie "Nieuws categorie") — nieuwe berichten verschijnen hier automatisch, inclusief RSS-feed.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"className":"finest-pagination"} -->
<!-- wp:query-pagination-previous {"label":"Vorige"} /-->
<!-- wp:query-pagination-numbers /-->
<!-- wp:query-pagination-next {"label":"Volgende"} /-->
<!-- /wp:query-pagination -->

</div>
<!-- /wp:query -->
HTML;

	return $intro . "\n\n" . $pills_wrap . "\n\n" . $grid;
}

require_once __DIR__ . '/content-legal.php';
