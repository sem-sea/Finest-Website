/**
 * The Finest Impact — motion layer.
 *
 * Interaction/transition language adapted from verostudio.com (read from
 * their shipped CSS, not guessed): entrance reveals use clip-path "mask"
 * opens and staggered line reveals on power/expo easing, a thin scroll
 * progress line, and a pinned horizontal rail for the Optiek Stories
 * section. Wheel/trackpad scrolling is eased by Lenis (assets/js/vendor/,
 * MIT) and kept in step with ScrollTrigger. Lenis leaves touch scrolling to
 * the device (syncTouch is off), is skipped under prefers-reduced-motion,
 * and the page scrolls natively if the file fails to load.
 *
 * This is a pure progressive-enhancement layer on top of ordinary Gutenberg
 * block content: it only ever adds `fi-reveal` / `fi-reveal-lines` classes
 * as motion hooks. Content is fully present and visible with JS off, with
 * prefers-reduced-motion, or if any of the vendored libraries fail to load
 * — `showFallback()` is only ever called on a failure/degraded path, never
 * after animations have actually been wired up (that would !important-
 * override the reveal states this script just set).
 */
(function () {
	'use strict';

	var root = document.documentElement;
	var reducedMotion =
		root.classList.contains( 'reduced-motion' ) ||
		( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );

	var fallbackShown = false;
	function showFallback() {
		if ( fallbackShown ) {
			return;
		}
		fallbackShown = true;
		root.classList.add( 'motion-fallback' );
	}
	// Last-resort safety net: if this script hangs or something unforeseen
	// never calls clearTimeout, content is never stuck invisible for long.
	var fallbackTimer = window.setTimeout( showFallback, 4000 );

	function ready( fn ) {
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', fn );
		} else {
			fn();
		}
	}

	ready( function () {
		if ( reducedMotion ) {
			showFallback();
			return;
		}

		if ( typeof window.gsap === 'undefined' || typeof window.ScrollTrigger === 'undefined' ) {
			showFallback();
			return;
		}

		try {
			var gsap = window.gsap;
			gsap.registerPlugin( window.ScrollTrigger );

			// --- smooth wheel scrolling (Lenis), optional ---
			if ( window.Lenis ) {
				var lenis = new window.Lenis( {
					duration: 1.1,
					easing: function ( t ) {
						return 1 - Math.pow( 1 - t, 3 );
					},
					smoothWheel: true,
				} );
				lenis.on( 'scroll', window.ScrollTrigger.update );
				gsap.ticker.add( function ( time ) {
					lenis.raf( time * 1000 );
				} );
				gsap.ticker.lagSmoothing( 0 );

				// Page must not scroll behind the open mobile menu.
				new MutationObserver( function () {
					if ( root.classList.contains( 'has-modal-open' ) ) {
						lenis.stop();
					} else {
						lenis.start();
					}
				} ).observe( root, { attributes: true, attributeFilter: [ 'class' ] } );

				// Anchor links (skip link, #sections) glide instead of jumping.
				document.addEventListener( 'click', function ( e ) {
					var link = e.target.closest ? e.target.closest( 'a[href^="#"]' ) : null;
					if ( ! link || e.defaultPrevented || link.getAttribute( 'href' ).length < 2 ) {
						return;
					}
					var target = null;
					try {
						target = document.querySelector( link.getAttribute( 'href' ) );
					} catch ( err ) {
						return;
					}
					if ( ! target ) {
						return;
					}
					e.preventDefault();
					lenis.scrollTo( target, { offset: -96 } );
					if ( window.history && window.history.pushState ) {
						window.history.pushState( null, '', link.getAttribute( 'href' ) );
					}
					if ( ! target.hasAttribute( 'tabindex' ) ) {
						target.setAttribute( 'tabindex', '-1' );
					}
					target.focus( { preventScroll: true } );
				} );

				// Long text areas must scroll themselves, not the page.
				document.querySelectorAll( 'textarea' ).forEach( function ( el ) {
					el.setAttribute( 'data-lenis-prevent', '' );
				} );
			}

			// --- staggered line reveal on headline moments ---
			var headlines = document.querySelectorAll( '.fi-reveal-lines' );
			if ( window.SplitText && headlines.length ) {
				gsap.registerPlugin( window.SplitText );
				headlines.forEach( function ( heading ) {
					var split = window.SplitText.create( heading, {
						type: 'lines',
						mask: 'lines',
						linesClass: 'fi-line',
					} );
					gsap.set( heading, { opacity: 1 } );
					gsap.set( split.lines, { yPercent: 110, opacity: 0 } );
					window.ScrollTrigger.create( {
						trigger: heading,
						start: 'top 85%',
						once: true,
						onEnter: function () {
							gsap.to( split.lines, {
								yPercent: 0,
								opacity: 1,
								duration: 1,
								ease: 'expo.out',
								stagger: 0.08,
							} );
						},
					} );
				} );
			} else if ( headlines.length ) {
				// SplitText failed to load independently of gsap/ScrollTrigger:
				// skip the line-by-line reveal, show the heading as-is.
				gsap.set( headlines, { opacity: 1 } );
			}

			// --- clip-path "mask" reveal on photography ---
			var photos = document.querySelectorAll( '.fi-reveal' );
			if ( photos.length ) {
				gsap.set( photos, {
					clipPath: 'inset(16% 16% 16% 16% round 2px)',
					scale: 1.06,
				} );
				window.ScrollTrigger.batch( photos, {
					start: 'top 88%',
					once: true,
					onEnter: function ( batch ) {
						gsap.to( batch, {
							clipPath: 'inset(0% 0% 0% 0% round 2px)',
							scale: 1,
							duration: 1.3,
							ease: 'power4.out',
							stagger: 0.12,
						} );
					},
				} );
			}

			// --- blog card grid: staggered fade-in (Nieuws/Klantverhalen
			// overview, archive, search, related-posts — see .finest-blog-card
			// in style.css, which sets the pre-animation hidden state and its
			// own motion-fallback override, same pattern as .fi-reveal-lines
			// above). Batched per row-entry rather than all at once so a long
			// paginated list doesn't dump every card's animation on load. ---
			var blogCards = document.querySelectorAll( '.finest-blog-card' );
			if ( blogCards.length ) {
				window.ScrollTrigger.batch( blogCards, {
					start: 'top 92%',
					once: true,
					onEnter: function ( batch ) {
						gsap.to( batch, {
							opacity: 1,
							y: 0,
							duration: 0.7,
							ease: 'power3.out',
							stagger: 0.08,
						} );
					},
				} );
			}

			// --- Optiek Stories: pinned horizontal rail on desktop ---
			// .finest-stories-query is the wp:query block wrapper (see
			// finest_stories_block(), inc/content-pages.php); its
			// post-template child (className finest-stories-track) and each
			// post inside it (core's own .wp-block-post) are real, live
			// WordPress markup — this never hardcodes which/how many
			// klantverhalen exist. On mobile the track is NOT pinned: it's a
			// normal horizontally-scrollable row (overflow-x + scroll-snap
			// in style.css), since pinning the whole viewport to a horizontal
			// drag works poorly with touch scrolling and is unnecessary --
			// the row is already short enough to swipe through directly.
			var storiesQuery = document.querySelector( '.finest-stories-query' );
			var storiesTrack = storiesQuery && storiesQuery.querySelector( '.finest-stories-track' );
			if ( storiesTrack ) {
				var storyCards = storiesTrack.querySelectorAll( '.wp-block-post' );
				if ( storyCards.length > 1 ) {
					var storiesMM = gsap.matchMedia();
					storiesMM.add( '(min-width: 900px)', function () {
						var trackWidth = storiesTrack.scrollWidth - storiesTrack.parentElement.offsetWidth;
						if ( trackWidth <= 0 ) {
							return;
						}
						root.classList.add( 'stories-pinned' );
						var pinTl = gsap.to( storiesTrack, {
							x: -trackWidth,
							ease: 'none',
							scrollTrigger: {
								trigger: storiesQuery,
								start: 'top top+=104',
								end: '+=' + ( trackWidth + 400 ),
								pin: true,
								scrub: 0.6,
								invalidateOnRefresh: true,
							},
						} );
						return function () {
							root.classList.remove( 'stories-pinned' );
							pinTl.scrollTrigger && pinTl.scrollTrigger.kill();
							gsap.set( storiesTrack, { clearProps: 'transform' } );
						};
					} );
				}

				gsap.set( storyCards, { opacity: 0, y: 24 } );
				window.ScrollTrigger.batch( storyCards, {
					start: 'top 90%',
					once: true,
					onEnter: function ( batch ) {
						gsap.to( batch, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', stagger: 0.1 } );
					},
				} );
			}

			// --- thin scroll-progress line (own element, zero markup cost) ---
			var bar = document.createElement( 'div' );
			bar.className = 'fi-scroll-progress';
			bar.setAttribute( 'aria-hidden', 'true' );
			document.body.appendChild( bar );
			gsap.set( bar, { scaleX: 0, transformOrigin: 'left center' } );
			gsap.to( bar, {
				scaleX: 1,
				ease: 'none',
				scrollTrigger: {
					trigger: document.documentElement,
					start: 'top top',
					end: 'max',
					scrub: 0.3,
				},
			} );

			// Success: every targeted element's visibility is now owned by
			// GSAP inline styles. Just cancel the safety net — do NOT call
			// showFallback() here, it would force-override the reveal states
			// above with !important and kill the animation for everyone.
			window.clearTimeout( fallbackTimer );
		} catch ( e ) {
			showFallback();
		}
	} );
} )();
