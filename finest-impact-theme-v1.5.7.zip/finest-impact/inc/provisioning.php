<?php
/**
 * "1-zip" auto-provisioning: activating this theme builds the full site
 * (pages, permalinks, taxonomy terms) with no manual setup.
 *
 * Every lesson from the case-study table in the WordPress Build Blueprint is
 * applied here on purpose:
 *  - ensure_page() uses get_posts(['post_parent'=>...]), never
 *    get_page_by_path(), so it finds child pages on a second run instead of
 *    creating "-2" duplicates.
 *  - The "done" flag is set from both the activation hook and the
 *    admin_init safety net, so a plugin activated after the theme doesn't
 *    leave provisioning permanently un-flagged.
 *  - permalink_structure is set (and rewrite rules flushed) on activation,
 *    or every internal link silently falls back to the homepage.
 *  - Custom taxonomy registration happens on init, and all provisioning
 *    that touches it runs on/after admin_init (after_switch_theme fires
 *    post-init in a real switch_theme() request); never on plugins_loaded.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the "Nieuws" category taxonomy used by native posts (The Finest
 * News uses core `post`, not a custom post type, so it gets archives/RSS/
 * categories for free; see functions.php comment).
 */
function finest_register_taxonomies() {
	register_taxonomy(
		'nieuws_categorie',
		'post',
		array(
			'labels' => array(
				'name'          => __( 'Nieuws categorieën', 'finest-impact' ),
				'singular_name' => __( 'Nieuws categorie', 'finest-impact' ),
			),
			'hierarchical'      => true,
			'public'            => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'nieuws-categorie' ),
		)
	);
}
add_action( 'init', 'finest_register_taxonomies' );

/**
 * Klantverhalen (client stories) as their own post type, separate from
 * Nieuws so the two "vogue.nl-style" sections (Fase 1 briefing) don't mix
 * in one archive/category list.
 */
function finest_register_post_types() {
	register_post_type( 'klantverhaal', array(
		'labels' => array(
			'name'          => __( 'Klantverhalen', 'finest-impact' ),
			'singular_name' => __( 'Klantverhaal', 'finest-impact' ),
			'add_new_item'  => __( 'Nieuw klantverhaal toevoegen', 'finest-impact' ),
		),
		'public'       => true,
		// No native archive: the /klantverhalen/ page below (with its own
		// embedded wp:query block) IS the landing page for this post type.
		// A has_archive route at the same slug would silently win over that
		// page's rewrite rule and serve WP's bare archive template instead
		// of the real, editable page content (caught in clean-room testing:
		// the page provisioned fine, but /klantverhalen/ rendered "Archives:
		// Klantverhalen" from archive.html, not finest_klantverhalen_intro_content()).
		'has_archive'  => false,
		'rewrite'      => array( 'slug' => 'klantverhalen' ),
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-format-quote',
		'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'template'     => array(
			array( 'core/paragraph', array( 'placeholder' => 'Korte samenvatting van het klantverhaal…' ) ),
		),
	) );
}
add_action( 'init', 'finest_register_post_types' );

/**
 * Create a page if (and only if) it doesn't already exist at this exact
 * parent; safe to call on every activation.
 *
 * @param string $slug
 * @param string $title
 * @param string $content   Full block markup for post_content.
 * @param int    $parent_id
 * @param string $template  Optional "Template Name" block template slug.
 * @return int Post ID.
 */
function finest_ensure_page( $slug, $title, $content = '', $parent_id = 0, $template = '' ) {
	$existing = get_posts( array(
		'name'           => $slug,
		'post_type'      => 'page',
		'post_status'    => 'any',
		'post_parent'    => $parent_id,
		'posts_per_page' => 1,
	) );

	if ( ! empty( $existing ) ) {
		return $existing[0]->ID;
	}

	$page_id = wp_insert_post( array(
		'post_title'   => $title,
		'post_name'    => $slug,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_parent'  => $parent_id,
		'post_content' => $content,
	) );

	if ( $template && ! is_wp_error( $page_id ) ) {
		update_post_meta( $page_id, '_wp_page_template', $template );
	}

	return is_wp_error( $page_id ) ? 0 : $page_id;
}

/**
 * Create a term if it doesn't already exist. Idempotent like ensure_page().
 */
function finest_ensure_term( $name, $taxonomy, $parent_id = 0 ) {
	$existing = get_term_by( 'name', $name, $taxonomy );
	if ( $existing ) {
		return $existing->term_id;
	}
	$result = wp_insert_term( $name, $taxonomy, array( 'parent' => $parent_id ) );
	return is_wp_error( $result ) ? 0 : $result['term_id'];
}

/**
 * Create a `post` (Nieuws article) if it doesn't already exist at this
 * slug, idempotent like ensure_page()/ensure_term(). Assigns the
 * nieuws_categorie term and, when given, a sideloaded featured image —
 * both via the same ensure_* helpers already used elsewhere, so re-running
 * provisioning never duplicates a term or re-uploads a photo already in
 * the media library.
 *
 * @param array $args {
 *     @type string $slug     Required.
 *     @type string $title    Required.
 *     @type string $content  Full block markup for post_content.
 *     @type string $excerpt  Plain-text excerpt.
 *     @type string $date     'Y-m-d H:i:s', local time — backdated seed
 *                             content needs an explicit date, since
 *                             wp_insert_post() defaults to "now" and a
 *                             publish-status post with a future date
 *                             would otherwise silently become "scheduled".
 *     @type string $category nieuws_categorie term name.
 *     @type string $image    Filename under assets/img/photography/, or ''.
 * }
 * @return int Post ID, or 0.
 */
function finest_ensure_post( $args ) {
	$existing = get_posts( array(
		'name'           => $args['slug'],
		'post_type'      => 'post',
		'post_status'    => 'any',
		'posts_per_page' => 1,
	) );
	if ( ! empty( $existing ) ) {
		return $existing[0]->ID;
	}

	$post_id = wp_insert_post( array(
		'post_title'   => $args['title'],
		'post_name'    => $args['slug'],
		'post_status'  => 'publish',
		'post_type'    => 'post',
		'post_content' => isset( $args['content'] ) ? $args['content'] : '',
		'post_excerpt' => isset( $args['excerpt'] ) ? $args['excerpt'] : '',
		'post_date'    => $args['date'],
	) );
	if ( is_wp_error( $post_id ) || ! $post_id ) {
		return 0;
	}

	if ( ! empty( $args['category'] ) ) {
		$term_id = finest_ensure_term( $args['category'], 'nieuws_categorie' );
		if ( $term_id ) {
			wp_set_post_terms( $post_id, array( $term_id ), 'nieuws_categorie' );
		}
	}

	if ( ! empty( $args['image'] ) ) {
		$attachment_id = finest_ensure_photo( $args['image'], 'The Finest News — redactionele foto (' . $args['image'] . ')', 'photography' );
		if ( $attachment_id ) {
			set_post_thumbnail( $post_id, $attachment_id );
		}
	}

	return $post_id;
}

/**
 * Append a "Lees ook" paragraph linking to related articles, once. Runs
 * as a second pass after every seed article already exists (finest_
 * seed_demo_articles(), inc/content-blog.php), since the interlink needs
 * the OTHER posts' real permalinks — which don't exist yet while the first
 * one is still being created. Idempotent via a literal marker check
 * (finest-read-also) in post_content: re-running provisioning never
 * appends a second copy, and if an editor later deletes the links in
 * wp-admin, that same check finds nothing and leaves it removed — same
 * "don't fight the editor's own edits" rule as finest_resync_nieuws_pills().
 */
function finest_append_read_also( $post_id, array $related ) {
	$related = array_filter( $related );
	if ( empty( $related ) ) {
		return;
	}
	$post = get_post( $post_id );
	if ( ! $post || false !== strpos( (string) $post->post_content, 'finest-read-also' ) ) {
		return;
	}

	$links = array();
	foreach ( $related as $r ) {
		$url = get_permalink( $r['id'] );
		if ( ! $url ) {
			continue;
		}
		// Root-relative for the same reason as the category pills: saved into
		// post_content, so an absolute URL would be pinned to the activation domain.
		$url = wp_make_link_relative( $url );
		$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html( $r['title'] ) . '</a>';
	}
	if ( empty( $links ) ) {
		return;
	}

	$sentence    = 'Lees ook: ' . implode( ' en ', $links ) . '.';
	$block       = "<!-- wp:paragraph {\"className\":\"finest-read-also\"} -->\n<p class=\"finest-read-also\">{$sentence}</p>\n<!-- /wp:paragraph -->";
	$new_content = rtrim( (string) $post->post_content ) . "\n\n" . $block;

	wp_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ) );
}

/**
 * Sideload a theme asset photo into the media library as a real attachment,
 * once, so it is a normal, editable/replaceable WordPress image (not a
 * hardcoded theme-relative path baked into post_content). Idempotent: looks
 * up by exact attachment title before copying anything.
 *
 * @param string $filename Filename under /assets/img/{$subdir}/.
 * @param string $title    Attachment title (also used as the lookup key and
 *                          the default alt text).
 * @param string $subdir   Subdirectory under /assets/img/. Defaults to
 *                          'photography' for the original hero/section
 *                          photos; team headshots live under 'team'.
 * @return int Attachment ID, or 0 if the source file is missing or the
 *             upload failed.
 */
function finest_ensure_photo( $filename, $title, $subdir = 'photography' ) {
	$existing = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'title'          => $title,
		'posts_per_page' => 1,
	) );
	if ( ! empty( $existing ) ) {
		return $existing[0]->ID;
	}

	$subdir      = sanitize_file_name( $subdir );
	$filename    = sanitize_file_name( $filename );
	$source_path = FINEST_THEME_DIR . '/assets/img/' . $subdir . '/' . $filename;
	if ( ! file_exists( $source_path ) ) {
		return 0;
	}

	$filetype = wp_check_filetype( $filename, null );
	// Local file inside the theme; subdir and filename went through sanitize_file_name() above, so no path traversal.
	$upload   = wp_upload_bits( $filename, null, file_get_contents( $source_path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}

	$attachment_id = wp_insert_attachment( array(
		'post_mime_type' => $filetype['type'],
		'post_title'     => $title,
		'post_status'    => 'inherit',
	), $upload['file'] );

	if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
		return 0;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	$metadata = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
	wp_update_attachment_metadata( $attachment_id, $metadata );
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', $title );

	return $attachment_id;
}

/**
 * The actual provisioning run: pages, terms, front-page setting.
 * Safe to call more than once: every step is idempotent.
 */
/**
 * A fresh WordPress install uses plain "?p=123" permalinks. Provisioned
 * content bakes permalinks into post_content (category pills, "Lees ook"
 * interlinks), so the structure has to be pretty BEFORE that content is
 * generated, not after.
 *
 * register_taxonomy()/register_post_type() decide whether to add their
 * rewrite rules from get_option('permalink_structure') at the moment they
 * run — which on a fresh install was during `init`, i.e. before this — so
 * after switching the structure they're re-registered, otherwise term links
 * would still come out as "?nieuws_categorie=slug" in this same request.
 * (flush_rewrite_rules() in finest_on_activation() persists the rules.)
 */
function finest_ensure_pretty_permalinks() {
	global $wp_rewrite;
	if ( get_option( 'permalink_structure' ) ) {
		return;
	}
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	finest_register_taxonomies();
	finest_register_post_types();
}

/**
 * Trash WordPress's stock "Hello world!" post — but only if it is still
 * exactly the untouched default. It is the newest post on a fresh install,
 * so otherwise it takes the first slot of the Nieuws grid (no category, no
 * image) and pushes the oldest seeded article onto page two.
 *
 * Deliberately narrow: ID 1, published, never edited (post_modified still
 * equals post_date), and its body is still WordPress's own stock sentence
 * in the site's language (compared against core's translated string, since
 * a Dutch install ships "Hallo wereld!" with a Dutch body). Anything an
 * editor wrote or touched is left alone. Trashed, not deleted: recoverable
 * from wp-admin.
 */
function finest_trash_default_post() {
	$post = get_post( 1 );
	if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
		return;
	}
	if ( $post->post_date !== $post->post_modified ) {
		return;
	}
	// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- intentionally core's own string.
	$stock_body = __( 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!' );
	if ( trim( wp_strip_all_tags( $post->post_content ) ) !== $stock_body ) {
		return;
	}
	wp_trash_post( $post->ID );
}

/**
 * Trash WordPress's stock "Sample Page" — only while it is still the
 * untouched default. Otherwise a published placeholder ("This is an example
 * page…") stays live at /sample-page/ and in the sitemap of a production
 * site. Same narrow rule as finest_trash_default_post(): ID 2, a page,
 * published, never edited (post_modified still equals post_date), and still
 * on core's own default slug in the site's language. Trashed, not deleted.
 */
function finest_trash_default_sample_page() {
	$page = get_post( 2 );
	if ( ! $page || 'page' !== $page->post_type || 'publish' !== $page->post_status ) {
		return;
	}
	if ( $page->post_date !== $page->post_modified ) {
		return;
	}
	// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- intentionally core's own string.
	if ( sanitize_title( _x( 'sample-page', 'Default page slug' ) ) !== $page->post_name ) {
		return;
	}
	wp_trash_post( $page->ID );
}

function finest_provision_content() {
	require_once FINEST_THEME_DIR . '/inc/content-pages.php';
	finest_ensure_pretty_permalinks();

	// Nieuws categories from the briefing.
	$nieuws_categorieen = array(
		'Brands & People',
		'Industrie news',
		'Retail & store concepts',
		'Trends & innovatie',
		'Events & fairs',
		'Marketing',
		'Internationaal news',
	);
	foreach ( $nieuws_categorieen as $cat ) {
		finest_ensure_term( $cat, 'nieuws_categorie' );
	}

	// Every one of these pages opens with its own manually-authored <h1> in
	// post_content (so the hero styling/fi-reveal-lines treatment can differ
	// per page), so every one of them needs the 'page-onepager' template —
	// the default 'page' template also renders wp:post-title, which without
	// this produces two <h1> tags on the same page (caught in clean-room
	// testing: algemene-voorwaarden and privacyverklaring were shipping with
	// a duplicate heading).
	$home_id = finest_ensure_page( 'home', 'Home', finest_home_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'over-ons', 'Over ons', finest_over_ons_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'diensten', 'Diensten', finest_diensten_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'contact', 'Contact', finest_contact_page_content(), 0, 'page-onepager' );
	finest_ensure_page( 'algemene-voorwaarden', 'Algemene Voorwaarden', finest_algemene_voorwaarden_content(), 0, 'page-onepager' );
	finest_ensure_page( 'privacyverklaring', 'Privacyverklaring', finest_privacyverklaring_content(), 0, 'page-onepager' );
	finest_ensure_page( 'klantverhalen', 'Klantverhalen', finest_klantverhalen_intro_content(), 0, 'page-onepager' );
	finest_ensure_page( 'nieuws', 'The Finest News', finest_nieuws_intro_content(), 0, 'page-onepager' );

	// Nine seed articles for The Finest News, so the Nieuws overview and
	// every single-post template render real, cross-linked content from
	// the first activation onward instead of an empty "no articles yet"
	// state. See inc/content-blog.php's own header comment for why these
	// need to stay editable, factual placeholders rather than invented
	// claims.
	finest_trash_default_post();
	finest_trash_default_sample_page();
	finest_seed_demo_articles();

	// Homepage is a real page (so it's editable like any other page), set
	// as the static front page rather than left as the latest-posts default.
	if ( $home_id ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}

	// Deliberately NOT setting page_for_posts to the nieuws page: WordPress
	// treats a "Posts page" specially and renders the blog index in its
	// place, discarding that page's own post_content entirely. The nieuws
	// page already embeds its own wp:query block (postType "post", same
	// posts, same category support), so it gets the listing it needs while
	// staying a normal, fully-editable page like every other one here
	// (caught in clean-room testing: with page_for_posts set, visiting
	// /nieuws/ silently skipped finest_nieuws_intro_content() entirely).

	finest_ensure_primary_menu();
}

/**
 * Build the primary nav menu from the provisioned pages, only if a menu
 * isn't already assigned (avoids clobbering manual edits on re-activation).
 */
function finest_ensure_primary_menu() {
	if ( has_nav_menu( 'primary' ) ) {
		return;
	}

	$menu_name = 'Hoofdmenu';
	$menu_id   = wp_get_nav_menu_object( $menu_name );
	if ( ! $menu_id ) {
		$menu_id = wp_create_nav_menu( $menu_name );
	} else {
		$menu_id = $menu_id->term_id;
	}

	$items = array(
		'diensten'     => 'Diensten',
		'over-ons'     => 'Over ons',
		'klantverhalen' => 'Klantverhalen',
		'nieuws'       => 'Nieuws',
		'contact'      => 'Contact',
	);

	// Fetched once, outside the loop: this used to re-query every menu item
	// on every iteration (an avoidable N+1), and the menu doesn't change
	// mid-loop — nothing below this point inserts an item before the next
	// iteration reads $existing_items again except via the fresh append
	// below, which is accounted for separately.
	$existing_items = wp_get_nav_menu_items( $menu_id );

	foreach ( $items as $slug => $label ) {
		$page = get_page_by_path( $slug );
		if ( ! $page ) {
			continue;
		}
		$already_there = false;
		if ( $existing_items ) {
			foreach ( $existing_items as $item ) {
				if ( (int) $item->object_id === $page->ID ) {
					$already_there = true;
					break;
				}
			}
		}
		if ( ! $already_there ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => $label,
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page->ID,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );
		}
	}

	set_theme_mod( 'nav_menu_locations', array_merge(
		(array) get_theme_mod( 'nav_menu_locations', array() ),
		array( 'primary' => $menu_id )
	) );
}

/**
 * finest_category_pills() (inc/content-pages.php) only renders at
 * provisioning time, baked into the 'nieuws' page's post_content — so a
 * nieuws_categorie term added, renamed, or deleted afterward in wp-admin
 * would otherwise never show up in the pills row without someone manually
 * re-opening and re-saving that page in the block editor.
 *
 * This re-generates just the <div class="finest-pills"> markup and splices
 * it back into the page's existing post_content via regex, rather than
 * overwriting the whole page — the editor's own copy/heading edits
 * elsewhere on that page must survive this, not get silently clobbered by
 * a taxonomy change. Three cases:
 *  - pills block already present, terms still exist -> replace just the
 *    <div class="finest-pills"> markup in place.
 *  - pills block already present, zero terms left -> remove the whole
 *    (now-empty) wp:html block.
 *  - no pills block yet (e.g. zero terms at provisioning time, first term
 *    added afterward) -> insert a freshly-built one right before the
 *    grid's own wp:query block, which is never optional and always
 *    present on this page, so it's a stable anchor to insert against.
 * If even that anchor is missing (post_content edited into an unexpected
 * shape), this does nothing rather than guess further.
 */
function finest_resync_nieuws_pills() {
	$page = get_page_by_path( 'nieuws' );
	if ( ! $page ) {
		return;
	}

	require_once FINEST_THEME_DIR . '/inc/content-pages.php';
	$content     = $page->post_content;
	$div_pattern = '/<div class="finest-pills">.*?<\/div>/s';
	$pills       = finest_category_pills( 'nieuws_categorie' );

	if ( $pills ) {
		if ( preg_match( $div_pattern, $content ) ) {
			if ( ! preg_match( $div_pattern, $pills, $fresh ) ) {
				return;
			}
			$new_content = preg_replace( $div_pattern, $fresh[0], $content, 1 );
		} else {
			// No pills block exists yet on this page -- insert one, built
			// the same way finest_nieuws_intro_content() builds it, right
			// before the grid's wp:query block.
			$wrap = finest_category_pills_wrap( 'nieuws_categorie' );
			if ( ! $wrap || false === strpos( $content, '<!-- wp:query ' ) ) {
				return;
			}
			$new_content = preg_replace(
				'/<!-- wp:query /',
				$wrap . "\n\n" . '<!-- wp:query ',
				$content,
				1
			);
		}
	} else {
		// No terms left at all: remove the now-empty pills block (including
		// its wp:html block comments) if it's still there.
		$block_pattern = '/<!-- wp:html -->\s*<div class="finest-pills">.*?<\/div>\s*<!-- \/wp:html -->/s';
		if ( ! preg_match( $block_pattern, $content ) ) {
			return;
		}
		$new_content = preg_replace( $block_pattern, '', $content, 1 );
	}

	if ( null !== $new_content && $new_content !== $content ) {
		wp_update_post( array( 'ID' => $page->ID, 'post_content' => $new_content ) );
	}
}

/**
 * Fires on every nieuws_categorie create/edit/delete (and, harmlessly, on
 * every other taxonomy's term changes too — filtered out below). During
 * the very first theme activation this fires once per category in
 * finest_provision_content() before the 'nieuws' page itself exists yet;
 * finest_resync_nieuws_pills() simply no-ops in that case since
 * get_page_by_path() finds nothing, so the page's own provisioning call
 * (which already includes a freshly-built pills row) is unaffected.
 */
function finest_resync_nieuws_pills_on_term_change( $term_id, $tt_id, $taxonomy ) {
	if ( 'nieuws_categorie' !== $taxonomy ) {
		return;
	}
	finest_resync_nieuws_pills();
}
add_action( 'created_term', 'finest_resync_nieuws_pills_on_term_change', 10, 3 );
add_action( 'edited_term', 'finest_resync_nieuws_pills_on_term_change', 10, 3 );
add_action( 'delete_term', 'finest_resync_nieuws_pills_on_term_change', 10, 3 );

/**
 * Runs on theme activation. Permalinks are fixed here too: a fresh WP
 * install defaults to plain "?p=123" links, which silently sends every
 * pretty internal link ("/over-ons/") back to the homepage instead of
 * a 404 (Fase 5's single most important gotcha).
 */
function finest_on_activation() {
	finest_run_provisioning( true );
}
add_action( 'after_switch_theme', 'finest_on_activation' );

/**
 * Run provisioning under a lock. WordPress clears its "theme was switched"
 * marker only AFTER after_switch_theme has run, so while provisioning is busy
 * (a second or two) any concurrent request (the wp-cron loopback WordPress
 * itself fires, another visitor, the admin_init safety net below) would start
 * a second copy, and two copies racing each other create every page and post
 * twice ("contact-2"). Core's own upgrader lock (an atomic INSERT IGNORE into
 * wp_options) lets exactly one request through; the others skip.
 *
 * @param bool $force Run even when the content was provisioned before (theme
 *                    re-activation: the ensure_* helpers are idempotent).
 */
function finest_run_provisioning( $force = false ) {
	if ( ! $force && get_option( 'finest_content_provisioned' ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	if ( ! WP_Upgrader::create_lock( 'finest_provisioning', 120 ) ) {
		return; // another request is already doing it
	}
	try {
		finest_provision_content();
		update_option( 'finest_content_provisioned', '1' );
		flush_rewrite_rules();
	} finally {
		WP_Upgrader::release_lock( 'finest_provisioning' );
	}
}

/**
 * Safety net: if some other activation order left provisioning unflagged
 * (e.g. a dependent plugin activated after the theme), run it once from
 * the admin. Never runs before init, so custom taxonomies are already
 * registered by the time this touches them.
 */
function finest_provision_content_once() {
	// admin_init also fires for logged-out requests to admin-ajax.php, so only
	// an administrator may trigger content creation.
	if ( ! current_user_can( 'switch_themes' ) ) {
		return;
	}
	finest_run_provisioning( false );
}
add_action( 'admin_init', 'finest_provision_content_once' );
