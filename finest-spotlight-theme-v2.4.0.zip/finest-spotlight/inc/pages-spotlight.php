<?php
/**
 * Spotlight compositions for the sub pages: Over ons, Diensten, Contact,
 * Klantverhalen and Nieuws (plus the page header used by the legal pages and
 * the templates).
 *
 * Same building blocks as the home page (inc/home-spotlight.php): a dark page
 * header (with or without a reeded photo), intro columns, split sections,
 * a black process band and the closing band. Everything is core blocks, written
 * exactly as each block's save() output so the editor never reports invalid
 * content.
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/home-spotlight.php';

/**
 * Dark page header. With a photo it is the home hero in a shorter version
 * (text left, reeded photo right); without one it is a full-width dark band.
 *
 * @param string $eyebrow      Small label above the title.
 * @param string $title_html   Inner HTML of the H1 (may contain <br>).
 * @param string $lead_html    Plain text/HTML for the lead paragraph ('' = none).
 * @param int    $photo_id     Attachment ID ( 0 = text-only band ).
 * @param string $buttons_html Button blocks ( '' = none ).
 * @param string $modifier     Extra class, e.g. 'fi-hero--legal'.
 */
function finest_spotlight_hero( $eyebrow, $title_html, $lead_html = '', $photo_id = 0, $buttons_html = '', $modifier = '' ) {
	$media = $photo_id ? finest_spotlight_image( $photo_id, 'fi-hero__media', '' ) : '';
	$class = trim( 'fi-hero fi-hero--page' . ( $media ? '' : ' fi-hero--text' ) . ' ' . $modifier );
	$eye   = esc_html( $eyebrow );
	$lead  = '' === $lead_html ? '' : "<!-- wp:paragraph {\"className\":\"fi-hero__sub\"} -->\n<p class=\"fi-hero__sub\">{$lead_html}</p>\n<!-- /wp:paragraph -->\n\n";
	$btns  = '' === $buttons_html ? '' : "<!-- wp:buttons {\"className\":\"fi-hero__buttons\"} -->\n<div class=\"wp-block-buttons fi-hero__buttons\">\n{$buttons_html}\n</div>\n<!-- /wp:buttons -->\n\n";
	return <<<HTML
<!-- wp:group {"align":"full","backgroundColor":"nacht","textColor":"linnen","className":"{$class}"} -->
<div class="wp-block-group alignfull {$class} has-linnen-color has-nacht-background-color has-text-color has-background">

<!-- wp:group {"className":"fi-hero__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-hero__text">

<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">{$eye}</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-hero__title fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-hero__title fi-reveal-lines">{$title_html}</h1>
<!-- /wp:heading -->

{$lead}{$btns}</div>
<!-- /wp:group -->

{$media}

</div>
<!-- /wp:group -->
HTML;
}

/**
 * Black closing band with the big wordmark (same as the end of the home page).
 *
 * @param string $heading  H2 text.
 * @param string $text     Paragraph text (plain, escaped here); '' = none.
 * @param string $btn_html Button block markup.
 */
function finest_spotlight_close_band( $heading, $text, $btn_html ) {
	$h = esc_html( $heading );
	$p = '' === $text ? '' : "<!-- wp:paragraph {\"fontSize\":\"medium\"} -->\n<p class=\"has-medium-font-size\">" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->\n\n";
	return <<<HTML
<!-- wp:group {"align":"full","backgroundColor":"zwart","textColor":"linnen","className":"fi-close is-style-fi-dark-section"} -->
<div class="wp-block-group alignfull fi-close is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background">

<!-- wp:group {"className":"fi-close__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-close__text">

<!-- wp:heading {"level":2,"fontSize":"display","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-display-font-size fi-reveal-lines">{$h}</h2>
<!-- /wp:heading -->

{$p}<!-- wp:buttons -->
<div class="wp-block-buttons">
{$btn_html}
</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="fi-close__mark" aria-hidden="true"><span class="finest-lockup finest-lockup--big"><span class="ll-the">the</span><span class="ll-finest">finest</span><span class="ll-impact">impact</span></span></div>
<!-- /wp:html -->

</div>
<!-- /wp:group -->
HTML;
}

/**
 * Two intro columns: a lead statement (with optional extras) left, text right.
 *
 * @param string $left_html  Block markup for the left column.
 * @param string $right_html Block markup for the right column.
 * @param string $modifier   Extra class on the outer group.
 */
function finest_spotlight_intro( $left_html, $right_html, $modifier = '' ) {
	$class = trim( 'fi-intro ' . $modifier );
	return <<<HTML
<!-- wp:group {"align":"full","className":"{$class}","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull {$class}">

<!-- wp:columns {"align":"wide","className":"fi-intro__cols"} -->
<div class="wp-block-columns alignwide fi-intro__cols">

<!-- wp:column -->
<div class="wp-block-column">

{$left_html}

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">

{$right_html}

</div>
<!-- /wp:column -->

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->
HTML;
}

/** A lead paragraph (large) for the left intro column. */
function finest_spotlight_lead( $html ) {
	return "<!-- wp:paragraph {\"className\":\"fi-intro__lead\"} -->\n<p class=\"fi-intro__lead\">{$html}</p>\n<!-- /wp:paragraph -->";
}

/** A body paragraph. */
function finest_spotlight_p( $html, $medium = false ) {
	if ( $medium ) {
		return "<!-- wp:paragraph {\"fontSize\":\"medium\"} -->\n<p class=\"has-medium-font-size\">{$html}</p>\n<!-- /wp:paragraph -->";
	}
	return "<!-- wp:paragraph -->\n<p>{$html}</p>\n<!-- /wp:paragraph -->";
}

/** Buttons wrapper around button markup. */
function finest_spotlight_buttons( $buttons_html ) {
	return "<!-- wp:buttons -->\n<div class=\"wp-block-buttons\">\n{$buttons_html}\n</div>\n<!-- /wp:buttons -->";
}

/* ------------------------------------------------------------------------
 * Over ons
 * ---------------------------------------------------------------------- */
function finest_over_ons_page_content() {
	$hero_id  = finest_ensure_photo( 'wat-is.jpg', 'Spotlight: portret met heldere bril', 'spotlight' );
	$split_id = finest_ensure_photo( 'opticiens.jpg', 'Spotlight: winkelinterieur met lounge', 'spotlight' );

	$hero = finest_spotlight_hero(
		'Over ons',
		'Marketing first.<br>Technology powered.<br>Human controlled.',
		'Marketing wordt steeds belangrijker, maar voor veel ondernemers ook steeds moeilijker om goed te organiseren. Er zijn meer kanalen, meer data, meer technologie en meer mogelijkheden dan ooit. Maar tijd en capaciteit groeien niet automatisch mee.',
		$hero_id
	);

	$intro = finest_spotlight_intro(
		finest_spotlight_lead( 'Met meer dan 20 jaar ervaring in marketing en ruime kennis van de optiekbranche kennen we die werkelijkheid van heel dichtbij.' ),
		finest_spotlight_p( 'We weten hoe belangrijk merk, strategie, creativiteit en commercieel inzicht zijn. We weten ook hoe vaak goede marketing blijft liggen omdat de dagelijkse praktijk voorgaat.' ) . "\n\n" .
		finest_spotlight_p( '<strong>Daarom hebben we The Finest Impact ontwikkeld.</strong>', true )
	);

	$split_text = <<<'HTML'
<!-- wp:paragraph {"className":"fi-eyebrow fi-eyebrow--dark"} -->
<p class="fi-eyebrow fi-eyebrow--dark">Onze visie</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Marketing expertise en technologie horen bij elkaar</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Technologie kan veel, maar zonder richting, context en commercieel inzicht ontstaat vooral meer output. Daar geloven wij niet in.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Wij geloven in marketing die consistent is en klopt. Marketing die past bij je merk. Marketing die inspeelt op wat klanten nodig hebben. Marketing die zichtbaar maakt waar je voor staat. En marketing die uiteindelijk écht iets moet opleveren, namelijk sales.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daarom combineren we menselijke expertise met technologie. De mens bepaalt de strategie, bewaakt de kwaliteit en maakt de keuzes. The Finest Impact zorgt voor snelheid, structuur en uitvoeringskracht. Samen ontstaat marketing die efficiënt en consistent wordt en zorgt voor groei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Own your spotlight.</strong></p>
<!-- /wp:paragraph -->
HTML;
	$split      = finest_spotlight_split( $split_id, 'right', $split_text, '' );

	$team  = "<!-- wp:group {\"align\":\"full\",\"className\":\"fi-intro fi-team\",\"layout\":{\"type\":\"constrained\"}} -->\n";
	$team .= '<div class="wp-block-group alignfull fi-intro fi-team">' . "\n\n";
	$team .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Ontmoet ons team</h2>\n<!-- /wp:heading -->\n\n";
	$team .= "<!-- wp:paragraph -->\n<p>De mensen achter The Finest Impact.</p>\n<!-- /wp:paragraph -->\n\n";
	$team .= "<!-- wp:columns {\"align\":\"wide\"} -->\n<div class=\"wp-block-columns alignwide\">\n";
	$team .= finest_team_member_block( 'Karin Boon', 'Co-founder & Head of Growth', '+31 6 48 46 99 24', 'https://www.linkedin.com/in/karinboon/', finest_ensure_photo( 'karin.jpg', 'Karin Boon', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Manon van Gasteren', 'Co-founder & Head of Marketing', '+31 6 22 80 82 36', 'https://www.linkedin.com/in/manonvangasteren/', finest_ensure_photo( 'manon.jpg', 'Manon van Gasteren', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Ben Verschuur', 'Co-founder & Head of Technology', '+31 6 13 01 32 66', 'https://www.linkedin.com/in/benverschuur/', finest_ensure_photo( 'ben.jpg', 'Ben Verschuur', 'team' ) ) . "\n";
	$team .= "</div>\n<!-- /wp:columns -->\n\n</div>\n<!-- /wp:group -->";

	$close = finest_spotlight_close_band(
		'Own your spotlight.',
		'The Finest Impact laat je marketing presteren.',
		finest_spotlight_button( 'Maak kennis met The Finest Impact', 'mailto:info@thefinestimpact.com' )
	);

	return implode( "\n\n", array( $hero, $intro, $split, $team, $close ) );
}

/* ------------------------------------------------------------------------
 * Diensten
 * ---------------------------------------------------------------------- */
function finest_diensten_page_content() {
	$hero_id = finest_ensure_photo( 'opticiens.jpg', 'Spotlight: winkelinterieur met lounge', 'spotlight' );

	$hero = finest_spotlight_hero(
		'Diensten',
		'Van strategie naar marketing die presteert',
		'Goede marketing begint niet met technologie. Het begint met weten waar je staat, wie je klant is, waar je kansen liggen en wat nodig is om te groeien.',
		$hero_id,
		finest_spotlight_button( 'Plan een kennismaking', '/contact/', false, true )
	);

	$intro = finest_spotlight_intro(
		finest_spotlight_lead( 'Met meer dan 20 jaar ervaring in marketing en ruime kennis van de optiekbranche weten we hoe marketing werkt, maar vooral ook wat er in de praktijk nodig is om die marketing daadwerkelijk te laten presteren.' ) . "\n\n" .
		finest_spotlight_p( '<strong>Menselijke expertise bepaalt de richting. Technologie zorgt voor snelheid, capaciteit en uitvoering.</strong>', true ),
		finest_spotlight_p( 'Daarom start The Finest Impact altijd vanuit jouw bedrijf. We brengen je marketing in kaart, bepalen samen de juiste richting, versterken wat nog ontbreekt en richten daarna jouw eigen marketingomgeving in.' ) . "\n\n" .
		finest_spotlight_p( 'Vanaf dat moment werk je structureel samen met The Finest Impact, onze marketingexpertise en gespecialiseerde marketing agents.' )
	);

	$stappen = array(
		array( 'We brengen de situatie in kaart', 'We starten met een strategische marketing sessie. Daarin kijken we naar je huidige marketing, doelgroep, positionering, klantreis, zichtbaarheid en commerciële ambities. Het resultaat is een concrete marketing roadmap.' ),
		array( 'We versterken wat nog ontbreekt', 'Op basis van die marketing roadmap bepalen we wat eerst beter moet. Dat kan bijvoorbeeld gaan om positionering, branding, contentstrategie, social media, campagnes, SEO, lokale vindbaarheid of zichtbaarheid in AI.' ),
		array( 'We richten The Finest Impact in', 'Zodra de marketingbasis staat, bouwen we jouw eigen marketingomgeving. We vertalen je merk, doelgroep, tone of voice, aanbod, doelen en kennis naar The Finest Impact en richten de juiste agents, workflows, kwaliteitscontrole en koppelingen in.' ),
		array( 'We gaan ermee werken en optimaliseren', 'Daarna wordt The Finest Impact onderdeel van je dagelijkse marketing. Je team gebruikt de omgeving voor onder andere campagnes, content, klantcommunicatie, zichtbaarheid en analyse. Jullie kennis blijft leidend, terwijl The Finest Impact helpt om sneller, consistent en professioneler te werken. Zo ontstaat stap voor stap een marketingaanpak die niet alleen slimmer is ingericht, maar ook structureel blijft werken.' ),
	);

	$process  = "<!-- wp:group {\"align\":\"full\",\"backgroundColor\":\"zwart\",\"textColor\":\"linnen\",\"className\":\"fi-process is-style-fi-dark-section\",\"layout\":{\"type\":\"constrained\"}} -->\n";
	$process .= '<div class="wp-block-group alignfull fi-process is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background">' . "\n\n";
	$process .= "<!-- wp:paragraph {\"className\":\"fi-eyebrow\"} -->\n<p class=\"fi-eyebrow\">In vier stappen</p>\n<!-- /wp:paragraph -->\n\n";
	$process .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\",\"className\":\"fi-reveal-lines\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size fi-reveal-lines\">Hoe gaan we te werk?</h2>\n<!-- /wp:heading -->\n\n";
	$process .= "<!-- wp:paragraph {\"className\":\"fi-process__intro\"} -->\n<p class=\"fi-process__intro\">We werken in vier duidelijke stappen. Zo bouwen we niet zomaar iets, maar zorgen we dat iedere keuze aansluit op jouw organisatie, ambities en marketingdoelen.</p>\n<!-- /wp:paragraph -->\n\n";
	$process .= "<!-- wp:columns {\"align\":\"wide\",\"className\":\"fi-process__cols\"} -->\n<div class=\"wp-block-columns alignwide fi-process__cols\">\n\n";
	foreach ( $stappen as $i => $stap ) {
		$num      = sprintf( '%02d', $i + 1 );
		$title    = esc_html( $stap[0] );
		$body     = esc_html( $stap[1] );
		$process .= "<!-- wp:column -->\n<div class=\"wp-block-column\">\n\n";
		$process .= "<!-- wp:paragraph {\"className\":\"fi-process__num\"} -->\n<p class=\"fi-process__num\">{$num}</p>\n<!-- /wp:paragraph -->\n\n";
		$process .= "<!-- wp:heading {\"level\":3,\"fontSize\":\"medium\"} -->\n<h3 class=\"wp-block-heading has-medium-font-size\">{$title}</h3>\n<!-- /wp:heading -->\n\n";
		$process .= "<!-- wp:paragraph {\"fontSize\":\"small\"} -->\n<p class=\"has-small-font-size\">{$body}</p>\n<!-- /wp:paragraph -->\n\n";
		$process .= "</div>\n<!-- /wp:column -->\n\n";
	}
	$process .= "</div>\n<!-- /wp:columns -->\n\n</div>\n<!-- /wp:group -->";

	$close = finest_spotlight_close_band(
		'Plan een kennismaking.',
		'Tijdens een kennismaking kijken we eerst naar je huidige situatie en ambities.',
		finest_spotlight_button( 'Plan een kennismaking', '/contact/' )
	);

	return implode( "\n\n", array( $hero, $intro, $process, finest_faq_block(), $close ) );
}

/* ------------------------------------------------------------------------
 * Contact
 * ---------------------------------------------------------------------- */
function finest_contact_page_content() {
	$hero_id = finest_ensure_photo( 'probleem.jpg', 'Spotlight: portret achter glas', 'spotlight' );

	$hero = finest_spotlight_hero(
		'Contact',
		'Plan een kennismaking',
		'Tijdens een kennismaking kijken we eerst naar je huidige situatie en ambities. Daarna kunnen we heel concreet aangeven welke aanpak bij jouw organisatie past.',
		$hero_id
	);

	$body = <<<'HTML'
<!-- wp:group {"align":"full","className":"fi-intro tfi-contact","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull fi-intro tfi-contact">

<!-- wp:columns {"align":"wide","className":"tfi-contact-grid"} -->
<div class="wp-block-columns alignwide tfi-contact-grid">

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Stuur een bericht</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[finest_contact_form]
<!-- /wp:shortcode -->

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Direct contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Karin Boon, Head of Growth<br>+31 6 48 46 99 24</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Manon van Gasteren, Head of Marketing<br>+31 6 22 80 82 36</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->
HTML;
	return $hero . "\n\n" . $body;
}

/* ------------------------------------------------------------------------
 * Klantverhalen
 * ---------------------------------------------------------------------- */
function finest_klantverhalen_intro_content() {
	$hero_id = finest_ensure_photo( 'story-interview.jpg', 'Spotlight: klantverhaal, interview', 'spotlight' );

	$hero = finest_spotlight_hero(
		'Klantverhalen',
		'Wat gebeurt er wanneer marketing wél structureel wordt?',
		'Daar willen we niet alleen over vertellen. We willen het laten zien.',
		$hero_id
	);

	$intro = finest_spotlight_intro(
		finest_spotlight_lead( 'In onze klantverhalen delen we hoe opticiens The Finest Impact gebruiken, wat er verandert in hun dagelijkse marketing en welk resultaat dat oplevert.' ),
		finest_spotlight_p( 'Van tijdsbesparing en meer zichtbaarheid tot betere campagnes, meer klantactivatie en commerciële groei.' )
	);

	// inherit:false on purpose: this is a normal Page, so there is no main
	// post query to inherit (inherit:true would silently render zero posts).
	$grid = <<<'HTML'
<!-- wp:group {"align":"full","className":"finest-stories finest-stories--archive","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull finest-stories finest-stories--archive">

<!-- wp:query {"queryId":1,"query":{"postType":"klantverhaal","perPage":12,"orderBy":"date","order":"desc","inherit":false},"align":"wide","className":"fi-stories-query"} -->
<div class="wp-block-query alignwide fi-stories-query">

<!-- wp:post-template {"className":"finest-stories-grid"} -->
<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"finest-card","aspectRatio":"4/5","className":"finest-stories__media"} /-->
<!-- wp:post-terms {"term":"klantverhaal_onderwerp","className":"finest-stories__label"} /-->
<!-- wp:post-title {"isLink":true,"level":2,"className":"finest-stories__post-title"} /-->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"className":"finest-no-results"} -->
<p class="finest-no-results">Nog geen klantverhalen gepubliceerd. Zodra er verhalen worden toegevoegd in wp-admin, verschijnen ze hier automatisch.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"className":"finest-pagination"} -->
<!-- wp:query-pagination-previous {"label":"Vorige"} /-->
<!-- wp:query-pagination-numbers /-->
<!-- wp:query-pagination-next {"label":"Volgende"} /-->
<!-- /wp:query-pagination -->

</div>
<!-- /wp:query -->

</div>
<!-- /wp:group -->
HTML;

	return implode( "\n\n", array( $hero, $intro, $grid ) );
}

/* ------------------------------------------------------------------------
 * Nieuws
 * ---------------------------------------------------------------------- */
function finest_nieuws_intro_content() {
	$hero_id = finest_ensure_photo( 'news-hero-interior.jpg', 'Spotlight: nieuws, winkelinterieur', 'spotlight' );

	$hero = finest_spotlight_hero(
		'The Finest News',
		'Blijf voor op wat er in de optiek gebeurt',
		'Voor opticiens die niet willen volgen, maar vooruit willen kijken.',
		$hero_id
	);

	$list = <<<'HTML'
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Welke ontwikkelingen zijn interessant?</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Welke trends moet je in de gaten houden?</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Waar liggen kansen voor jouw winkel, merk of marketing?</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
HTML;

	$intro = finest_spotlight_intro(
		finest_spotlight_lead( 'De optiekwereld verandert snel. Nieuwe merken komen op, retailconcepten veranderen, technologie ontwikkelt zich en consumenten verwachten steeds meer.' ) . "\n\n" .
		finest_spotlight_p( '<strong>The Finest News. Voor opticiens die niet willen volgen, maar vooruit willen kijken.</strong>', true ),
		finest_spotlight_p( 'The Finest News volgt wat er gebeurt in Nederland én daarbuiten. Van nieuwe eyewear merken en opvallende winkels tot internationale trends, technologie, AI, events, marketing en ontwikkelingen in de markt.' ) . "\n\n" .
		finest_spotlight_p( 'Maar we brengen niet alleen het nieuws. We kijken vooral naar de vraag: wat betekent dit voor jou als opticien?' ) . "\n\n" . $list
	);

	$pills_wrap = finest_category_pills_wrap( 'nieuws_categorie' );
	$pills_wrap = $pills_wrap ? $pills_wrap . "\n\n" : '';

	// inherit:false (stated explicitly so nobody "helpfully" adds inherit:true
	// back): a normal static Page has no main post query to inherit.
	$grid = <<<'HTML'
<!-- wp:query {"queryId":2,"query":{"postType":"post","perPage":9,"orderBy":"date","order":"desc","inherit":false},"align":"wide","className":"finest-blog-grid"} -->
<div class="wp-block-query alignwide finest-blog-grid">

<!-- wp:post-template {"className":"finest-blog-grid__track"} -->
<!-- wp:group {"className":"finest-blog-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-blog-card">
<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"finest-card","className":"finest-blog-card__media"} /-->
<!-- wp:post-terms {"term":"nieuws_categorie","fontSize":"label","className":"finest-blog-card__cat"} /-->
<!-- wp:post-title {"isLink":true,"level":2,"fontSize":"medium","className":"finest-blog-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":18,"className":"finest-blog-card__excerpt"} /-->
<!-- wp:post-date {"fontSize":"label","className":"finest-blog-card__date"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"className":"finest-no-results"} -->
<p class="finest-no-results">Nog geen artikelen gepubliceerd. Nieuwe berichten verschijnen hier automatisch, inclusief RSS-feed.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"className":"finest-pagination"} -->
<!-- wp:query-pagination-previous {"label":"Vorige"} /-->
<!-- wp:query-pagination-numbers /-->
<!-- wp:query-pagination-next {"label":"Volgende"} /-->
<!-- /wp:query-pagination -->

</div>
<!-- /wp:query -->
HTML;

	$news  = "<!-- wp:group {\"align\":\"full\",\"className\":\"fi-intro fi-news\",\"layout\":{\"type\":\"constrained\"}} -->\n";
	$news .= '<div class="wp-block-group alignfull fi-intro fi-news">' . "\n\n" . $pills_wrap . $grid . "\n\n</div>\n<!-- /wp:group -->";

	return implode( "\n\n", array( $hero, $intro, $news ) );
}
