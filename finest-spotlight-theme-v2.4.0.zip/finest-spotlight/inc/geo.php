<?php
/**
 * GEO (generative engine optimisation) and extra SEO, on top of inc/seo.php.
 *
 * What it adds, all derived from content that already exists on the site
 * (nothing is invented; facts the business has to supply are settings):
 *
 *  - One JSON-LD @graph per page: WebSite (with sitelinks search box), a WebPage
 *    of the right subtype (AboutPage, ContactPage, CollectionPage), FAQPage built
 *    from the page's own FAQ blocks, and Person entries for the founders on the
 *    Over ons page. The Organization (ProfessionalService in seo.php) is
 *    referenced by @id, so every answer engine sees one consistent entity.
 *  - /llms.txt: a short Markdown map of the site for AI assistants.
 *  - robots.txt rules for AI crawlers (ChatGPT, Claude, Perplexity, Google AI,
 *    Apple Intelligence), switchable in Settings > General.
 *  - hreflang + x-default, and the max-snippet / max-video-preview robots hints
 *    (max-image-preview comes from core).
 *  - /.well-known/security.txt (RFC 9116).
 *
 * Everything is skipped when an SEO plugin is active (it does this job) and on
 * sites that are not public (teaser mode, "discourage search engines").
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------------
 * Settings (Settings > General)
 * ---------------------------------------------------------------------- */

/** Crawler user agents the AI switch applies to. */
function finest_geo_ai_agents() {
	return (array) apply_filters(
		'finest_geo_ai_agents',
		array(
			'GPTBot',
			'OAI-SearchBot',
			'ChatGPT-User',
			'ClaudeBot',
			'Claude-SearchBot',
			'Claude-User',
			'PerplexityBot',
			'Perplexity-User',
			'Google-Extended',
			'Applebot-Extended',
		)
	);
}

/** True when AI crawlers are allowed (default). */
function finest_geo_ai_allowed() {
	return '0' !== (string) get_option( 'finest_ai_crawlers', '1' );
}

/** Profile URLs of the company (one per line in the settings), validated. */
function finest_geo_same_as() {
	$raw  = (string) get_option( 'finest_company_sameas', '' );
	$urls = array();
	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$url = esc_url_raw( trim( $line ), array( 'https' ) );
		if ( $url ) {
			$urls[] = $url;
		}
	}
	return array_values( array_unique( $urls ) );
}

function finest_geo_register_settings() {
	register_setting(
		'general',
		'finest_ai_crawlers',
		array(
			'type'              => 'string',
			'default'           => '1',
			'sanitize_callback' => static function ( $value ) {
				return $value ? '1' : '0';
			},
		)
	);
	register_setting(
		'general',
		'finest_company_sameas',
		array(
			'type'              => 'string',
			'sanitize_callback' => static function ( $value ) {
				$clean = array();
				foreach ( preg_split( '/\r\n|\r|\n/', (string) $value ) as $line ) {
					$url = esc_url_raw( trim( $line ), array( 'https' ) );
					if ( $url ) {
						$clean[] = $url;
					}
				}
				return implode( "\n", array_unique( $clean ) );
			},
		)
	);

	add_settings_field(
		'finest_ai_crawlers',
		__( 'AI-zoekmachines', 'finest-spotlight' ),
		static function () {
			printf(
				'<label><input type="checkbox" id="finest_ai_crawlers" name="finest_ai_crawlers" value="1" %s> %s</label><p class="description">%s</p>',
				checked( finest_geo_ai_allowed(), true, false ),
				esc_html__( 'ChatGPT, Claude, Perplexity, Google AI en Apple mogen de site lezen en citeren', 'finest-spotlight' ),
				esc_html__( 'Zet dit uit om ze via robots.txt te weren. Staat er op de server een echt bestand robots.txt, dan gaat dat voor.', 'finest-spotlight' )
			);
		},
		'general',
		'default'
	);
	add_settings_field(
		'finest_company_sameas',
		__( 'Bedrijfsprofielen (LinkedIn e.d.)', 'finest-spotlight' ),
		static function () {
			printf(
				'<textarea class="large-text code" rows="3" id="finest_company_sameas" name="finest_company_sameas" autocomplete="off">%s</textarea><p class="description">%s</p>',
				esc_textarea( (string) get_option( 'finest_company_sameas', '' ) ),
				esc_html__( 'Eén https-adres per regel (LinkedIn-bedrijfspagina, Instagram, Google Bedrijfsprofiel). Zoekmachines en AI-assistenten gebruiken dit om het bedrijf te herkennen.', 'finest-spotlight' )
			);
		},
		'general',
		'default'
	);
}
add_action( 'admin_init', 'finest_geo_register_settings' );

/* ------------------------------------------------------------------------
 * Gate: only on public sites, only when no SEO plugin does the job
 * ---------------------------------------------------------------------- */
function finest_geo_active() {
	if ( function_exists( 'finest_seo_plugin_active' ) && finest_seo_plugin_active() ) {
		return false;
	}
	if ( ! get_option( 'blog_public' ) ) {
		return false;
	}
	if ( function_exists( 'finest_teaser_settings' ) ) {
		$teaser = finest_teaser_settings();
		if ( ! empty( $teaser['enabled'] ) ) {
			return false;
		}
	}
	return true;
}

/* ------------------------------------------------------------------------
 * JSON-LD @graph
 * ---------------------------------------------------------------------- */

/**
 * Site description for machines: the tagline, unless it is empty or the
 * WordPress default, in which case the summary of the home page.
 */
function finest_geo_site_description() {
	$tagline = trim( (string) get_bloginfo( 'description' ) );
	$default = array( '', 'Just another WordPress site', 'Een nieuwe WordPress site' );
	if ( ! in_array( $tagline, $default, true ) ) {
		return $tagline;
	}
	$home = (int) get_option( 'page_on_front' );
	if ( $home ) {
		$excerpt = trim( wp_strip_all_tags( get_the_excerpt( $home ) ) );
		if ( '' !== $excerpt ) {
			return $excerpt;
		}
	}
	return '';
}

/** Stable @id values, so the nodes can reference each other. */
function finest_geo_ids() {
	return array(
		'org'     => home_url( '/#organization' ),
		'website' => home_url( '/#website' ),
	);
}

/** FAQ entries found in the page's own details blocks: array of array( question, answer ). */
function finest_geo_faq_from_content( $content ) {
	$items = array();
	if ( false === strpos( $content, 'wp-block-details' ) ) {
		return $items;
	}
	if ( preg_match_all( '/<details[^>]*>\s*<summary[^>]*>(.*?)<\/summary>(.*?)<\/details>/is', $content, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $m ) {
			$question = trim( wp_specialchars_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES ) );
			$answer   = trim( preg_replace( '/\s+/', ' ', wp_specialchars_decode( wp_strip_all_tags( preg_replace( '/<!--.*?-->/s', '', $m[2] ) ), ENT_QUOTES ) ) );
			if ( '' !== $question && '' !== $answer ) {
				$items[] = array( $question, $answer );
			}
		}
	}
	return array_slice( $items, 0, 30 );
}

/** Team members (name, role, LinkedIn) from the cards on the Over ons page. */
function finest_geo_people_from_content( $content ) {
	$people = array();
	if ( false === strpos( $content, 'linkedin.com' ) ) {
		return $people;
	}
	$pattern = '/<h3[^>]*>([^<]+)<\/h3>\s*(?:<!--.*?-->\s*)*<p[^>]*>([^<]+)<\/p>.*?href="(https:\/\/(?:www\.)?linkedin\.com\/[^"]+)"/is';
	if ( preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $m ) {
			$people[] = array(
				'name'     => trim( wp_specialchars_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES ) ),
				'role'     => trim( wp_specialchars_decode( wp_strip_all_tags( $m[2] ), ENT_QUOTES ) ),
				'linkedin' => esc_url_raw( $m[3], array( 'https' ) ),
			);
		}
	}
	return array_slice( $people, 0, 12 );
}

/** schema.org type of the current page. */
function finest_geo_page_type( $post ) {
	if ( is_search() ) {
		return 'SearchResultsPage';
	}
	if ( $post instanceof WP_Post && 'page' === $post->post_type ) {
		$map = array(
			'over-ons'      => 'AboutPage',
			'contact'       => 'ContactPage',
			'nieuws'        => 'CollectionPage',
			'klantverhalen' => 'CollectionPage',
		);
		if ( isset( $map[ $post->post_name ] ) ) {
			return $map[ $post->post_name ];
		}
	}
	if ( is_archive() ) {
		return 'CollectionPage';
	}
	return 'WebPage';
}

/**
 * Build the graph for the current request. Separate from the printing
 * function so it can be tested and filtered.
 */
function finest_geo_graph() {
	$ids       = finest_geo_ids();
	$canonical = finest_seo_canonical();
	$image     = finest_seo_image();
	$post      = is_singular() ? get_queried_object() : null;
	$lang      = str_replace( '_', '-', finest_site_locale() );

	$website = array(
		'@type'           => 'WebSite',
		'@id'             => $ids['website'],
		'url'             => home_url( '/' ),
		'name'            => get_bloginfo( 'name' ),
		'description'     => finest_geo_site_description(),
		'inLanguage'      => $lang,
		'publisher'       => array( '@id' => $ids['org'] ),
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => array(
				'@type'       => 'EntryPoint',
				'urlTemplate' => home_url( '/?s={search_term_string}' ),
			),
			'query-input' => 'required name=search_term_string',
		),
	);

	$page = array(
		'@type'              => finest_geo_page_type( $post ),
		'@id'                => $canonical . '#webpage',
		'url'                => $canonical,
		'name'               => finest_seo_title(),
		'description'        => finest_seo_description(),
		'inLanguage'         => $lang,
		'isPartOf'           => array( '@id' => $ids['website'] ),
		'about'              => array( '@id' => $ids['org'] ),
		'primaryImageOfPage' => array(
			'@type' => 'ImageObject',
			'url'   => $image['url'],
		),
	);
	if ( $post instanceof WP_Post ) {
		$page['datePublished'] = get_the_date( 'c', $post );
		$page['dateModified']  = get_the_modified_date( 'c', $post );
	}

	$graph = array( $website, $page );

	if ( $post instanceof WP_Post && 'page' === $post->post_type ) {
		$faq = finest_geo_faq_from_content( $post->post_content );
		if ( $faq ) {
			$entities = array();
			foreach ( $faq as $item ) {
				$entities[] = array(
					'@type'          => 'Question',
					'name'           => $item[0],
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => $item[1],
					),
				);
			}
			$graph[] = array(
				'@type'      => 'FAQPage',
				'@id'        => $canonical . '#faq',
				'url'        => $canonical,
				'inLanguage' => $lang,
				'isPartOf'   => array( '@id' => $canonical . '#webpage' ),
				'mainEntity' => $entities,
			);
		}

		if ( 'over-ons' === $post->post_name ) {
			foreach ( finest_geo_people_from_content( $post->post_content ) as $person ) {
				$node = array(
					'@type'    => 'Person',
					'@id'      => home_url( '/#person-' . sanitize_title( $person['name'] ) ),
					'name'     => $person['name'],
					'jobTitle' => $person['role'],
					'worksFor' => array( '@id' => $ids['org'] ),
				);
				if ( $person['linkedin'] ) {
					$node['sameAs'] = array( $person['linkedin'] );
				}
				$graph[] = $node;
			}
		}
	}

	return (array) apply_filters( 'finest_geo_graph', $graph );
}

function finest_geo_print_graph() {
	if ( ! finest_geo_active() || is_404() || is_search() ) {
		return;
	}
	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => finest_geo_graph(),
	);
	// wp_json_encode() leaves slashes escaped, so "</script>" inside a value can never close the tag.
	echo '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-LD, encoded above.
}
add_action( 'wp_head', 'finest_geo_print_graph', 4 );

/**
 * Give the ProfessionalService from inc/seo.php its @id and the extra facts
 * (logo, profiles) so the nodes above can point to it.
 */
function finest_geo_org_node( $schema ) {
	$schema['@id'] = finest_geo_ids()['org'];
	$summary       = finest_geo_site_description();
	if ( '' !== $summary ) {
		$schema['description'] = $summary;
	}
	$schema['logo'] = array(
		'@type' => 'ImageObject',
		'url'   => FINEST_THEME_URI . '/assets/img/logo/logo-thefinestimpact1.png',
	);
	$same_as        = finest_geo_same_as();
	if ( $same_as ) {
		$schema['sameAs'] = $same_as;
	}
	if ( '' !== finest_company_field( 'name' ) ) {
		$schema['legalName'] = finest_company_field( 'name' );
	}
	return $schema;
}
add_filter( 'finest_seo_org_schema', 'finest_geo_org_node' );

/* ------------------------------------------------------------------------
 * Head hints: hreflang, robots snippet limits
 * ---------------------------------------------------------------------- */
function finest_geo_hreflang() {
	if ( ! finest_geo_active() || is_404() || is_search() ) {
		return;
	}
	$url  = esc_url( finest_seo_canonical() );
	$lang = esc_attr( str_replace( '_', '-', finest_site_locale() ) );
	echo '<link rel="alternate" hreflang="' . $lang . '" href="' . $url . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
	echo '<link rel="alternate" hreflang="x-default" href="' . $url . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
}
add_action( 'wp_head', 'finest_geo_hreflang', 5 );

/** Allow full snippets and video previews (core already adds max-image-preview:large). */
function finest_geo_robots( $robots ) {
	if ( ! finest_geo_active() ) {
		return $robots;
	}
	if ( ! isset( $robots['noindex'] ) ) {
		$robots['max-snippet']       = '-1';
		$robots['max-video-preview'] = '-1';
	}
	return $robots;
}
add_filter( 'wp_robots', 'finest_geo_robots', 20 );

/* ------------------------------------------------------------------------
 * robots.txt: AI crawlers
 * ---------------------------------------------------------------------- */
function finest_geo_robots_txt( $output, $is_public ) {
	if ( ! $is_public ) {
		return $output;
	}
	$rule   = finest_geo_ai_allowed() ? 'Allow: /' : 'Disallow: /';
	$agents = '';
	foreach ( finest_geo_ai_agents() as $agent ) {
		$agent = preg_replace( '/[^A-Za-z0-9._-]/', '', $agent );
		if ( '' !== $agent ) {
			$agents .= 'User-agent: ' . $agent . "\n";
		}
	}
	if ( '' === $agents ) {
		return $output;
	}
	$block = "\n# AI search and assistants (setting: Settings > General)\n" . $agents . $rule . "\n";
	if ( finest_geo_ai_allowed() ) {
		// Keep the admin area closed for everyone, AI agents included.
		$block .= "Disallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\n";
	}
	return $output . $block;
}
add_filter( 'robots_txt', 'finest_geo_robots_txt', 20, 2 );

/* ------------------------------------------------------------------------
 * /llms.txt and /.well-known/security.txt
 * ---------------------------------------------------------------------- */

/** Request path without query string and without the subfolder WordPress may live in. */
function finest_geo_request_path() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared against fixed strings.
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( '/' !== $base && 0 === strpos( $path, $base ) ) {
		$path = '/' . substr( $path, strlen( $base ) );
	}
	return $path;
}

/** One Markdown link line for a post. */
function finest_geo_llms_line( $post ) {
	$title   = wp_strip_all_tags( get_the_title( $post ) );
	$excerpt = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( get_the_excerpt( $post ) ) ) );
	$line    = '- [' . str_replace( array( '[', ']' ), '', $title ) . '](' . get_permalink( $post ) . ')';
	if ( '' !== $excerpt ) {
		$line .= ': ' . wp_trim_words( $excerpt, 28, '…' );
	}
	return $line;
}

/** The text of /llms.txt. */
function finest_geo_llms_text() {
	$lines   = array();
	$lines[] = '# ' . get_bloginfo( 'name' );
	$lines[] = '';
	$summary = finest_geo_site_description();
	if ( '' !== $summary ) {
		$lines[] = '> ' . $summary;
		$lines[] = '';
	}

	$pages   = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		)
	);
	$lines[] = '## ' . __( 'Pagina’s', 'finest-spotlight' );
	foreach ( $pages as $page ) {
		$lines[] = finest_geo_llms_line( $page );
	}

	$groups = array(
		'post'         => __( 'Nieuws', 'finest-spotlight' ),
		'klantverhaal' => __( 'Klantverhalen', 'finest-spotlight' ),
	);
	foreach ( $groups as $type => $heading ) {
		if ( ! post_type_exists( $type ) ) {
			continue;
		}
		$posts = get_posts(
			array(
				'post_type'      => $type,
				'post_status'    => 'publish',
				'posts_per_page' => 10,
				'no_found_rows'  => true,
			)
		);
		if ( $posts ) {
			$lines[] = '';
			$lines[] = '## ' . $heading;
			foreach ( $posts as $item ) {
				$lines[] = finest_geo_llms_line( $item );
			}
		}
	}

	$lines[] = '';
	$lines[] = '## ' . __( 'Contact', 'finest-spotlight' );
	$lines[] = '- ' . home_url( '/contact/' );
	return implode( "\n", $lines ) . "\n";
}

/** Serve the two plain-text files before WordPress would 404 them. */
function finest_geo_serve_text_files() {
	$path = untrailingslashit( finest_geo_request_path() );
	if ( '/llms.txt' === $path && finest_geo_active() ) {
		$body = finest_geo_llms_text();
	} elseif ( in_array( $path, array( '/.well-known/security.txt', '/security.txt' ), true ) && get_option( 'blog_public' ) ) {
		$contact = (string) apply_filters( 'finest_security_contact', 'mailto:info@thefinestimpact.com' );
		$body    = 'Contact: ' . esc_url_raw( $contact, array( 'mailto', 'https' ) ) . "\n"
			. 'Expires: ' . gmdate( 'Y-m-d\TH:i:s\Z', strtotime( '+1 year' ) ) . "\n"
			. 'Preferred-Languages: nl, en' . "\n"
			. 'Canonical: ' . home_url( '/.well-known/security.txt' ) . "\n";
	} else {
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'Cache-Control: public, max-age=3600' );
	header( 'X-Content-Type-Options: nosniff' );
	echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text, built from escaped/stripped parts.
	exit;
}
add_action( 'parse_request', 'finest_geo_serve_text_files', 1 );
