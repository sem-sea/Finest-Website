<?php
/**
 * Front-end hardening that a marketing site never needs to turn off.
 *
 * Everything here is small, reversible with a filter, and limited to what a
 * theme can do safely. Server-level protections (HSTS, a Content-Security-
 * Policy, a firewall) belong at the host or in a security plugin such as
 * Wordfence; see readme.txt.
 *
 *  - No WordPress version in the page source or the RSS feed.
 *  - No user-name leaks: ?author=N redirects, the public REST users route and
 *    the sitemap of authors are closed for visitors who are not logged in.
 *  - XML-RPC and pingbacks off (filter `finest_allow_xmlrpc` to switch on).
 *  - Generic login error (does not reveal whether the user name exists).
 *  - Safe response headers: nosniff, referrer policy, same-origin framing,
 *    permissions policy. Filter `finest_security_headers` to change them.
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

// No generator tag, no version in feeds.
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );

/**
 * Visitors who are not logged in must not be able to list user names.
 */
function finest_security_block_author_enum() {
	if ( is_admin() || is_user_logged_in() ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only check of a public query var.
	if ( isset( $_GET['author'] ) ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
	// Author archives are not part of this site: send /author/name/ to the home page too.
	if ( is_author() ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'finest_security_block_author_enum', 1 );

/** Close the public REST users routes. */
function finest_security_rest_users( $endpoints ) {
	if ( is_user_logged_in() ) {
		return $endpoints;
	}
	foreach ( array( '/wp/v2/users', '/wp/v2/users/(?P<id>[\d]+)' ) as $route ) {
		unset( $endpoints[ $route ] );
	}
	return $endpoints;
}
add_filter( 'rest_endpoints', 'finest_security_rest_users' );

/** No author list in the core sitemap. */
function finest_security_sitemap_providers( $provider, $name ) {
	return 'users' === $name ? false : $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'finest_security_sitemap_providers', 10, 2 );

// XML-RPC and pingbacks.
if ( ! apply_filters( 'finest_allow_xmlrpc', false ) ) {
	add_filter( 'xmlrpc_enabled', '__return_false' );
	add_action(
		'init',
		static function () {
			if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
				status_header( 403 );
				header( 'Content-Type: text/plain; charset=utf-8' );
				exit( 'XML-RPC is uitgeschakeld.' );
			}
		},
		0
	);
	add_filter( 'pings_open', '__return_false', 20 );
	add_filter(
		'wp_headers',
		static function ( $headers ) {
			unset( $headers['X-Pingback'] );
			return $headers;
		}
	);
}

// The login form must not tell an attacker which half of the credentials was right.
add_filter(
	'login_errors',
	static function () {
		return esc_html__( 'Inloggen is niet gelukt. Controleer je gegevens en probeer het opnieuw.', 'finest-spotlight' );
	}
);

/**
 * Response headers. Only sent when the server has not already set them.
 *
 * @param string[] $headers Existing headers.
 * @return string[]
 */
function finest_security_headers( $headers ) {
	$ours = (array) apply_filters(
		'finest_security_headers',
		array(
			'X-Content-Type-Options' => 'nosniff',
			'Referrer-Policy'        => 'strict-origin-when-cross-origin',
			'X-Frame-Options'        => 'SAMEORIGIN',
			'Permissions-Policy'     => 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()',
		)
	);
	foreach ( $ours as $name => $value ) {
		if ( ! isset( $headers[ $name ] ) && '' !== (string) $value ) {
			$headers[ $name ] = $value;
		}
	}
	return $headers;
}
add_filter( 'wp_headers', 'finest_security_headers' );

// Do not announce the PHP version.
add_action(
	'send_headers',
	static function () {
		header_remove( 'X-Powered-By' );
	}
);
