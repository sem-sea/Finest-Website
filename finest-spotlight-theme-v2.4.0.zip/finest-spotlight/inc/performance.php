<?php
/**
 * Page speed: smaller assets, fewer requests, a faster largest paint.
 *
 * Nothing here changes what a page looks like; every item is measured
 * against the previous build with a pixel comparison (see readme.txt).
 *
 *  - Minified copies of style.css and the theme scripts are served when they
 *    exist (assets/css/style.min.css, assets/js/*.min.js). style.css and the
 *    plain scripts stay the editable sources. SCRIPT_DEBUG serves the sources.
 *  - explainers.js (canvas diagrams) only loads on pages that contain one.
 *  - The emoji script and styles are not loaded (the site uses no emoji
 *    images; native emoji still render).
 *  - Contact Form 7 CSS/JS only loads on pages that contain a form.
 *  - The big motion libraries load with a low network priority, so the hero
 *    photo and the stylesheet win the bandwidth on slow connections.
 *  - The hero photo is preloaded with the same srcset/sizes as the image
 *    itself, and photos in the half-width sections get an honest `sizes`.
 *  - New uploads get WebP sub-sizes (originals are kept).
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------------
 * Minified assets
 * ---------------------------------------------------------------------- */

/**
 * Path and URL of an asset: the .min version when it exists (and SCRIPT_DEBUG
 * is off), otherwise the source.
 *
 * @param string $relative Source path relative to the theme, e.g. 'assets/js/motion.js'.
 * @return array{path:string,url:string}|null
 */
function finest_asset( $relative ) {
	$candidates = array();
	if ( ! ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ) {
		$candidates[] = preg_replace( '/\.(css|js)$/', '.min.$1', $relative );
	}
	$candidates[] = $relative;
	foreach ( $candidates as $candidate ) {
		$path = FINEST_THEME_DIR . '/' . $candidate;
		if ( file_exists( $path ) ) {
			return array(
				'path' => $path,
				'url'  => FINEST_THEME_URI . '/' . $candidate,
			);
		}
	}
	return null;
}

/* ------------------------------------------------------------------------
 * Fewer requests
 * ---------------------------------------------------------------------- */

/** No emoji detection script, no emoji styles (native emoji keep working). */
function finest_perf_disable_emoji() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', 'finest_perf_disable_emoji' );

/** True when the current page has a form that needs Contact Form 7's assets. */
function finest_perf_page_has_form() {
	if ( ! is_singular() ) {
		return false;
	}
	$post = get_queried_object();
	if ( ! ( $post instanceof WP_Post ) ) {
		return false;
	}
	return has_shortcode( $post->post_content, 'finest_contact_form' )
		|| has_shortcode( $post->post_content, 'contact-form-7' )
		|| false !== strpos( $post->post_content, 'wp:contact-form-7' );
}

/** Contact Form 7 loads its CSS and scripts everywhere; keep them to pages with a form. */
function finest_perf_trim_cf7_assets() {
	if ( finest_perf_page_has_form() ) {
		return;
	}
	wp_dequeue_style( 'contact-form-7' );
	wp_dequeue_script( 'contact-form-7' );
	wp_dequeue_script( 'swv' );
	wp_dequeue_script( 'google-recaptcha' );
	wp_dequeue_script( 'wpcf7-recaptcha' );
}
add_action( 'wp_enqueue_scripts', 'finest_perf_trim_cf7_assets', 100 );

/** Skip explainers.js when the page has no canvas diagram. */
function finest_perf_trim_explainers() {
	$post    = is_singular() ? get_queried_object() : null;
	$content = ( $post instanceof WP_Post ) ? $post->post_content : '';
	if ( false === strpos( $content, 'explainer-canvas' ) ) {
		wp_dequeue_script( 'finest-explainers' );
	}
}
add_action( 'wp_enqueue_scripts', 'finest_perf_trim_explainers', 100 );

/* ------------------------------------------------------------------------
 * Network priority: the motion libraries are an enhancement, not content
 * ---------------------------------------------------------------------- */
function finest_perf_script_priority( $tag, $handle ) {
	$low = array( 'finest-lenis', 'finest-gsap', 'finest-scrolltrigger', 'finest-splittext', 'finest-motion', 'finest-explainers' );
	if ( in_array( $handle, $low, true ) && false === strpos( $tag, 'fetchpriority' ) ) {
		$tag = preg_replace( '/<script /', '<script fetchpriority="low" ', $tag, 1 );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'finest_perf_script_priority', 10, 2 );

/* ------------------------------------------------------------------------
 * Images: honest `sizes`, hero preload
 * ---------------------------------------------------------------------- */

/** `sizes` for the photos the Spotlight sections place at half width. */
function finest_perf_sizes_for( $class_list ) {
	if ( false !== strpos( $class_list, 'fi-hero__media' ) ) {
		return '(min-width: 900px) 48vw, 100vw';
	}
	if ( false !== strpos( $class_list, 'fi-split__media' ) ) {
		return '(min-width: 900px) 50vw, 100vw';
	}
	return '';
}

/** Remember which attachment IDs have a custom `sizes`, for wp_content_img_tag below. */
function finest_perf_sizes_map( $id = 0, $sizes = '' ) {
	static $map = array();
	if ( $id && '' !== $sizes ) {
		$map[ (int) $id ] = $sizes;
	}
	return $map;
}

function finest_perf_note_block_sizes( $block_content, $block ) {
	$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	$sizes = finest_perf_sizes_for( $class );
	if ( '' !== $sizes && ! empty( $block['attrs']['id'] ) ) {
		finest_perf_sizes_map( (int) $block['attrs']['id'], $sizes );
	}
	return $block_content;
}
add_filter( 'render_block_core/image', 'finest_perf_note_block_sizes', 10, 2 );

/** Apply the custom `sizes` while core adds srcset/sizes to the content images. */
function finest_perf_content_img_sizes( $filtered_image, $context, $attachment_id ) {
	$map = finest_perf_sizes_map();
	if ( isset( $map[ (int) $attachment_id ] ) ) {
		$sizes = esc_attr( $map[ (int) $attachment_id ] );
		if ( preg_match( '/\ssizes="[^"]*"/', $filtered_image ) ) {
			$filtered_image = preg_replace( '/\ssizes="[^"]*"/', ' sizes="' . $sizes . '"', $filtered_image, 1 );
		} else {
			$filtered_image = preg_replace( '/<img /', '<img sizes="' . $sizes . '" ', $filtered_image, 1 );
		}
	}
	return $filtered_image;
}
add_filter( 'wp_content_img_tag', 'finest_perf_content_img_sizes', 20, 3 );

/** The hero photo (first fi-hero__media image of the page), if any. */
function finest_perf_hero_id() {
	if ( ! is_singular() ) {
		return 0;
	}
	$post = get_queried_object();
	if ( ! ( $post instanceof WP_Post ) ) {
		return 0;
	}
	if ( preg_match( '/<figure[^>]*fi-hero__media[^>]*>\s*<img[^>]*wp-image-(\d+)/i', $post->post_content, $m ) ) {
		return (int) $m[1];
	}
	return 0;
}

/** Start downloading the hero photo before the stylesheet has arrived. */
function finest_perf_preload_hero() {
	$id = finest_perf_hero_id();
	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return;
	}
	$src    = wp_get_attachment_image_url( $id, 'full' );
	$srcset = wp_get_attachment_image_srcset( $id, 'full' );
	if ( ! $src ) {
		return;
	}
	printf(
		'<link rel="preload" as="image" href="%1$s"%2$s imagesizes="%3$s" fetchpriority="high">' . "\n",
		esc_url( $src ),
		$srcset ? ' imagesrcset="' . esc_attr( $srcset ) . '"' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped on the same line.
		esc_attr( finest_perf_sizes_for( 'fi-hero__media' ) )
	);
}
add_action( 'wp_head', 'finest_perf_preload_hero', 1 );

/** New uploads: WebP sub-sizes at a sensible quality (the original file is kept). */
function finest_perf_webp_output( $formats ) {
	// Return false from the `finest_webp_uploads` filter to keep JPEG sub-sizes.
	if ( apply_filters( 'finest_webp_uploads', true ) ) {
		$formats['image/jpeg'] = 'image/webp';
	}
	return $formats;
}
add_filter( 'image_editor_output_format', 'finest_perf_webp_output' );
add_filter(
	'wp_editor_set_quality',
	static function ( $quality, $mime_type ) {
		return 'image/webp' === $mime_type ? 80 : $quality;
	},
	10,
	2
);
