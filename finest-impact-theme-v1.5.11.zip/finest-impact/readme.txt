=== The Finest Impact ===
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.5.11
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Block theme for The Finest Impact (marketing platform for independent opticians). Pages, news and templates are native Gutenberg blocks.

== Installation ==

1. Appearance > Themes > Add New > Upload Theme, choose the zip, install and activate.
2. On activation the theme creates the pages (Home, Diensten, Over ons, Klantverhalen, Nieuws, Contact, Algemene voorwaarden, Privacyverklaring), the Nieuws categories, 9 starter articles, the media-library images and sets pretty permalinks. Existing pages are never overwritten.
3. Settings > General > WhatsApp-nummer: the number behind the WhatsApp button in the contact bar (empty hides the button).
4. Contact form: install the plugin Contact Form 7 (and Flamingo to keep submissions). The theme then creates a ready-made form in the house style; recipient and mail text are editable under Contact > Contact forms. Without Contact Form 7 the theme uses a simpler built-in form with the same look.
5. Set Settings > General > Site Language to Nederlands. On first activation (production sites only) the theme switches off "Discourage search engines from indexing this site" so the site can be found; staging/local sites (WP_ENVIRONMENT_TYPE) and later re-activations are left alone.
6. Settings > General > Bedrijfsgegevens: enter the legal name, KvK number, VAT number and address (shown on the legal pages), and have the legal pages reviewed by a lawyer.

== Security notes ==

* The built-in form checks a nonce, a honeypot, field lengths and rate limits (3 per IP per 10 minutes, 30 per hour site-wide, counted for valid submissions only). Reply-To carries the e-mail address only.
* No third-party scripts, fonts or cookies are loaded by the theme. The WhatsApp button is a plain link that only leaves the site when clicked.
* Behind a proxy or CDN make sure PHP sees the visitor's real IP, otherwise the per-IP limit applies to everyone at once.
* Set security headers (HSTS, X-Content-Type-Options, frame-ancestors, Referrer-Policy) at the host or CDN; a theme should not set them.
* On cached pages the built-in form's nonce can expire; exclude the Contact page from page caching or use Contact Form 7.

== Credits ==

* Fonts: Jost and Hanken Grotesk, SIL Open Font License 1.1 (assets/fonts/OFL.txt).
* Animation: GSAP 3.15.0 with ScrollTrigger and SplitText, (c) GreenSock, used under the GSAP Standard License, https://gsap.com/standard-license (assets/js/vendor/).
* Photographs and logos: provided by The Finest Impact.

== Changelog ==

= 1.5.11 =
* Content no longer touches the screen edge on mobile (side padding set once in theme.json).
* FAQ accordion now shows its + / minus, hairlines and spacing like the demo.
* Header: wordmark left, menu right with "Inloggen" as a plain link (no oversized button); hero text inset and wraps at 760px; hero full-height on desktop.
* Outlined buttons on black bands (a black button on black was invisible); footer wordmark lockup + full-width hairline; Diensten steps as a 4-column grid; contact intro aligned with its heading.

= 1.5.10 =
* First activation on a production site now turns off "Discourage search engines" (Settings > Reading). Skipped on staging/local/development, when already indexable, via the finest_enable_indexing_on_first_activation filter, and on every later re-activation.
= 1.5.9 =
* Every page now has an editable search description (block editor sidebar > Summary > Excerpt), filled in for the seeded pages; better automatic fallback; description for news categories.
* lang and og:locale are Dutch (nl-NL) for the Dutch copy even if the site language is still English.
= 1.5.8 =
* Compatibility declared from what was actually tested: WordPress 6.8.5 and 7.1.3 (PHP 8.4); PHP 8.1+ checked statically. Requires at least 6.8, tested up to 7.1.
= 1.5.7 =
* Fix: first activation could create every page and post twice when another request (e.g. wp-cron) hit the site during the one-time setup. Setup now runs under a lock.
= 1.5.6 =
* Legal pages filled in (terms: duration, liability, governing law; privacy: legal basis, recipients, retention, rights, complaint route). Company details (legal name, KvK, btw, address) are settings under Settings > General and appear through a shortcode; empty values never show placeholders to visitors.
= 1.5.5 =
* Security hardening and packaging: capability check before first-run provisioning, escaping/sanitising fixes found by the WordPress coding standards security sniffs, licence files, folder name finest-impact.
= 1.5.4 =
* Contact form in the house style (Contact Form 7 + built-in fallback), loaders and states, footer link colour fix.
= 1.5.3 =
* Manon's photo. = 1.5.2 = Karin's photo and sharper team photos. = 1.5.1 = New share images. = 1.5.0 = Contact bar (Neem contact op + WhatsApp).
