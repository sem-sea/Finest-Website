/* Contact form behaviour: loader state, focus management, aria-busy.
   Works for Contact Form 7 (data-status on the form, wpcf7* events) and for the
   built-in fallback form (same markup). Styling is pure CSS driven by
   form[data-status]; this file only adds what CSS can't: focus and busy state. */
(function () {
	'use strict';

	function focusEl(el) {
		if (!el) { return; }
		if (!el.hasAttribute('tabindex') && !/^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/.test(el.tagName)) { el.setAttribute('tabindex', '-1'); }
		try { el.focus({ preventScroll: false }); } catch (e) { el.focus(); }
	}

	function firstInvalid(form) {
		return form.querySelector('.wpcf7-not-valid, [aria-invalid="true"]');
	}

	document.querySelectorAll('form.tfi-form').forEach(function (form) {
		/* Contact Form 7 */
		form.addEventListener('wpcf7beforesubmit', function () { form.setAttribute('aria-busy', 'true'); });
		form.addEventListener('wpcf7submit', function () { form.removeAttribute('aria-busy'); });
		['wpcf7invalid', 'wpcf7unaccepted'].forEach(function (name) {
			form.addEventListener(name, function () { window.setTimeout(function () { focusEl(firstInvalid(form)); }, 30); });
		});
		/* After a successful send CF7 resets the form (status flips to "resetting"
		   and back to "sent"); focus the success panel on the final "sent". */
		form.addEventListener('wpcf7statuschanged', function (e) {
			if (e.detail && e.detail.status === 'sent') {
				window.setTimeout(function () { focusEl(form.querySelector('.tfi-success')); }, 60);
			}
		});
		['wpcf7mailfailed', 'wpcf7spam'].forEach(function (name) {
			form.addEventListener(name, function () {
				window.setTimeout(function () { focusEl(form.querySelector('.wpcf7-response-output')); }, 30);
			});
		});

		/* Built-in fallback form: show the loader while the page posts. */
		if (form.classList.contains('tfi-form--native')) {
			form.addEventListener('submit', function () {
				if (form.checkValidity && !form.checkValidity()) { return; }
				form.setAttribute('data-status', 'submitting');
				form.setAttribute('aria-busy', 'true');
			});
			/* After a redirect with a status, bring the message into view. */
			var res = form.querySelector('.tfi-success, .wpcf7-response-output');
			if (res && /^#tfi-response/.test(window.location.hash)) { focusEl(res); }
		}
	});

	/* Browser back-button: leave no form stuck in "submitting". */
	window.addEventListener('pageshow', function (e) {
		if (!e.persisted) { return; }
		document.querySelectorAll('form.tfi-form--native[data-status="submitting"]').forEach(function (f) {
			f.setAttribute('data-status', 'init');
			f.removeAttribute('aria-busy');
		});
	});
})();
