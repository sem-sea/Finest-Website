=== The Finest Impact ===
Requires at least: 6.7
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.5.5
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Block theme for The Finest Impact (marketing platform for independent opticians). Pages, news and templates are native Gutenberg blocks.

== Installation ==

1. Appearance > Themes > Add New > Upload Theme, choose the zip, install and activate.
2. On activation the theme creates the pages (Home, Diensten, Over ons, Klantverhalen, Nieuws, Contact, Algemene voorwaarden, Privacyverklaring), the Nieuws categories, 9 starter articles, the media-library images and sets pretty permalinks. Existing pages are never overwritten.
3. Settings > General > WhatsApp-nummer: the number behind the WhatsApp button in the contact bar (empty hides the button).
4. Contact form: install the plugin Contact Form 7 (and Flamingo to keep submissions). The theme then creates a ready-made form in the house style; recipient and mail text are editable under Contact > Contact forms. Without Contact Form 7 the theme uses a simpler built-in form with the same look.
5. Fill the [AAN TE VULLEN] placeholders in the legal pages (company number, VAT number, address, retention periods) and have them reviewed by a lawyer.

== Security notes ==

* The built-in form checks a nonce, a honeypot, field lengths and rate limits (3 per IP per 10 minutes, 30 per hour site-wide, counted for valid submissions only). Reply-To carries the e-mail address only.
* No third-party scripts, fonts or cookies are loaded by the theme. The WhatsApp button is a plain link that only leaves the site when clicked.
* Behind a proxy or CDN make sure PHP sees the visitor's real IP, otherwise the per-IP limit applies to everyone at once.
* Set security headers (HSTS, X-Content-Type-Options, frame-ancestors, Referrer-Policy) at the host or CDN; a theme should not set them.
* On cached pages the built-in form's nonce can expire; exclude the Contact page from page caching or use Contact Form 7.

== Credits ==

* Fonts: Jost and Hanken Grotesk, SIL Open Font License 1.1 (assets/fonts/OFL.txt).
* Animation: GSAP 3.15.0 with ScrollTrigger and SplitText, (c) GreenSock, used under the GSAP Standard License, https://gsap.com/standard-license (assets/js/vendor/).
* Photographs and logos: provided by The Finest Impact.

== Changelog ==

= 1.5.5 =
* Security hardening and packaging: capability check before first-run provisioning, escaping/sanitising fixes found by the WordPress coding standards security sniffs, licence files, folder name finest-impact.
= 1.5.4 =
* Contact form in the house style (Contact Form 7 + built-in fallback), loaders and states, footer link colour fix.
= 1.5.3 =
* Manon's photo. = 1.5.2 = Karin's photo and sharper team photos. = 1.5.1 = New share images. = 1.5.0 = Contact bar (Neem contact op + WhatsApp).
