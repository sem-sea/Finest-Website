<?php
/**
 * Teaser page ("binnenkort online" / website tijdelijk dicht).
 *
 * Weergave > Teaserpagina. While switched on, visitors see one branded page
 * (HTTP 503 + Retry-After + noindex, never cached) instead of the site.
 * Logged-in users who can edit pages, and anyone with the secret preview link
 * (?voorbeeld=SLEUTEL), still see the real site. wp-admin, wp-login.php, the
 * REST API and robots.txt are untouched.
 *
 * @package finest-impact
 */

defined( 'ABSPATH' ) || exit;

/**
 * Defaults.
 *
 * @return array
 */
function finest_teaser_defaults() {
	return array(
		'enabled'      => false,
		'eyebrow'      => 'Own your spotlight',
		'title'        => 'Binnenkort online',
		'text'         => 'We werken aan onze nieuwe website. Wil je nu al kennismaken? Stuur ons gerust een bericht.',
		'button_label' => '',
		'button_url'   => '',
		'show_email'   => true,
		'show_whatsapp' => true,
		'preview_key'  => '',
	);
}

/**
 * Current settings (saved values over defaults).
 *
 * @return array
 */
function finest_teaser_settings() {
	$saved = get_option( 'finest_teaser', array() );
	return array_merge( finest_teaser_defaults(), is_array( $saved ) ? $saved : array() );
}

/**
 * Sanitise the submitted form; creates the preview key when switching on.
 *
 * @param mixed $input Raw values.
 * @return array
 */
function finest_teaser_sanitize( $input ) {
	$input   = is_array( $input ) ? $input : array();
	$current = finest_teaser_settings();
	$enabled = ! empty( $input['enabled'] );
	$key     = preg_match( '/^[a-f0-9]{20,40}$/', (string) $current['preview_key'] ) ? $current['preview_key'] : '';
	if ( ( $enabled && '' === $key ) || ! empty( $input['regenerate_key'] ) ) {
		$key = bin2hex( random_bytes( 10 ) );
	}
	return array(
		'enabled'       => $enabled,
		'eyebrow'       => sanitize_text_field( $input['eyebrow'] ?? '' ),
		'title'         => sanitize_text_field( $input['title'] ?? '' ) ? sanitize_text_field( $input['title'] ) : 'Binnenkort online',
		'text'          => sanitize_textarea_field( $input['text'] ?? '' ),
		'button_label'  => sanitize_text_field( $input['button_label'] ?? '' ),
		'button_url'    => esc_url_raw( $input['button_url'] ?? '' ),
		'show_email'    => ! empty( $input['show_email'] ),
		'show_whatsapp' => ! empty( $input['show_whatsapp'] ),
		'preview_key'   => $key,
	);
}

/**
 * Register option + page.
 */
function finest_teaser_register() {
	register_setting(
		'finest_teaser_group',
		'finest_teaser',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'finest_teaser_sanitize',
			'default'           => finest_teaser_defaults(),
		)
	);
}
add_action( 'admin_init', 'finest_teaser_register' );

/**
 * Menu entry under Weergave.
 */
function finest_teaser_menu() {
	add_theme_page(
		__( 'Teaserpagina', 'finest-impact' ),
		__( 'Teaserpagina', 'finest-impact' ),
		'edit_theme_options',
		'finest-teaser',
		'finest_teaser_render_page'
	);
}
add_action( 'admin_menu', 'finest_teaser_menu' );

/**
 * Settings page.
 */
function finest_teaser_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$t = finest_teaser_settings();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Teaserpagina (website tijdelijk dicht)', 'finest-impact' ); ?></h1>
		<?php settings_errors(); ?>
		<p><?php esc_html_e( 'Aan = bezoekers zien alleen deze teaser, met de melding "tijdelijk niet beschikbaar" voor Google. Jij en andere ingelogde redacteuren zien de echte site gewoon.', 'finest-impact' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'finest_teaser_group' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Teaserpagina', 'finest-impact' ); ?></th>
					<td><label><input type="checkbox" name="finest_teaser[enabled]" value="1" <?php checked( $t['enabled'] ); ?>> <strong><?php esc_html_e( 'AAN: de rest van de website is dicht voor bezoekers', 'finest-impact' ); ?></strong></label></td>
				</tr>
				<tr>
					<th scope="row"><label for="ft-eyebrow"><?php esc_html_e( 'Kleine regel boven de kop', 'finest-impact' ); ?></label></th>
					<td><input id="ft-eyebrow" type="text" class="regular-text" name="finest_teaser[eyebrow]" value="<?php echo esc_attr( $t['eyebrow'] ); ?>" maxlength="80"></td>
				</tr>
				<tr>
					<th scope="row"><label for="ft-title"><?php esc_html_e( 'Kop', 'finest-impact' ); ?></label></th>
					<td><input id="ft-title" type="text" class="large-text" name="finest_teaser[title]" value="<?php echo esc_attr( $t['title'] ); ?>" maxlength="160"></td>
				</tr>
				<tr>
					<th scope="row"><label for="ft-text"><?php esc_html_e( 'Tekst', 'finest-impact' ); ?></label></th>
					<td><textarea id="ft-text" class="large-text" rows="3" name="finest_teaser[text]" maxlength="500"><?php echo esc_textarea( $t['text'] ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><label for="ft-btn"><?php esc_html_e( 'Extra knop (optioneel)', 'finest-impact' ); ?></label></th>
					<td>
						<input id="ft-btn" type="text" class="regular-text" name="finest_teaser[button_label]" value="<?php echo esc_attr( $t['button_label'] ); ?>" placeholder="<?php esc_attr_e( 'Tekst op de knop', 'finest-impact' ); ?>" maxlength="60">
						<input type="url" class="regular-text" name="finest_teaser[button_url]" value="<?php echo esc_attr( $t['button_url'] ); ?>" placeholder="https://…">
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Contactknoppen', 'finest-impact' ); ?></th>
					<td>
						<label><input type="checkbox" name="finest_teaser[show_email]" value="1" <?php checked( $t['show_email'] ); ?>> <?php esc_html_e( 'E-mailadres tonen als knop', 'finest-impact' ); ?></label><br>
						<label><input type="checkbox" name="finest_teaser[show_whatsapp]" value="1" <?php checked( $t['show_whatsapp'] ); ?>> <?php esc_html_e( 'WhatsApp-knop tonen (nummer: Instellingen > Algemeen)', 'finest-impact' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Geheime voorbeeldlink', 'finest-impact' ); ?></th>
					<td>
						<?php if ( $t['preview_key'] ) : ?>
							<input type="text" class="large-text" readonly onclick="this.select()" value="<?php echo esc_attr( add_query_arg( 'voorbeeld', $t['preview_key'], home_url( '/' ) ) ); ?>">
							<p class="description"><?php esc_html_e( 'Hiermee zie je de echte site terwijl de teaser aan staat (ook voor een klant of collega, 8 uur geldig per apparaat).', 'finest-impact' ); ?></p>
							<label><input type="checkbox" name="finest_teaser[regenerate_key]" value="1"> <?php esc_html_e( 'Nieuwe sleutel maken bij opslaan (de oude link werkt dan niet meer)', 'finest-impact' ); ?></label>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'Zodra je de teaser aanzet en opslaat, krijg je hier een geheime voorbeeldlink.', 'finest-impact' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php if ( $t['enabled'] ) : ?>
			<p><a class="button" target="_blank" rel="noopener" href="<?php echo esc_url( add_query_arg( 'voorbeeld', $t['preview_key'], home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Echte site bekijken (voorbeeldlink)', 'finest-impact' ); ?></a></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * May this request see the real site while the teaser is on?
 *
 * @param array $t Teaser settings.
 * @return bool
 */
function finest_teaser_bypass( $t ) {
	if ( current_user_can( 'edit_pages' ) || is_customize_preview() ) {
		return true;
	}
	$key = (string) $t['preview_key'];
	if ( '' === $key ) {
		return false;
	}
	$token = hash_hmac( 'sha256', $key, wp_salt( 'auth' ) );
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public preview link, compared to a secret.
	$given = isset( $_GET['voorbeeld'] ) ? sanitize_text_field( wp_unslash( $_GET['voorbeeld'] ) ) : '';
	if ( '' !== $given && hash_equals( $key, $given ) ) {
		setcookie( 'finest_teaser_preview', $token, time() + 8 * HOUR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		$_COOKIE['finest_teaser_preview'] = $token;
		return true;
	}
	$have = isset( $_COOKIE['finest_teaser_preview'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['finest_teaser_preview'] ) ) : '';
	return '' !== $have && hash_equals( $token, $have );
}

/**
 * Front-end gate.
 */
function finest_teaser_gate() {
	$t = finest_teaser_settings();
	if ( empty( $t['enabled'] ) || is_robots() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	if ( finest_teaser_bypass( $t ) ) {
		// Real site for an allowed visitor: make sure no cache stores it for everyone else.
		nocache_headers();
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		return;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	nocache_headers();
	status_header( 503 );
	header( 'Retry-After: 3600' );
	header( 'X-Robots-Tag: noindex, nofollow' );
	header( 'Content-Type: text/html; charset=utf-8' );
	finest_teaser_print( $t );
	exit;
}
add_action( 'template_redirect', 'finest_teaser_gate', 0 );

/**
 * The page itself: self-contained (own CSS, theme fonts), no scripts.
 *
 * @param array $t Teaser settings.
 */
function finest_teaser_print( $t ) {
	$site   = get_bloginfo( 'name' );
	$email  = function_exists( 'finest_contact_recipient' ) ? finest_contact_recipient() : '';
	$wa     = function_exists( 'finest_whatsapp_number' ) ? finest_whatsapp_number() : '';
	$jost   = get_theme_file_uri( 'assets/fonts/jost-variable.woff2' );
	$hanken = get_theme_file_uri( 'assets/fonts/hanken-grotesk-variable.woff2' );
	?>
<!doctype html>
<html lang="nl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $t['title'] . ' — ' . $site ); ?></title>
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="<?php echo esc_attr( $t['text'] ); ?>">
<style>
@font-face{font-family:'Jost';font-weight:200 500;font-display:swap;src:url('<?php echo esc_url( $jost ); ?>') format('woff2')}
@font-face{font-family:'Hanken Grotesk';font-weight:300 700;font-display:swap;src:url('<?php echo esc_url( $hanken ); ?>') format('woff2')}
*{box-sizing:border-box}
html,body{margin:0}
body{min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;background:#F7F3EE;color:#000;font-family:'Hanken Grotesk',system-ui,sans-serif;font-size:17px;line-height:1.7}
main{flex:1;display:flex;align-items:center}
.inner{width:100%;max-width:760px;margin:0 auto;padding:56px 20px}
@media(min-width:900px){.inner{padding:56px 64px}}
.lockup{display:inline-flex;flex-direction:column;font-family:'Jost',sans-serif;text-transform:lowercase;line-height:1;font-size:64px;margin-bottom:56px}
@media(min-width:900px){.lockup{font-size:80px}}
.lockup span{display:block;font-weight:300}
.lockup .the{font-size:.34em;letter-spacing:.03em;align-self:flex-start;margin-bottom:-.08em}
.lockup .finest{letter-spacing:-.01em}
.lockup .impact{font-size:.34em;letter-spacing:.22em;align-self:flex-end;margin-top:-.1em}
.eyebrow{font-family:'Jost',sans-serif;font-size:12px;letter-spacing:.28em;text-transform:uppercase;margin:0 0 14px}
h1{font-family:'Jost',sans-serif;font-weight:200;font-size:clamp(40px,7vw,72px);line-height:1.1;letter-spacing:-.01em;margin:0 0 20px}
.lead{font-size:20px;margin:0}
.actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:32px}
.btn{display:inline-block;font-family:'Jost',sans-serif;font-weight:400;letter-spacing:.04em;text-decoration:none;padding:15px 30px;border:1px solid #000;border-radius:2px;background:#000;color:#F7F3EE;transition:background-color .3s,color .3s}
.btn:hover,.btn:focus-visible{background:#5C5C5C;border-color:#5C5C5C}
.btn.o{background:transparent;color:#000}
.btn.o:hover,.btn.o:focus-visible{background:#000;color:#F7F3EE}
.btn:focus-visible{outline:2px solid #000;outline-offset:3px}
footer{width:100%;max-width:760px;margin:0 auto;padding:20px 20px 28px;font-size:13px;color:#5C5C5C}
@media(min-width:900px){footer{padding-left:64px;padding-right:64px}}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
</style>
</head>
<body>
<main id="main">
	<div class="inner">
		<div class="lockup" role="img" aria-label="<?php echo esc_attr( $site ); ?>"><span class="the" aria-hidden="true">the</span><span class="finest" aria-hidden="true">finest</span><span class="impact" aria-hidden="true">impact</span></div>
		<?php if ( '' !== $t['eyebrow'] ) : ?>
			<p class="eyebrow"><?php echo esc_html( $t['eyebrow'] ); ?></p>
		<?php endif; ?>
		<h1><?php echo esc_html( $t['title'] ); ?></h1>
		<?php if ( '' !== $t['text'] ) : ?>
			<p class="lead"><?php echo esc_html( $t['text'] ); ?></p>
		<?php endif; ?>
		<div class="actions">
			<?php if ( $t['button_label'] && $t['button_url'] ) : ?>
				<a class="btn" href="<?php echo esc_url( $t['button_url'] ); ?>"><?php echo esc_html( $t['button_label'] ); ?></a>
			<?php endif; ?>
			<?php if ( $t['show_email'] && $email ) : ?>
				<a class="btn o" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
			<?php endif; ?>
			<?php if ( $t['show_whatsapp'] && $wa ) : ?>
				<a class="btn o" href="<?php echo esc_url( 'https://wa.me/' . $wa ); ?>" target="_blank" rel="noopener noreferrer">WhatsApp<span class="sr"> (opent in een nieuw tabblad)</span></a>
			<?php endif; ?>
		</div>
	</div>
</main>
<footer>© <?php echo esc_html( gmdate( 'Y' ) . ' ' . $site ); ?></footer>
</body>
</html>
	<?php
}

/**
 * Remind admins that the site is closed: admin bar badge + notice.
 *
 * @param WP_Admin_Bar $bar Admin bar.
 */
function finest_teaser_admin_bar( $bar ) {
	$t = finest_teaser_settings();
	if ( empty( $t['enabled'] ) || ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$bar->add_node(
		array(
			'id'    => 'finest-teaser',
			'title' => esc_html__( 'Website is DICHT (teaser aan)', 'finest-impact' ),
			'href'  => admin_url( 'themes.php?page=finest-teaser' ),
			'meta'  => array( 'class' => 'finest-teaser-on' ),
		)
	);
}
add_action( 'admin_bar_menu', 'finest_teaser_admin_bar', 100 );

/**
 * Red badge styling (admin bar shows on the front end and in wp-admin).
 */
function finest_teaser_admin_bar_style() {
	$t = finest_teaser_settings();
	if ( empty( $t['enabled'] ) || ! is_admin_bar_showing() ) {
		return;
	}
	echo '<style>#wpadminbar .finest-teaser-on > .ab-item{background:#b00020!important;color:#fff!important}</style>';
}
add_action( 'wp_head', 'finest_teaser_admin_bar_style' );
add_action( 'admin_head', 'finest_teaser_admin_bar_style' );
