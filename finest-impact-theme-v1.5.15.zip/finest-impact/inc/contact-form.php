<?php
/**
 * Contact form.
 *
 * Preferred engine: Contact Form 7. When that plugin is active the theme
 * creates one ready-made form ("TFI - Contactformulier": fields, Dutch
 * messages, mail template with the recipient editable in wp-admin) and the
 * [finest_contact_form] shortcode on the Contact page renders it, styled in
 * the The Finest Impact design (style.css, "Contact form" section).
 *
 * Fallback: without Contact Form 7 the same shortcode renders a small built-in
 * form with identical markup/classes, so the page never breaks and looks the
 * same. The fallback handler is hardened (length limits, Reply-To carries the
 * e-mail address only, rate limits that count valid submissions only, an
 * all-site hourly cap, one clear message per failure).
 *
 * Neither path stores submissions. Install Flamingo next to Contact Form 7 for
 * a searchable inbox, and use Contact > Integration for Akismet/Turnstile.
 */

defined( 'ABSPATH' ) || exit;

/** Contact Form 7 present and loaded? */
function finest_cf7_active() {
	return class_exists( 'WPCF7_ContactForm' );
}

/** Where enquiries go (fallback form + the CF7 form's initial setting). */
function finest_contact_recipient() {
	return (string) apply_filters( 'finest_contact_recipient', 'info@thefinestimpact.com' );
}

/* -------------------------------------------------------------------------
 * Contact Form 7: the ready-made form
 * ---------------------------------------------------------------------- */

/**
 * Form template in CF7 syntax. Plain divs (no loose text), so CF7's autop
 * leaves the layout alone. The submit control is a real <button> so it can
 * carry the label, arrow and loader; CF7 only needs the .wpcf7-submit class.
 */
function finest_cf7_form_markup() {
	$privacy = esc_url( home_url( '/privacyverklaring/' ) );
	$markup  = '<div class="tfi-fields">';
	$markup .= '<div class="tfi-field"><label for="tfi-name">Naam</label>[text* your-name id:tfi-name class:tfi-input autocomplete:name maxlength:100 placeholder "Je naam"]</div>';
	$markup .= '<div class="tfi-field"><label for="tfi-email">E-mailadres</label>[email* your-email id:tfi-email class:tfi-input autocomplete:email maxlength:150 placeholder "jij@voorbeeld.nl"]</div>';
	$markup .= '<div class="tfi-field"><label for="tfi-company">Bedrijfsnaam <span class="tfi-optional">(optioneel)</span></label>[text your-company id:tfi-company class:tfi-input autocomplete:organization maxlength:120 placeholder "Naam van je winkel"]</div>';
	$markup .= '<div class="tfi-field"><label for="tfi-message">Bericht</label>[textarea* your-message id:tfi-message class:tfi-input rows:4 minlength:5 maxlength:3000 placeholder "Waar wil je meer over weten?"]</div>';
	$markup .= '<div class="tfi-hp" aria-hidden="true"><label for="tfi-website">Laat dit veld leeg</label>[text tfi-website id:tfi-website tabindex:-1 autocomplete:off]</div>';
	$markup .= '<div class="tfi-consent">[acceptance tfi-consent id:tfi-consent] Ik ga ermee akkoord dat The Finest Impact mijn gegevens gebruikt om op mijn bericht te reageren. Lees de <a href="' . $privacy . '">privacyverklaring</a>.[/acceptance]</div>';
	$markup .= '<div class="tfi-actions"><button type="submit" class="wpcf7-submit tfi-btn"><span class="tfi-btn__label">Verstuur bericht</span><span class="tfi-btn__busy" aria-hidden="true">Versturen&hellip;</span><span class="tfi-btn__arrow" aria-hidden="true">&rarr;</span><span class="tfi-btn__spinner" aria-hidden="true"></span></button></div>';
	$markup .= '</div>';
	$markup .= '<div class="tfi-success" tabindex="-1"><svg class="tfi-check" viewBox="0 0 52 52" width="56" height="56" focusable="false" aria-hidden="true"><circle class="tfi-check__ring" cx="26" cy="26" r="24"/><path class="tfi-check__tick" d="M15 27l8 8 14-17"/></svg><p class="tfi-success__title">Bericht ontvangen</p><a class="tfi-again" href="/contact/">Nog een bericht sturen</a></div>';
	return $markup;
}

/**
 * Create the form once. Never recreated: if an editor deletes it in wp-admin
 * the option keeps the id, the check below fails, and the shortcode falls back
 * to the built-in form instead of silently re-adding a form someone removed.
 */
function finest_cf7_ensure_form() {
	if ( ! finest_cf7_active() || false !== get_option( 'finest_cf7_form_id', false ) ) {
		return;
	}
	if ( ! post_type_exists( 'wpcf7_contact_form' ) ) {
		return;
	}

	$form  = WPCF7_ContactForm::get_template( array( 'title' => 'TFI - Contactformulier' ) );
	$props = $form->get_properties();

	$props['form'] = finest_cf7_form_markup();

	$props['mail']['recipient']          = finest_contact_recipient();
	$props['mail']['subject']            = '[Website] Kennismaking aangevraagd door [your-name]';
	// Reply-To is the e-mail address only: a name containing a comma could
	// otherwise add extra reply addresses.
	$props['mail']['additional_headers'] = 'Reply-To: [your-email]';
	$props['mail']['body']               = "Naam: [your-name]\nE-mail: [your-email]\nBedrijf: [your-company]\n\nBericht:\n[your-message]\n\n-- \nVerzonden via het contactformulier op [_site_url] ([_date] [_time])";
	$props['mail']['use_html']           = 0;

	$props['messages'] = array_merge( $props['messages'], array(
		'mail_sent_ok'       => 'Bedankt voor je bericht. We nemen zo snel mogelijk contact met je op.',
		'mail_sent_ng'       => 'Je bericht kon niet worden verstuurd. Probeer het opnieuw, of mail ons op info@thefinestimpact.com.',
		'validation_error'   => 'Een of meer velden bevatten een fout. Controleer ze en probeer het opnieuw.',
		'spam'               => 'Dat ging iets te snel. Wacht even en probeer het opnieuw, of mail ons op info@thefinestimpact.com.',
		'accept_terms'       => 'Ga akkoord met de privacyverklaring om je bericht te kunnen versturen.',
		'invalid_required'   => 'Dit veld is verplicht.',
		'invalid_too_long'   => 'Dit veld is te lang.',
		'invalid_too_short'  => 'Dit veld is te kort.',
		'invalid_email'      => 'Vul een geldig e-mailadres in.',
	) );

	// Show the privacy checkbox as a normal validation error instead of
	// greying out the submit button.
	$props['additional_settings'] = "acceptance_as_validation: on\n";

	$form->set_properties( $props );
	$form->save();

	update_option( 'finest_cf7_form_id', (int) $form->id(), false );
}
add_action( 'init', 'finest_cf7_ensure_form', 30 );

/** The id of our CF7 form if it still exists, otherwise 0. */
function finest_cf7_form_id() {
	$id = (int) get_option( 'finest_cf7_form_id', 0 );
	return ( $id && 'wpcf7_contact_form' === get_post_type( $id ) ) ? $id : 0;
}

/**
 * Anti-abuse for OUR CF7 form only (other forms an editor builds are left
 * alone). CF7 calls wpcf7_spam only after validation passed, so typos never
 * burn a slot. Honeypot, then 3 per IP per 10 minutes, then 30 per hour for
 * the whole site.
 */
function finest_cf7_spam_check( $spam, $submission ) {
	if ( $spam || ! $submission ) {
		return $spam;
	}
	$form = $submission->get_contact_form();
	if ( ! $form || (int) $form->id() !== finest_cf7_form_id() ) {
		return $spam;
	}

	if ( '' !== trim( (string) $submission->get_posted_data( 'tfi-website' ) ) ) {
		return true;
	}

	$ip      = (string) $submission->get_meta( 'remote_ip' );
	$ip_key  = 'finest_cf7_rl_' . md5( $ip );
	$ip_hits = (int) get_transient( $ip_key );
	$all     = (int) get_transient( 'finest_cf7_rl_all' );
	if ( $ip_hits >= 3 || $all >= 30 ) {
		return true;
	}
	set_transient( $ip_key, $ip_hits + 1, 10 * MINUTE_IN_SECONDS );
	set_transient( 'finest_cf7_rl_all', $all + 1, HOUR_IN_SECONDS );

	return false;
}
add_filter( 'wpcf7_spam', 'finest_cf7_spam_check', 20, 2 );

/* -------------------------------------------------------------------------
 * Shortcode used on the Contact page
 * ---------------------------------------------------------------------- */

/** "Prefer chat?" line, shown under the form (the contact bar is hidden here). */
function finest_contact_alt_line() {
	$number = function_exists( 'finest_whatsapp_number' ) ? finest_whatsapp_number() : '';
	if ( '' === $number ) {
		return '';
	}
	$url = 'https://wa.me/' . $number . '?text=' . rawurlencode( 'Hallo The Finest Impact, ik heb een vraag.' );
	return '<p class="tfi-alt">Liever appen? <a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">Chat via WhatsApp<span class="screen-reader-text"> (opent in een nieuw tabblad)</span></a></p>';
}

function finest_contact_form_shortcode() {
	$cf7_id = finest_cf7_active() ? finest_cf7_form_id() : 0;
	if ( $cf7_id ) {
		$form = do_shortcode( '[contact-form-7 id="' . $cf7_id . '" html_class="tfi-form" html_title="Contactformulier"]' );
	} else {
		$form = finest_native_contact_form();
	}
	return '<div class="tfi-form-wrap">' . $form . finest_contact_alt_line() . '</div>';
}
add_shortcode( 'finest_contact_form', 'finest_contact_form_shortcode' );

/* -------------------------------------------------------------------------
 * Fallback: built-in form + handler (used when Contact Form 7 is not active)
 * ---------------------------------------------------------------------- */

/** Status shown after a redirect: code => [kind, message]. */
function finest_contact_statuses() {
	return array(
		'sent'    => array( 'success', 'Bedankt voor je bericht. We nemen zo snel mogelijk contact met je op.' ),
		'invalid' => array( 'error', 'Een of meer velden ontbreken of zijn te lang. Controleer ze en probeer het opnieuw.' ),
		'expired' => array( 'error', 'Deze pagina was te lang open. Ververs de pagina en probeer het opnieuw.' ),
		'rate'    => array( 'error', 'Dat ging iets te snel. Wacht even en probeer het opnieuw, of mail ons op info@thefinestimpact.com.' ),
		'failed'  => array( 'error', 'Je bericht kon niet worden verstuurd. Probeer het opnieuw, of mail ons op info@thefinestimpact.com.' ),
	);
}

function finest_native_contact_form() {
	$statuses = finest_contact_statuses();
	// Read-only status code, used only as a key into the fixed list above: no state is changed, so no nonce.
	$code     = isset( $_GET['finest_contact'] ) ? sanitize_key( wp_unslash( $_GET['finest_contact'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$status   = isset( $statuses[ $code ] ) ? $statuses[ $code ] : null;
	$privacy  = home_url( '/privacyverklaring/' );

	ob_start();
	?>
	<form class="tfi-form tfi-form--native<?php echo ( $status && 'success' === $status[0] ) ? ' is-sent' : ''; ?>" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-status="<?php echo $status ? ( 'success' === $status[0] ? 'sent' : 'failed' ) : 'init'; ?>">
		<div class="tfi-fields">
			<div class="tfi-field">
				<label for="tfi-name"><?php esc_html_e( 'Naam', 'finest-impact' ); ?></label>
				<input class="tfi-input" type="text" id="tfi-name" name="finest_name" required maxlength="100" autocomplete="name" placeholder="<?php esc_attr_e( 'Je naam', 'finest-impact' ); ?>">
			</div>
			<div class="tfi-field">
				<label for="tfi-email"><?php esc_html_e( 'E-mailadres', 'finest-impact' ); ?></label>
				<input class="tfi-input" type="email" id="tfi-email" name="finest_email" required maxlength="150" autocomplete="email" placeholder="<?php esc_attr_e( 'jij@voorbeeld.nl', 'finest-impact' ); ?>">
			</div>
			<div class="tfi-field">
				<label for="tfi-company"><?php esc_html_e( 'Bedrijfsnaam', 'finest-impact' ); ?> <span class="tfi-optional">(<?php esc_html_e( 'optioneel', 'finest-impact' ); ?>)</span></label>
				<input class="tfi-input" type="text" id="tfi-company" name="finest_company" maxlength="120" autocomplete="organization" placeholder="<?php esc_attr_e( 'Naam van je winkel', 'finest-impact' ); ?>">
			</div>
			<div class="tfi-field">
				<label for="tfi-message"><?php esc_html_e( 'Bericht', 'finest-impact' ); ?></label>
				<textarea class="tfi-input" id="tfi-message" name="finest_message" rows="4" required minlength="5" maxlength="3000" placeholder="<?php esc_attr_e( 'Waar wil je meer over weten?', 'finest-impact' ); ?>"></textarea>
			</div>
			<div class="tfi-hp" aria-hidden="true">
				<label for="tfi-website"><?php esc_html_e( 'Laat dit veld leeg', 'finest-impact' ); ?></label>
				<input type="text" id="tfi-website" name="finest_website" tabindex="-1" autocomplete="off">
			</div>
			<div class="tfi-consent">
				<label><input type="checkbox" name="finest_consent" value="1" required> <span>Ik ga ermee akkoord dat The Finest Impact mijn gegevens gebruikt om op mijn bericht te reageren. Lees de <a href="<?php echo esc_url( $privacy ); ?>">privacyverklaring</a>.</span></label>
			</div>
			<?php wp_nonce_field( 'finest_contact_form', 'finest_contact_nonce' ); ?>
			<input type="hidden" name="finest_contact_action" value="1">
			<div class="tfi-actions">
				<button type="submit" class="tfi-btn"><span class="tfi-btn__label">Verstuur bericht</span><span class="tfi-btn__busy" aria-hidden="true">Versturen&hellip;</span><span class="tfi-btn__arrow" aria-hidden="true">&rarr;</span><span class="tfi-btn__spinner" aria-hidden="true"></span></button>
			</div>
		</div>
		<?php if ( $status && 'success' === $status[0] ) : ?>
			<div class="tfi-success" tabindex="-1" role="status"><svg class="tfi-check" viewBox="0 0 52 52" width="56" height="56" focusable="false" aria-hidden="true"><circle class="tfi-check__ring" cx="26" cy="26" r="24"/><path class="tfi-check__tick" d="M15 27l8 8 14-17"/></svg><p class="tfi-success__title">Bericht ontvangen</p><a class="tfi-again" href="/contact/">Nog een bericht sturen</a></div>
		<?php endif; ?>
		<?php if ( $status ) : ?>
			<div class="wpcf7-response-output" role="<?php echo 'success' === $status[0] ? 'status' : 'alert'; ?>" id="tfi-response" tabindex="-1"><?php echo esc_html( $status[1] ); ?></div>
		<?php endif; ?>
	</form>
	<?php
	return ob_get_clean();
}

/** Back to the form with a status code (and the anchor so it is in view). */
function finest_contact_redirect( $code ) {
	$base = wp_get_referer() ?: home_url( '/contact/' );
	$base = remove_query_arg( 'finest_contact', $base );
	wp_safe_redirect( add_query_arg( 'finest_contact', $code, $base ) . '#tfi-response' );
	exit;
}

/**
 * Fallback handler. Runs before output so it can redirect (POST -> redirect ->
 * GET). Order matters: nonce, honeypot, VALIDATE, then rate limits, so a typo
 * never costs the visitor a waiting period.
 */
function finest_handle_contact_submission() {
	if ( empty( $_POST['finest_contact_action'] ) ) {
		return;
	}

	if ( ! isset( $_POST['finest_contact_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['finest_contact_nonce'] ) ), 'finest_contact_form' ) ) {
		finest_contact_redirect( 'expired' );
	}

	// Honeypot: a real visitor never fills this hidden field. Bots get "sent".
	if ( ! empty( $_POST['finest_website'] ) ) {
		finest_contact_redirect( 'sent' );
	}

	$name    = isset( $_POST['finest_name'] ) ? sanitize_text_field( wp_unslash( $_POST['finest_name'] ) ) : '';
	$email   = isset( $_POST['finest_email'] ) ? sanitize_email( wp_unslash( $_POST['finest_email'] ) ) : '';
	$company = isset( $_POST['finest_company'] ) ? sanitize_text_field( wp_unslash( $_POST['finest_company'] ) ) : '';
	$message = isset( $_POST['finest_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['finest_message'] ) ) : '';

	if ( '' === $name || ! is_email( $email ) || strlen( $message ) < 5 || empty( $_POST['finest_consent'] ) ||
		mb_strlen( $name ) > 100 || mb_strlen( $email ) > 150 || mb_strlen( $company ) > 120 || mb_strlen( $message ) > 3000 ) {
		finest_contact_redirect( 'invalid' );
	}

	// Rate limits (valid submissions only): 3 per IP per 10 minutes, 30 per hour site-wide.
	$ip      = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$ip_key  = 'finest_contact_rl_' . md5( $ip );
	$ip_hits = (int) get_transient( $ip_key );
	$all     = (int) get_transient( 'finest_contact_rl_all' );
	if ( $ip_hits >= 3 || $all >= 30 ) {
		finest_contact_redirect( 'rate' );
	}
	set_transient( $ip_key, $ip_hits + 1, 10 * MINUTE_IN_SECONDS );
	set_transient( 'finest_contact_rl_all', $all + 1, HOUR_IN_SECONDS );

	$subject = sprintf( '[Website] Kennismaking aangevraagd door %s', $name );
	$body    = "Naam: {$name}\nE-mail: {$email}\nBedrijf: {$company}\n\nBericht:\n{$message}";
	// Reply-To carries the address only: a comma or angle bracket in a name
	// must never be able to add extra reply recipients.
	$headers = array( 'Reply-To: ' . $email );

	$sent_ok = wp_mail( finest_contact_recipient(), $subject, $body, $headers );

	finest_contact_redirect( $sent_ok ? 'sent' : 'failed' );
}
add_action( 'template_redirect', 'finest_handle_contact_submission' );

/* -------------------------------------------------------------------------
 * Assets + admin hint
 * ---------------------------------------------------------------------- */

/** Loader / focus behaviour, only where the form lives. */
function finest_enqueue_contact_assets() {
	if ( ! is_page( 'contact' ) ) {
		return;
	}
	$path = FINEST_THEME_DIR . '/assets/js/contact-form.js';
	if ( file_exists( $path ) ) {
		wp_enqueue_script( 'finest-contact-form', FINEST_THEME_URI . '/assets/js/contact-form.js', array(), filemtime( $path ), array( 'strategy' => 'defer' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'finest_enqueue_contact_assets' );

/**
 * One dismissible hint for administrators when Contact Form 7 is missing: the
 * theme works without it (built-in form) but CF7 gives a form editor, spam
 * tools and the recipient setting.
 */
function finest_cf7_admin_notice() {
	if ( finest_cf7_active() || ! current_user_can( 'install_plugins' ) || get_user_meta( get_current_user_id(), 'finest_cf7_notice_dismissed', true ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'plugins', 'themes' ), true ) ) {
		return;
	}
	$install = admin_url( 'plugin-install.php?s=contact+form+7&tab=search&type=term' );
	$dismiss = wp_nonce_url( add_query_arg( 'finest_dismiss_cf7', '1' ), 'finest_dismiss_cf7' );
	echo '<div class="notice notice-info"><p><strong>The Finest Impact:</strong> het contactformulier gebruikt nu een eenvoudig ingebouwd formulier. Installeer <a href="' . esc_url( $install ) . '">Contact Form 7</a> (en daarbij <em>Flamingo</em> om berichten te bewaren) en het thema maakt automatisch een bewerkbaar formulier in dezelfde huisstijl. <a href="' . esc_url( $dismiss ) . '">Niet meer tonen</a></p></div>';
}
add_action( 'admin_notices', 'finest_cf7_admin_notice' );

function finest_cf7_notice_dismiss() {
	if ( isset( $_GET['finest_dismiss_cf7'] ) && current_user_can( 'install_plugins' ) && check_admin_referer( 'finest_dismiss_cf7' ) ) {
		update_user_meta( get_current_user_id(), 'finest_cf7_notice_dismissed', 1 );
	}
}
add_action( 'admin_init', 'finest_cf7_notice_dismiss' );

/**
 * Contact Form 7 wraps loose lines in <p> and adds <br> (its "autop"), which
 * puts paragraph margins inside our flex fields. Our template is already
 * structured HTML, so remove those wrappers for our form only.
 */
function finest_cf7_strip_autop( $html ) {
	if ( false === strpos( $html, 'class="tfi-fields"' ) ) {
		return $html;
	}
	$html = preg_replace( '#<p>(.*?)</p>#s', '$1', $html );
	return str_replace( array( '<br />', '<br>' ), '', $html );
}
add_filter( 'wpcf7_form_elements', 'finest_cf7_strip_autop', 20 );
