<?php
/**
 * Block patterns: ready-made sections in the inserter (+ > Patronen > The
 * Finest Impact) and animation styles for headings and images.
 *
 * The markup mirrors the sections the theme seeds on its own pages, so a new
 * section looks and moves exactly like an existing one. Photos point at the
 * theme's own files; replace them with your own via the block toolbar.
 *
 * @package finest-impact
 */

defined( 'ABSPATH' ) || exit;

/**
 * Animation choices in the block "Styles" panel. The motion layer
 * (assets/js/motion.js, style.css) treats these exactly like the fi-reveal
 * classes the seeded pages carry.
 */
function finest_register_motion_block_styles() {
	register_block_style(
		'core/heading',
		array(
			'name'  => 'fi-reveal-lines',
			'label' => __( 'Animatie: regel voor regel', 'finest-impact' ),
		)
	);
	register_block_style(
		'core/image',
		array(
			'name'  => 'fi-reveal',
			'label' => __( 'Animatie: onthullen', 'finest-impact' ),
		)
	);
}
add_action( 'init', 'finest_register_motion_block_styles' );

/**
 * Markup for the "button" used in every pattern.
 *
 * @param string $label Button text.
 * @param string $class Optional block style class (is-style-fi-outline).
 * @return string
 */
function finest_pattern_button( $label, $class = '' ) {
	$label = esc_html( $label );
	if ( '' === $class ) {
		return '<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">' . $label . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->';
	}
	return '<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"' . $class . '"} -->
<div class="wp-block-button ' . $class . '"><a class="wp-block-button__link wp-element-button" href="/contact/">' . $label . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->';
}

/**
 * Pattern definitions: slug => array( title, description, content ).
 *
 * @return array
 */
function finest_get_patterns() {
	$hero_img = esc_url( get_theme_file_uri( 'assets/img/photography/fotografie-website2.jpg' ) );
	$karin    = esc_url( get_theme_file_uri( 'assets/img/team/karin.jpg' ) );
	$manon    = esc_url( get_theme_file_uri( 'assets/img/team/manon.jpg' ) );

	$patterns = array();

	// 1. Hero.
	$patterns['hero'] = array(
		'title'       => __( 'Hero met foto', 'finest-impact' ),
		'description' => __( 'Paginabrede foto met kop, tekst en knop. Vervang de foto via de blokbalk (Vervangen). Bevat een eigen H1: kies bij de pagina het sjabloon Onepager, dan staat de titel er niet dubbel.', 'finest-impact' ),
		'content'     => '<!-- wp:cover {"url":"' . $hero_img . '","dimRatio":60,"overlayColor":"zwart","minHeight":640,"contentPosition":"bottom left","textColor":"linnen","className":"fi-hero-video","align":"full"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-bottom-left fi-hero-video has-linnen-color has-text-color" style="min-height:640px"><img class="wp-block-cover__image-background" alt="" src="' . $hero_img . '" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-zwart-background-color has-background-dim-60 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">Own your spotlight</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Jouw kop in één of twee regels</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Eén zin die uitlegt waar de pagina over gaat.</p>
<!-- /wp:paragraph -->

' . finest_pattern_button( 'Plan een kennismaking' ) . '</div></div>
<!-- /wp:cover -->',
	);

	// 2. Page intro.
	$patterns['intro'] = array(
		'title'       => __( 'Paginakop met inleiding', 'finest-impact' ),
		'description' => __( 'Grote kop met een korte inleiding, zoals bovenaan Diensten en Over ons. Bevat een eigen H1: kies bij de pagina het sjabloon Onepager.', 'finest-impact' ),
		'content'     => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--50)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Titel van de pagina</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Inleidende zin die de pagina samenvat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Eventueel een alinea extra uitleg.</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->',
	);

	// 3-6. Text + scroll-driven diagram (one pattern per diagram).
	$scenes = array(
		'stats'   => array( __( 'Zichtbaarheid (cirkels)', 'finest-impact' ), false ),
		'mess'    => array( __( 'Chaos naar ritme (blokjes)', 'finest-impact' ), false ),
		'hub'     => array( __( 'Eén hub (netwerk)', 'finest-impact' ), true ),
		'balance' => array( __( 'Mens en AI (balans)', 'finest-impact' ), false ),
	);
	foreach ( $scenes as $scene => $info ) {
		$class = 'explainer-grid' . ( $info[1] ? ' explainer-grid--reverse' : '' );
		$patterns[ 'diagram-' . $scene ] = array(
			/* translators: %s: name of the animated diagram. */
			'title'       => sprintf( __( 'Tekst met diagram: %s', 'finest-impact' ), $info[0] ),
			'description' => __( 'Tekst naast een tekening die meebeweegt met het scrollen. De tekening zelf is vast; de tekst pas je aan.', 'finest-impact' ),
			'content'     => '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:group {"align":"wide","className":"' . $class . '","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide ' . $class . '">

<!-- wp:html -->
<div class="explainer-canvas" data-scene="' . esc_attr( $scene ) . '" aria-hidden="true"><canvas></canvas></div>
<!-- /wp:html -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Kop van deze sectie</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Leg hier in een paar alinea\'s uit waar het om gaat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Eén zin om te onthouden.</strong></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->',
		);
	}

	// 7. Steps.
	$step = static function ( $n ) {
		return '<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">' . $n . '. Titel van de stap</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Korte uitleg van wat er in deze stap gebeurt.</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->';
	};
	$patterns['stappen'] = array(
		'title'       => __( 'Vier stappen naast elkaar', 'finest-impact' ),
		'description' => __( 'Beige band met een kop en vier genummerde stappen; onder elkaar op een telefoon.', 'finest-impact' ),
		'content'     => '<!-- wp:group {"align":"full","backgroundColor":"klei","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-klei-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Hoe gaan we te werk?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Eén zin die de stappen inleidt.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"align":"wide","className":"fi-steps"} -->
<div class="wp-block-columns alignwide fi-steps">

' . $step( 1 ) . '

' . $step( 2 ) . '

' . $step( 3 ) . '

' . $step( 4 ) . '

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->',
	);

	// 8. FAQ.
	$faq = static function ( $q ) {
		return '<!-- wp:details -->
<details class="wp-block-details"><summary>' . $q . '</summary>
<!-- wp:paragraph -->
<p>Het antwoord op deze vraag.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->';
	};
	$patterns['faq'] = array(
		'title'       => __( 'Veelgestelde vragen', 'finest-impact' ),
		'description' => __( 'Uitklapbare vragen met plus-teken. Een vraag erbij: kopieer een rij.', 'finest-impact' ),
		'content'     => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Veelgestelde vragen</h2>
<!-- /wp:heading -->

' . $faq( 'Eerste vraag?' ) . '

' . $faq( 'Tweede vraag?' ) . '

' . $faq( 'Derde vraag?' ) . '

' . finest_pattern_button( 'Plan een demo' ) . '
</div>
<!-- /wp:group -->',
	);

	// 9. Team cards.
	$member = static function ( $img, $name ) {
		return '<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"finest-team-photo"} -->
<figure class="wp-block-image size-large finest-team-photo"><img src="' . $img . '" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">' . $name . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Functie</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">+31 6 12 34 56 78<br><a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->';
	};
	$patterns['team'] = array(
		'title'       => __( 'Teamkaarten', 'finest-impact' ),
		'description' => __( 'Twee teamleden naast elkaar met foto, naam, functie en contact. Vervang de foto\'s en teksten.', 'finest-impact' ),
		'content'     => '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Ontmoet ons team</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">

' . $member( $karin, 'Voornaam Achternaam' ) . '

' . $member( $manon, 'Voornaam Achternaam' ) . '

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->',
	);

	// 10. Dark call-to-action band.
	$patterns['cta-band'] = array(
		'title'       => __( 'Zwarte band met oproep', 'finest-impact' ),
		'description' => __( 'Paginabrede zwarte sectie met kop, tekst en een knop met rand.', 'finest-impact' ),
		'content'     => '<!-- wp:group {"align":"full","backgroundColor":"zwart","textColor":"linnen","className":"is-style-fi-dark-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">

<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">Own your spotlight</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Kop met de belangrijkste boodschap</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Een korte alinea die uitlegt waarom de bezoeker contact moet opnemen.</p>
<!-- /wp:paragraph -->

' . finest_pattern_button( 'Plan een kennismaking' ) . '
</div>
<!-- /wp:group -->',
	);

	// 11. Latest news cards.
	$patterns['nieuws'] = array(
		'title'       => __( 'Laatste nieuws (3 kaarten)', 'finest-impact' ),
		'description' => __( 'De drie nieuwste nieuwsberichten als kaarten; wordt vanzelf bijgewerkt.', 'finest-impact' ),
		'content'     => '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Laatste nieuws</h2>
<!-- /wp:heading -->

<!-- wp:query {"query":{"postType":"post","perPage":3,"orderBy":"date","order":"desc","inherit":false},"align":"wide","className":"finest-blog-grid"} -->
<div class="wp-block-query alignwide finest-blog-grid">

<!-- wp:post-template {"className":"finest-blog-grid__track"} -->
<!-- wp:group {"className":"finest-blog-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-blog-card">
<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"finest-card","className":"finest-blog-card__media"} /-->
<!-- wp:post-terms {"term":"nieuws_categorie","fontSize":"label","className":"finest-blog-card__cat"} /-->
<!-- wp:post-title {"isLink":true,"level":3,"fontSize":"medium","className":"finest-blog-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":18,"className":"finest-blog-card__excerpt"} /-->
<!-- wp:post-date {"fontSize":"label","className":"finest-blog-card__date"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template -->

</div>
<!-- /wp:query -->

</div>
<!-- /wp:group -->',
	);

	return $patterns;
}

/**
 * Register the patterns.
 */
function finest_register_patterns() {
	foreach ( finest_get_patterns() as $slug => $pattern ) {
		register_block_pattern(
			'finest-impact/' . $slug,
			array(
				'title'       => $pattern['title'],
				'description' => $pattern['description'],
				'categories'  => array( 'finest-impact' ),
				'content'     => $pattern['content'],
			)
		);
	}
}
add_action( 'init', 'finest_register_patterns', 20 );
