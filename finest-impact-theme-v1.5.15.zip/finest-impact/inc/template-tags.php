<?php
/**
 * Small, pure helper functions shared across templates and provisioning.
 * Keep logic here instead of duplicating it per template (Fase 4 rule).
 */

defined( 'ABSPATH' ) || exit;

/**
 * "Meer uit The Finest News" at the bottom of templates/single.html: a real
 * core/query block (not hardcoded links), scoped to the className
 * finest-related-posts. On its own, a Query Loop block can't express
 * "posts sharing a taxonomy term with the post currently being viewed" —
 * that's not something the block's own UI (or its stored query attrs) can
 * represent, since it depends on which single post is being rendered. This
 * filter is core's own supported extension point for exactly that case
 * (query_loop_block_query_vars, since WP 5.9): it runs once per Query
 * block render and only touches the block carrying our className, so every
 * other Query Loop in the theme (the Nieuws/Klantverhalen overview grids,
 * the archive/search templates) is completely unaffected.
 *
 * Falls back to "latest posts, excluding this one" when the current post
 * has no nieuws_categorie terms set yet, rather than an empty tax_query
 * that would silently match nothing.
 */
function finest_related_posts_query_vars( $query, $block ) {
	if ( ! is_singular( 'post' ) ) {
		return $query;
	}
	$class = isset( $block->parsed_block['attrs']['className'] ) ? $block->parsed_block['attrs']['className'] : '';
	if ( false === strpos( (string) $class, 'finest-related-posts' ) ) {
		return $query;
	}

	$post_id = get_the_ID();
	$query['post__not_in'] = array( $post_id );

	$terms = get_the_terms( $post_id, 'nieuws_categorie' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		$query['tax_query'] = array(
			array(
				'taxonomy' => 'nieuws_categorie',
				'field'    => 'term_id',
				'terms'    => wp_list_pluck( $terms, 'term_id' ),
			),
		);
	}

	return $query;
}
add_filter( 'query_loop_block_query_vars', 'finest_related_posts_query_vars', 10, 2 );


/**
 * Mark the menu item for the page being viewed (aria-current + the
 * current-menu-item class). Menu links here are plain URLs, which core does
 * not highlight on its own. Posts count as "Nieuws", klantverhalen as
 * "Klantverhalen"; child pages match their parent. The result is plain HTML,
 * so it works without JavaScript.
 *
 * @param string $block_content Rendered navigation-link block.
 * @param array  $block         Parsed block.
 * @return string
 */
function finest_mark_current_nav_item( $block_content, $block ) {
	if ( '' === $block_content || empty( $block['attrs']['url'] ) ) {
		return $block_content;
	}

	$link = (string) wp_parse_url( $block['attrs']['url'], PHP_URL_PATH );
	if ( '' === $link || '/' === $link ) {
		return $block_content;
	}
	$link = trailingslashit( $link );

	$section = '';
	if ( is_singular( 'page' ) ) {
		$section = get_permalink( get_queried_object_id() );
	} elseif ( is_singular( 'post' ) || is_home() || is_category() || is_tag() || is_tax( 'nieuws_categorie' ) ) {
		$page    = get_page_by_path( 'nieuws' );
		$section = $page ? get_permalink( $page ) : '';
	} elseif ( is_singular( 'klantverhaal' ) || is_post_type_archive( 'klantverhaal' ) ) {
		$page    = get_page_by_path( 'klantverhalen' );
		$section = $page ? get_permalink( $page ) : '';
	}
	if ( ! $section ) {
		return $block_content;
	}

	$here = trailingslashit( (string) wp_parse_url( $section, PHP_URL_PATH ) );
	if ( 0 !== strpos( $here, $link ) ) {
		return $block_content;
	}

	$processor = new WP_HTML_Tag_Processor( $block_content );
	if ( $processor->next_tag( 'li' ) ) {
		$processor->add_class( 'current-menu-item' );
	}
	if ( $processor->next_tag( 'a' ) ) {
		$processor->set_attribute( 'aria-current', 'page' );
	}
	return $processor->get_updated_html();
}
add_filter( 'render_block_core/navigation-link', 'finest_mark_current_nav_item', 10, 2 );
