<?php
/**
 * Settings page "Weergave > Beweging": scroll and animation behaviour.
 *
 * Stored in one option (finest_motion). The values reach assets/js/motion.js
 * as window.FINEST_MOTION; reduced-motion visitors are always respected on top
 * of these choices. Developers can override everything with the
 * finest_motion_settings filter.
 *
 * @package finest-impact
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default values.
 *
 * @return array
 */
function finest_motion_defaults() {
	return array(
		'animations'     => true,  // Master switch: off behaves like "reduce motion".
		'smoothScroll'   => true,  // Soft wheel/trackpad scrolling (Lenis).
		'smoothDuration' => 1.1,   // Seconds a scroll takes to settle.
		'reveals'        => true,  // Headings, photos and cards animate in.
		'pinnedRail'     => true,  // Optiek Stories scrolls sideways on desktop.
		'progressBar'    => true,  // Thin line at the top showing page progress.
	);
}

/**
 * Current settings (saved values over defaults).
 *
 * @return array
 */
function finest_motion_settings() {
	static $cache = null;
	if ( null === $cache ) {
		$saved = get_option( 'finest_motion', array() );
		$saved = is_array( $saved ) ? $saved : array();
		$cache = finest_motion_sanitize( array_merge( finest_motion_defaults(), $saved ), false );
		$cache = apply_filters( 'finest_motion_settings', $cache );
	}
	return $cache;
}

/**
 * Sanitise submitted (or stored) values.
 *
 * @param mixed $input        Raw values.
 * @param bool  $from_form    True when the values come from the settings form,
 *                            where an unticked checkbox is simply absent.
 * @return array
 */
function finest_motion_sanitize( $input, $from_form = true ) {
	$input    = is_array( $input ) ? $input : array();
	$defaults = finest_motion_defaults();
	$out      = array();
	foreach ( array( 'animations', 'smoothScroll', 'reveals', 'pinnedRail', 'progressBar' ) as $key ) {
		if ( $from_form ) {
			$out[ $key ] = ! empty( $input[ $key ] );
		} else {
			$out[ $key ] = isset( $input[ $key ] ) ? (bool) $input[ $key ] : $defaults[ $key ];
		}
	}
	$duration              = isset( $input['smoothDuration'] ) ? (float) str_replace( ',', '.', (string) $input['smoothDuration'] ) : $defaults['smoothDuration'];
	$out['smoothDuration'] = min( 3.0, max( 0.3, $duration ) );
	return $out;
}

/**
 * Pass the settings to motion.js.
 */
function finest_motion_inline_config() {
	if ( wp_script_is( 'finest-motion', 'enqueued' ) ) {
		$cfg = finest_motion_settings();
		wp_add_inline_script( 'finest-motion', 'window.FINEST_MOTION=' . wp_json_encode( $cfg ) . ';', 'before' );
	}
}
add_action( 'wp_enqueue_scripts', 'finest_motion_inline_config', 20 );

/**
 * Register the option and its page.
 */
function finest_motion_register_settings() {
	register_setting(
		'finest_motion_group',
		'finest_motion',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'finest_motion_sanitize',
			'default'           => finest_motion_defaults(),
		)
	);
}
add_action( 'admin_init', 'finest_motion_register_settings' );

/**
 * Menu entry under Weergave.
 */
function finest_motion_menu() {
	add_theme_page(
		__( 'Beweging en scrollen', 'finest-impact' ),
		__( 'Beweging', 'finest-impact' ),
		'edit_theme_options',
		'finest-motion',
		'finest_motion_render_page'
	);
}
add_action( 'admin_menu', 'finest_motion_menu' );

/**
 * Settings page.
 */
function finest_motion_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$s = finest_motion_settings();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Beweging en scrollen', 'finest-impact' ); ?></h1>
		<?php settings_errors(); ?>
		<p><?php esc_html_e( 'Bepaal hoe de site beweegt. Bezoekers die "beweging verminderen" in hun apparaat hebben aangezet, zien nooit animaties, wat je hier ook kiest.', 'finest-impact' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'finest_motion_group' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Animaties', 'finest-impact' ); ?></th>
					<td><label><input type="checkbox" name="finest_motion[animations]" value="1" <?php checked( $s['animations'] ); ?>> <?php esc_html_e( 'Animaties aan (uit = alles staat meteen op zijn plek)', 'finest-impact' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Zacht scrollen', 'finest-impact' ); ?></th>
					<td>
						<label><input type="checkbox" name="finest_motion[smoothScroll]" value="1" <?php checked( $s['smoothScroll'] ); ?>> <?php esc_html_e( 'Zacht uitlopend scrollen met muiswiel of trackpad', 'finest-impact' ); ?></label>
						<p class="description"><?php esc_html_e( 'Uit = het scrollen van de browser zelf. Op een telefoon scrolt het toestel altijd zelf.', 'finest-impact' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="finest-motion-duration"><?php esc_html_e( 'Duur van het uitlopen', 'finest-impact' ); ?></label></th>
					<td>
						<input id="finest-motion-duration" type="number" min="0.3" max="3" step="0.1" name="finest_motion[smoothDuration]" value="<?php echo esc_attr( $s['smoothDuration'] ); ?>" class="small-text"> <?php esc_html_e( 'seconden', 'finest-impact' ); ?>
						<p class="description"><?php esc_html_e( 'Lager voelt directer (0,6), hoger voelt zachter (1,6). Standaard 1,1.', 'finest-impact' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Tekst en foto\'s', 'finest-impact' ); ?></th>
					<td><label><input type="checkbox" name="finest_motion[reveals]" value="1" <?php checked( $s['reveals'] ); ?>> <?php esc_html_e( 'Koppen, foto\'s en kaarten verschijnen met een animatie tijdens het scrollen', 'finest-impact' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Optiek Stories', 'finest-impact' ); ?></th>
					<td><label><input type="checkbox" name="finest_motion[pinnedRail]" value="1" <?php checked( $s['pinnedRail'] ); ?>> <?php esc_html_e( 'Op desktop schuift de rij zijwaarts terwijl je omlaag scrolt', 'finest-impact' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Voortgangslijn', 'finest-impact' ); ?></th>
					<td><label><input type="checkbox" name="finest_motion[progressBar]" value="1" <?php checked( $s['progressBar'] ); ?>> <?php esc_html_e( 'Dunne lijn bovenaan die laat zien hoever je op de pagina bent', 'finest-impact' ); ?></label></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
