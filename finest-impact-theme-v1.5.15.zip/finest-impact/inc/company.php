<?php
/**
 * Company details for the legal pages (KvK, btw, address).
 *
 * Dutch law (art. 3:15d BW) wants the legal name, establishment address, KvK
 * number and VAT number on a business website. They are real facts that only
 * the company can supply, so the theme does not invent them: they are
 * settings (Settings > General > Bedrijfsgegevens) shown through the
 * [finest_company_details] shortcode on the Algemene voorwaarden and
 * Privacyverklaring pages. An empty value is omitted for visitors and shown as
 * a reminder to administrators only.
 *
 * Defaults can be shipped via the finest_company_defaults filter.
 */

defined( 'ABSPATH' ) || exit;

function finest_company_defaults() {
	return (array) apply_filters( 'finest_company_defaults', array(
		'name'    => 'The Finest Impact',
		'kvk'     => '',
		'vat'     => '',
		'address' => '',
	) );
}

function finest_company_field( $key ) {
	$defaults = finest_company_defaults();
	return trim( (string) get_option( 'finest_company_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' ) );
}

function finest_company_labels() {
	return array(
		'name'    => __( 'Bedrijfsnaam (juridisch, bijv. met B.V.)', 'finest-impact' ),
		'kvk'     => __( 'KvK-nummer', 'finest-impact' ),
		'vat'     => __( 'Btw-nummer', 'finest-impact' ),
		'address' => __( 'Vestigingsadres', 'finest-impact' ),
	);
}

function finest_register_company_settings() {
	foreach ( finest_company_labels() as $key => $label ) {
		register_setting( 'general', 'finest_company_' . $key, array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
		) );
		add_settings_field(
			'finest_company_' . $key,
			$label,
			'finest_company_setting_field',
			'general',
			'default',
			array( 'key' => $key, 'label_for' => 'finest_company_' . $key )
		);
	}
}
add_action( 'admin_init', 'finest_register_company_settings' );

function finest_company_setting_field( $args ) {
	$key = $args['key'];
	printf(
		'<input type="text" class="regular-text" id="finest_company_%1$s" name="finest_company_%1$s" value="%2$s" autocomplete="off">',
		esc_attr( $key ),
		esc_attr( finest_company_field( $key ) )
	);
	if ( 'kvk' === $key ) {
		echo '<p class="description">' . esc_html__( 'Gebruikt op de pagina’s Algemene voorwaarden en Privacyverklaring.', 'finest-impact' ) . '</p>';
	}
}

/**
 * [finest_company_details fields="name,kvk,vat,address"]: one paragraph, one
 * line per filled-in field, then the e-mail address.
 */
function finest_company_details_shortcode( $atts ) {
	$atts   = shortcode_atts( array( 'fields' => 'name,kvk,vat,address' ), $atts, 'finest_company_details' );
	$fields = array_filter( array_map( 'trim', explode( ',', $atts['fields'] ) ) );
	$labels = array(
		'kvk'     => 'KvK-nummer',
		'vat'     => 'Btw-nummer',
		'address' => 'Vestigingsadres',
	);
	$is_admin_viewer = current_user_can( 'manage_options' );
	$lines           = array();

	foreach ( $fields as $key ) {
		if ( ! isset( $labels[ $key ] ) && 'name' !== $key ) {
			continue;
		}
		$value = finest_company_field( $key );
		if ( '' === $value ) {
			if ( $is_admin_viewer && 'name' !== $key ) {
				$lines[] = '<mark class="tfi-todo">' . esc_html( $labels[ $key ] ) . ': ' . esc_html__( '[nog in te vullen via Instellingen → Algemeen]', 'finest-impact' ) . '</mark>';
			}
			continue;
		}
		$lines[] = ( 'name' === $key )
			? '<strong>' . esc_html( $value ) . '</strong>'
			: esc_html( $labels[ $key ] ) . ': ' . esc_html( $value );
	}

	$email   = finest_contact_recipient();
	$lines[] = 'E-mail: <a href="' . esc_url( 'mailto:' . $email ) . '">' . esc_html( $email ) . '</a>';

	return '<p class="tfi-company">' . implode( '<br>', $lines ) . '</p>';
}
add_shortcode( 'finest_company_details', 'finest_company_details_shortcode' );
