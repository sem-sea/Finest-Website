<?php
/**
 * Legal pages. Marked as a concept until a lawyer has reviewed them.
 *
 * Facts only the company can supply (legal name, KvK, btw, address) are NOT
 * invented: they are settings (inc/company.php) rendered by the
 * [finest_company_details] shortcode. The wording of the terms (duration,
 * liability) and of the privacy statement (legal basis, recipients, retention)
 * is a proposal based on common Dutch B2B practice; the business can change any
 * of it in the page editor.
 */

defined( 'ABSPATH' ) || exit;

function finest_legal_concept_notice() {
	return <<<'HTML'
<!-- wp:group {"backgroundColor":"klei","style":{"border":{"width":"1px"},"spacing":{"padding":{"top":"20px","bottom":"20px","left":"24px","right":"24px"},"margin":{"bottom":"var:preset|spacing|40"}}},"borderColor":"rand","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-rand-border-color has-klei-background-color has-background" style="border-width:1px;margin-bottom:var(--wp--preset--spacing--40);padding-top:20px;padding-right:24px;padding-bottom:20px;padding-left:24px">
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><strong>Concept: nog niet juridisch gecontroleerd.</strong> Deze pagina is een startpunt. De bedrijfsgegevens (KvK-nummer, btw-nummer, vestigingsadres) vul je in via Instellingen → Algemeen. Laat de tekst controleren door een jurist voordat de site live gaat.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
HTML;
}

function finest_algemene_voorwaarden_content() {
	$notice = finest_legal_concept_notice();
	return <<<HTML
{$notice}

<!-- wp:heading {"level":1,"fontSize":"kop"} -->
<h1 class="wp-block-heading has-kop-font-size">Algemene Voorwaarden</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Deze algemene voorwaarden zijn van toepassing op alle overeenkomsten tussen The Finest Impact ("wij", "ons") en de opdrachtgever ("jij", "je") met betrekking tot het gebruik van het marketingplatform en de bijbehorende dienstverlening.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">1. Wie we zijn</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[finest_company_details fields="name,kvk,vat,address"]
<!-- /wp:shortcode -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">2. De dienst</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The Finest Impact is een marketingplatform voor onafhankelijke opticiens. De precieze omvang van de dienstverlening (strategie, content, campagnes, koppelingen met bestaande systemen) wordt per klant vastgesteld tijdens de kennismaking en strategische marketing sessie, en vastgelegd in een aparte overeenkomst of offerte.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">3. Menselijke controle over gepubliceerde content</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The Finest Impact publiceert niet zelfstandig namens de opdrachtgever. De opdrachtgever behoudt te allen tijde de controle over welke content, campagnes en communicatie daadwerkelijk naar buiten gaan. Door content goed te keuren of te laten publiceren, blijf je er zelf verantwoordelijk voor dat die correct is en voldoet aan de wet; wij controleren content niet op juridische juistheid.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">4. Looptijd en opzegging</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>De overeenkomst gaat in op de datum in de offerte of overeenkomst en loopt voor de daarin genoemde initiële looptijd. Staat er geen looptijd in de offerte, dan is de initiële looptijd twaalf maanden.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Na de initiële looptijd wordt de overeenkomst telkens stilzwijgend verlengd met dezelfde periode, tenzij een van ons uiterlijk één maand vóór het einde van de lopende periode schriftelijk heeft opgezegd. Opzeggen per e-mail volstaat. Tussentijds opzeggen is niet mogelijk, behalve als een van ons ernstig tekortschiet en dat na een schriftelijke ingebrekestelling niet binnen een redelijke termijn herstelt.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">5. Aansprakelijkheid</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Onze totale aansprakelijkheid voor schade die voortvloeit uit of verband houdt met de overeenkomst is beperkt tot directe schade, en tot het bedrag dat je ons in de twaalf maanden vóór de gebeurtenis voor de dienst hebt betaald.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Wij zijn niet aansprakelijk voor indirecte schade, zoals gederfde winst, gemiste omzet, gemiste besparingen of reputatieschade. Deze beperkingen gelden niet bij opzet of bewuste roekeloosheid van ons of onze leidinggevenden, en niet voor zover de wet aansprakelijkheid niet toestaat uit te sluiten. Meld schade zo snel mogelijk schriftelijk, in elk geval binnen een redelijke termijn nadat je die hebt ontdekt.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">6. Toepasselijk recht en geschillen</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Op deze voorwaarden is Nederlands recht van toepassing. Geschillen leggen we voor aan de bevoegde rechter in het arrondissement waar wij gevestigd zijn, nadat we eerst hebben geprobeerd er samen uit te komen.</p>
<!-- /wp:paragraph -->
HTML;
}

function finest_privacyverklaring_content() {
	$notice = finest_legal_concept_notice();
	return <<<HTML
{$notice}

<!-- wp:heading {"level":1,"fontSize":"kop"} -->
<h1 class="wp-block-heading has-kop-font-size">Privacyverklaring</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The Finest Impact respecteert je privacy. Deze verklaring beschrijft welke persoonsgegevens deze website verzamelt, waarom, en hoe je je rechten kunt uitoefenen.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Wie is verantwoordelijk?</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[finest_company_details fields="name,kvk,address"]
<!-- /wp:shortcode -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Welke gegevens verzamelen we, en waarom</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Deze verklaring beschrijft alleen de gegevens die deze website daadwerkelijk verzamelt: geen algemene claims over cookies of tracking die niet gebruikt worden.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item --><li><strong>Contactformulier.</strong> Wanneer je het contactformulier invult, verwerken we je naam, e-mailadres, bedrijfsnaam (optioneel) en bericht, uitsluitend om te reageren op je aanvraag. Het bericht komt per e-mail bij ons binnen en we gebruiken het niet voor andere doeleinden.</li><!-- /wp:list-item -->
<!-- wp:list-item --><li><strong>WhatsApp.</strong> De WhatsApp-knop is een gewone link. Pas als je erop klikt, verlaat je deze website en start je een gesprek via WhatsApp (Meta). Voor dat gesprek gelden de voorwaarden en het privacybeleid van WhatsApp. Wij verwerken alleen wat je ons zelf in dat gesprek stuurt, uitsluitend om je vraag te beantwoorden.</li><!-- /wp:list-item -->
<!-- wp:list-item --><li><strong>Cookies.</strong> Deze website gebruikt alleen strikt noodzakelijke, functionele cookies (bijvoorbeeld voor de beveiliging van formulieren). Hiervoor is geen toestemming vereist. Er zijn geen analytics-, marketing- of trackingcookies actief. Gaan we die later inzetten, dan vragen we eerst je toestemming en passen we deze verklaring aan.</li><!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Op welke grondslag verwerken we je gegevens?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Voor het contactformulier is dat je toestemming (het vinkje onder het formulier) en ons gerechtvaardigd belang om zakelijke vragen te beantwoorden. Je kunt je toestemming altijd intrekken door ons te mailen.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Met wie delen we je gegevens?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Alleen met partijen die we nodig hebben om de website en onze e-mail te laten werken, zoals onze hosting- en e-mailprovider. Met hen hebben we afspraken over de bescherming van je gegevens. Als je op de WhatsApp-knop klikt, verwerkt WhatsApp (Meta) je gegevens onder eigen verantwoordelijkheid, mogelijk ook buiten de Europese Unie. We verkopen je gegevens niet.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Bewaartermijn</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Berichten via het contactformulier bewaren we niet langer dan nodig is om je vraag af te handelen, en uiterlijk twaalf maanden daarna. Komt er een overeenkomst uit voort, dan bewaren we de gegevens die we daarvoor nodig hebben zo lang als de wet vereist (voor de administratie meestal zeven jaar).</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Jouw rechten</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Je hebt het recht om inzage, correctie of verwijdering van je persoonsgegevens te vragen, om de verwerking te beperken, om bezwaar te maken en om je gegevens over te laten dragen. Neem hiervoor contact op via <a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a>. We reageren binnen een maand. Ben je het niet eens met hoe we met je gegevens omgaan, dan kun je een klacht indienen bij de <a href="https://autoriteitpersoonsgegevens.nl" target="_blank" rel="noopener">Autoriteit Persoonsgegevens</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Klantgegevens binnen het platform</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Voor gegevens die klanten van The Finest Impact via het platform zelf verwerken (bijvoorbeeld gekoppelde kassa- of nieuwsbriefsystemen) geldt een aparte verwerkersovereenkomst, buiten de scope van deze websiteprivacyverklaring.</p>
<!-- /wp:paragraph -->
HTML;
}
