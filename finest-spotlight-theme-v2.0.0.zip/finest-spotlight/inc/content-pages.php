<?php
/**
 * Real page content (Gutenberg block markup) sourced from the client's own
 * "Website teksten + briefing versie def" document; nothing here is
 * invented (Fase 8). Legal pages are the one exception the client
 * explicitly approved: a concept, clearly marked as such, since no legal
 * text was supplied in the briefing.
 *
 * Every function returns plain block-comment markup so it round-trips
 * through the block editor exactly like content a person typed by hand.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Full-bleed, editable image block for a photo already sideloaded into the
 * media library via finest_ensure_photo(). fi-reveal is purely a motion hook
 * (see assets/js/motion.js) — removing it in the block editor just turns
 * off the entrance animation, the image itself is a normal attachment.
 *
 * The <img> is deliberately the bare markup core/image's own save() writes
 * (src, alt, class="wp-image-ID" — nothing else). An earlier version
 * hand-built the tag with wp_get_attachment_image() so it carried
 * srcset/sizes/width/height/loading/decoding; Gutenberg's block validator
 * compares the stored HTML attribute-for-attribute against what save()
 * would emit, so every one of those extras made the block "invalid" the
 * moment a client opened the page in the editor. Nothing is lost by
 * dropping them: WordPress adds srcset, sizes, width/height (layout-shift
 * safe) and the right loading/fetchpriority hints itself, at render time,
 * to any content <img> that carries a wp-image-ID class.
 *
 * @param bool $decorative True for ambient brand photography that adds
 *                          no information beyond what the surrounding
 *                          copy already says (WCAG 2.2 SC 1.1.1 — such
 *                          images should carry alt="", not a media
 *                          library caption repeated as prose).
 */
function finest_photo_block( $attachment_id, $decorative = false ) {
	if ( ! $attachment_id ) {
		return '';
	}
	$url = wp_get_attachment_image_url( $attachment_id, 'full' );
	if ( ! $url ) {
		return '';
	}
	$url = esc_url( $url );
	$alt = esc_attr( $decorative ? '' : get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
	return <<<HTML
<!-- wp:image {"id":{$attachment_id},"sizeSlug":"full","linkDestination":"none","align":"full","className":"fi-reveal"} -->
<figure class="wp-block-image alignfull size-full fi-reveal"><img src="{$url}" alt="{$alt}" class="wp-image-{$attachment_id}"/></figure>
<!-- /wp:image -->
HTML;
}

/**
 * Small, non-full-bleed portrait for a team member card. Same idea as
 * finest_photo_block() but aligned "none" (sits inside the column) and
 * tagged with finest-team-photo instead of fi-reveal, since the team grid
 * fades in as a group via its wrapping section, not per-photo.
 */
function finest_team_photo_block( $attachment_id ) {
	if ( ! $attachment_id ) {
		return '';
	}
	$url = wp_get_attachment_image_url( $attachment_id, 'large' );
	if ( ! $url ) {
		return '';
	}
	$url = esc_url( $url );
	$alt = esc_attr( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
	return <<<HTML
<!-- wp:image {"id":{$attachment_id},"sizeSlug":"large","linkDestination":"none","className":"finest-team-photo"} -->
<figure class="wp-block-image size-large finest-team-photo"><img src="{$url}" alt="{$alt}" class="wp-image-{$attachment_id}"/></figure>
<!-- /wp:image -->
HTML;
}

/**
 * Wraps a sequence of already-built blocks (heading/paragraphs/button) in a
 * two-column "explainer-grid" alongside a sticky scroll-driven canvas
 * diagram (assets/js/explainers.js), matching the four homepage sections
 * it's built for — $scene must be one of the keys explainers.js's `scenes`
 * map knows: stats | mess | hub | balance. The canvas itself is a `<canvas>`
 * element with no content of its own (aria-hidden), so it carries no
 * information not already present in $text_html — screen readers and
 * no-JS visitors get the identical copy, just without the animated
 * companion graphic (see explainers.js header comment: it degrades to a
 * static drawn end-state under prefers-reduced-motion, and to nothing at
 * all if JS/GSAP/ScrollTrigger never load, which is fine since aria-hidden
 * already takes it out of the accessibility tree either way).
 *
 * On mobile (<900px) the two-column CSS grid collapses to one column and
 * the canvas is no longer position:sticky (see .explainer-canvas in
 * style.css) — it scrolls normally above its text, which is why
 * explainers.js ties its scroll progress to two different ScrollTrigger
 * instances (gsap.matchMedia breakpoints) rather than one.
 *
 * @param string $scene     stats | mess | hub | balance.
 * @param string $text_html Pre-built block markup (heading/paragraphs/etc).
 * @param bool   $reverse   Alternates the grid column order for visual
 *                          rhythm down the page (see style.css
 *                          .explainer-grid--reverse).
 */
function finest_explainer_block( $scene, $text_html, $reverse = false ) {
	$scene_e = esc_attr( $scene );
	$class   = 'explainer-grid' . ( $reverse ? ' explainer-grid--reverse' : '' );
	return <<<HTML
<!-- wp:group {"align":"wide","className":"{$class}","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide {$class}">

<!-- wp:html -->
<div class="explainer-canvas" data-scene="{$scene_e}" aria-hidden="true"><canvas></canvas></div>
<!-- /wp:html -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

{$text_html}

</div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->
HTML;
}

function finest_cta_button( $label = 'Plan een kennismaking', $url = '/contact/' ) {
	$url = esc_url( $url );
	$label = esc_html( $label );
	return <<<HTML
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="{$url}">{$label}</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
HTML;
}

/**
 * "Optiek Stories": the four latest Klantverhalen as a grid of cards (image,
 * topic label, title), closing out the homepage. A real core/query block, not
 * a PHP-built snapshot: a story published next month shows up automatically,
 * and core/query-no-results covers the empty state on a fresh install.
 * Spotlight look: heavy rule + light headline, 4 columns on desktop, 2 on
 * tablet/phone (style.css .finest-stories-grid).
 */
function finest_stories_block() {
	return <<<'HTML'
<!-- wp:group {"align":"full","className":"finest-stories","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull finest-stories">

<!-- wp:group {"align":"wide","className":"finest-stories__head","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide finest-stories__head">
<!-- wp:heading {"level":2,"fontSize":"kop","className":"finest-stories__title"} -->
<h2 class="wp-block-heading has-kop-font-size finest-stories__title">Optiek Stories</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"finest-stories__all"} -->
<p class="finest-stories__all"><a href="/klantverhalen/">Alle stories</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:query {"queryId":2,"query":{"postType":"klantverhaal","perPage":4,"orderBy":"date","order":"desc","inherit":false},"align":"wide","className":"fi-stories-query"} -->
<div class="wp-block-query alignwide fi-stories-query">

<!-- wp:post-template {"className":"finest-stories-grid"} -->
<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"finest-card","aspectRatio":"4/5","className":"finest-stories__media"} /-->
<!-- wp:post-terms {"term":"klantverhaal_onderwerp","className":"finest-stories__label"} /-->
<!-- wp:post-title {"isLink":true,"level":3,"className":"finest-stories__post-title"} /-->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"className":"finest-no-results"} -->
<p class="finest-no-results">Nog geen klantverhalen gepubliceerd. Zodra er verhalen worden toegevoegd in wp-admin, verschijnen ze hier automatisch.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

</div>
<!-- /wp:query -->

</div>
<!-- /wp:group -->
HTML;
}

function finest_faq_item( $question, $answer ) {
	$q = esc_html( $question );
	$a = esc_html( $answer );
	return <<<HTML
<!-- wp:details -->
<details class="wp-block-details"><summary>{$q}</summary>
<!-- wp:paragraph -->
<p>{$a}</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
HTML;
}

function finest_faq_block() {
	$items = array(
		array( 'Wat is The Finest Impact?', 'The Finest Impact is een compleet marketingteam in één platform, ontwikkeld voor de optiek. Het helpt je bij alles wat nodig is om je marketing structureel goed te organiseren. Van strategie en campagnes tot content, social media, e-mailmarketing, vindbaarheid, marktinzichten en analyse. Alles vertrekt vanuit jouw bedrijf, jouw klanten en jouw commerciële doelen. Zo krijg je meer marketingkracht, zonder zelf een volledige marketingafdeling op te bouwen.' ),
		array( 'Voor wie is The Finest Impact bedoeld?', 'Voor zelfstandige opticiens die marketing belangrijk vinden, maar merken dat het er in de praktijk te vaak bij wordt gedaan. Misschien ligt marketing nu bij jou als ondernemer. Misschien doet een medewerker het erbij. Of werk je met verschillende bureaus en freelancers. The Finest Impact brengt daar meer structuur, snelheid en samenhang in: één platform waarin jouw gehele marketingteam samenkomt.' ),
		array( 'Wat kan The Finest Impact voor mijn optiekbedrijf doen?', 'The Finest Impact helpt je om vooruit te kijken, campagnes op tijd te plannen, regelmatig zichtbaar te zijn, klanten opnieuw te activeren en beter gebruik te maken van kansen in je markt. Niet meer iedere week opnieuw bedenken wat je moet posten of welke actie je moet verzinnen. Je werkt vanuit een duidelijke marketinglijn.' ),
		array( 'Is The Finest Impact alleen bedoeld voor content en social media?', 'Nee. Content is maar één onderdeel van marketing. The Finest Impact helpt ook bij strategie, campagnes, klantactivatie, e-mailmarketing, lokale zichtbaarheid, vindbaarheid in Google en AI, marktontwikkelingen en het analyseren van wat werkt.' ),
		array( 'Werkt The Finest Impact met AI?', 'Ja, AI speelt een belangrijke rol. Maar The Finest Impact is niet ontwikkeld om simpelweg zoveel mogelijk content te produceren. AI wordt ingezet om sneller te kunnen onderzoeken, plannen, maken, analyseren en verbeteren. Jouw bedrijf, klanten en commerciële doelen blijven altijd het uitgangspunt.' ),
		array( 'Krijg ik dan van die typische AI-teksten?', 'Dat willen we juist voorkomen. The Finest Impact leert jouw merk, doelgroep, tone of voice, aanbod en manier van communiceren kennen. Daardoor ontstaat marketing die beter bij jouw merk past en niet klinkt alsof dezelfde tekst ook voor iedere andere opticien geschreven had kunnen zijn.' ),
		array( 'Heb ik nog wel zelf controle over mijn marketing?', 'Altijd. The Finest Impact is geen automatische marketingmachine die zelfstandig van alles publiceert. Zie het als een extra marketingteam naast je. Het platform helpt je denken, voorbereiden, maken en verbeteren. Jij bepaalt uiteindelijk wat past bij jouw bedrijf en wat naar buiten gaat.' ),
		array( 'Kan één medewerker hiermee werken?', 'Ja. Dat is juist één van de uitgangspunten. Je hoeft geen groot marketingteam of senior marketeer in dienst te hebben. Ook een ondernemer, marketingmedewerker of communicatiemedewerker kan met The Finest Impact werken. De kennis en slagkracht die normaal over meerdere specialisten verdeeld is, wordt veel toegankelijker.' ),
		array( 'Vervangt The Finest Impact mijn marketingbureau of marketeer?', 'Dat hoeft niet. Heb je een goede marketeer of een bureau waar je prettig mee werkt, dan kan The Finest Impact juist helpen om meer gedaan te krijgen. Tegelijkertijd kan het platform werkzaamheden overnemen die nu verspreid liggen over verschillende bureaus, freelancers en tools. Je bepaalt dus zelf wat je intern wilt organiseren en waar je externe expertise voor wilt blijven inzetten.' ),
		array( 'Hoe weet The Finest Impact wat bij mijn bedrijf past?', 'Daar begint onze samenwerking mee. Voordat we The Finest Impact voor je inrichten, kijken we naar je bedrijf, positionering, klanten, aanbod, huidige marketing en commerciële ambities. Wat staat al goed? Waar liggen kansen? Wat ontbreekt nog? Pas daarna richten we The Finest Impact in rondom jouw organisatie. Geen standaardpakket waarin iedere opticien hetzelfde krijgt.' ),
		array( 'Hoe starten we?', 'We beginnen met een Strategische Marketing Sessie. Daarin kijken we samen naar je huidige marketing, doelgroep, positionering, zichtbaarheid en commerciële doelen. Vervolgens bepalen we jouw belangrijke data en marketingstrategie, wat eerst aangescherpt moet worden en hoe The Finest Impact jouw marketing het beste kan ondersteunen. Daaruit ontstaat een duidelijke strategische richting voor de komende periode.' ),
		array( 'Kan The Finest Impact samenwerken met systemen die we al gebruiken?', 'Waar dat relevant is, kan The Finest Impact samenwerken met bestaande marketing- en bedrijfssystemen. Denk aan je kassasysteem, meta, nieuwsbrief e.d. Welke koppelingen zinvol zijn, verschilt per organisatie. Ons uitgangspunt is simpel: we koppelen niet omdat het technisch kan, maar alleen wanneer het jouw marketing daadwerkelijk beter, slimmer of makkelijker maakt.' ),
		array( 'Is onze informatie veilig?', 'Daar besteden we vanaf het begin veel aandacht aan. We kijken zorgvuldig naar welke informatie nodig is, wie toegang heeft en hoe bedrijfs- en klantinformatie wordt gebruikt. Daarbij geldt altijd: niet méér data gebruiken dan nodig is. Zeker wanneer systemen of klantgegevens met elkaar worden verbonden, moeten veiligheid en privacy goed geregeld zijn.' ),
		array( 'Wat levert The Finest Impact mij uiteindelijk op?', 'Niet simpelweg meer marketing. Maar betere marketing. Meer structuur. Meer continuïteit. Snellere uitvoering. Sterkere campagnes. Meer zichtbaarheid. Meer inzicht in wat werkt. Meer sales. En vooral: minder tijd kwijt zijn aan het organiseren van marketing. Zodat jij je kunt richten op waar je uiteindelijk het verschil maakt: je klanten, je winkel, je collectie, je sales en goede oogzorg.' ),
		array( 'Wat kost The Finest Impact?', 'The Finest Impact wordt ingericht rondom jouw organisatie. De investering hangt daarom af van waar je nu staat en wat nodig is om je marketing goed te organiseren. Tijdens een kennismaking kijken we eerst naar je huidige situatie en ambities. Daarna kunnen we heel concreet aangeven welke aanpak bij jouw organisatie past.' ),
		array( 'Kan ik eerst zien hoe het werkt?', 'Natuurlijk. Tijdens een demo laten we je zien hoe The Finest Impact werkt aan de hand van herkenbare situaties uit de optiek. Geen technische softwaretour, maar vooral: wat betekent dit voor jouw dagelijkse marketing?' ),
	);

	$out = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$out .= '<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
	$out .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Veelgestelde vragen</h2>\n<!-- /wp:heading -->\n\n";
	foreach ( $items as $item ) {
		$out .= finest_faq_item( $item[0], $item[1] ) . "\n\n";
	}
	$out .= finest_cta_button( 'Plan een demo', '/contact/' );
	$out .= "\n</div>\n<!-- /wp:group -->";
	return $out;
}

function finest_team_member_block( $name, $role, $phone, $linkedin, $photo_id = 0 ) {
	$name_e  = esc_html( $name );
	$role_e  = esc_html( $role );
	$phone_e = esc_html( $phone );
	$li_e    = esc_url( $linkedin );
	$photo   = finest_team_photo_block( $photo_id );
	// WCAG 2.2 SC 2.4.4: four cards in a row all ending in a bare
	// "LinkedIn" link are indistinguishable to anyone navigating by a
	// screen reader's links list (no surrounding context there) — an
	// aria-label gives each one a distinct, meaningful accessible name
	// without changing the visible link text.
	$li_label = esc_attr( sprintf( 'LinkedIn-profiel van %s (opent in nieuw tabblad)', $name ) );
	return <<<HTML
<!-- wp:column -->
<div class="wp-block-column">

{$photo}

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">{$name_e}</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">{$role_e}</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">{$phone_e}<br><a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a><br><a href="{$li_e}" target="_blank" rel="noopener" aria-label="{$li_label}">LinkedIn</a></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->
HTML;
}

function finest_over_ons_page_content() {
	$intro = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Marketing first.<br>Technology powered.<br>Human controlled.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Marketing wordt steeds belangrijker, maar voor veel ondernemers ook steeds moeilijker om goed te organiseren. Er zijn meer kanalen, meer data, meer technologie en meer mogelijkheden dan ooit. Maar tijd en capaciteit groeien niet automatisch mee.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Met meer dan 20 jaar ervaring in marketing en ruime kennis van de optiekbranche kennen we die werkelijkheid van heel dichtbij. We weten hoe belangrijk merk, strategie, creativiteit en commercieel inzicht zijn. We weten ook hoe vaak goede marketing blijft liggen omdat de dagelijkse praktijk voorgaat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Daarom hebben we The Finest Impact ontwikkeld.</strong></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"zwart","textColor":"linnen","className":"is-style-fi-dark-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

<!-- wp:heading {"level":2,"fontSize":"kop"} -->
<h2 class="wp-block-heading has-kop-font-size">Marketing expertise en technologie horen bij elkaar</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Technologie kan veel, maar zonder richting, context en commercieel inzicht ontstaat vooral meer output. Daar geloven wij niet in.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Wij geloven in marketing die consistent is en klopt. Marketing die past bij je merk. Marketing die inspeelt op wat klanten nodig hebben. Marketing die zichtbaar maakt waar je voor staat. En marketing die uiteindelijk écht iets moet opleveren, namelijk sales.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daarom combineren we menselijke expertise met technologie. De mens bepaalt de strategie, bewaakt de kwaliteit en maakt de keuzes. The Finest Impact zorgt voor snelheid, structuur en uitvoeringskracht. Samen ontstaat marketing die efficiënt en consistent wordt en zorgt voor groei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Own your spotlight.</strong></p>
<!-- /wp:paragraph -->

HTML;
	$intro .= finest_cta_button( 'Maak kennis met The Finest Impact', 'mailto:info@thefinestimpact.com' );
	$intro .= "\n</div>\n<!-- /wp:group -->";

	$team = "\n\n<!-- wp:group {\"align\":\"wide\",\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$team .= '<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">' . "\n\n";
	$team .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Ontmoet ons team</h2>\n<!-- /wp:heading -->\n\n";
	$team .= "<!-- wp:paragraph -->\n<p>De mensen achter The Finest Impact.</p>\n<!-- /wp:paragraph -->\n\n";
	$team .= "<!-- wp:columns {\"align\":\"wide\"} -->\n<div class=\"wp-block-columns alignwide\">\n";
	$team .= finest_team_member_block( 'Karin Boon', 'Co-founder & Head of Growth', '+31 6 48 46 99 24', 'https://www.linkedin.com/in/karinboon/', finest_ensure_photo( 'karin.jpg', 'Karin Boon', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Manon van Gasteren', 'Co-founder & Head of Marketing', '+31 6 22 80 82 36', 'https://www.linkedin.com/in/manonvangasteren/', finest_ensure_photo( 'manon.jpg', 'Manon van Gasteren', 'team' ) ) . "\n";
	$team .= finest_team_member_block( 'Ben Verschuur', 'Co-founder & Head of Technology', '+31 6 13 01 32 66', 'https://www.linkedin.com/in/benverschuur/', finest_ensure_photo( 'ben.jpg', 'Ben Verschuur', 'team' ) ) . "\n";
	$team .= "</div>\n<!-- /wp:columns -->\n\n</div>\n<!-- /wp:group -->";

	return $intro . $team;
}

function finest_diensten_page_content() {
	$blok1 = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Van strategie naar marketing die presteert</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Goede marketing begint niet met technologie. Het begint met weten waar je staat, wie je klant is, waar je kansen liggen en wat nodig is om te groeien.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Met meer dan 20 jaar ervaring in marketing en ruime kennis van de optiekbranche weten we hoe marketing werkt, maar vooral ook wat er in de praktijk nodig is om die marketing daadwerkelijk te laten presteren.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daarom start The Finest Impact altijd vanuit jouw bedrijf. We brengen je marketing in kaart, bepalen samen de juiste richting, versterken wat nog ontbreekt en richten daarna jouw eigen marketingomgeving in.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Vanaf dat moment werk je structureel samen met The Finest Impact, onze marketingexpertise en gespecialiseerde marketing agents.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Menselijke expertise bepaalt de richting. Technologie zorgt voor snelheid, capaciteit en uitvoering.</strong></p>
<!-- /wp:paragraph -->

HTML;
	$blok1 .= finest_cta_button( 'Plan een kennismaking', '/contact/' );
	$blok1 .= "\n</div>\n<!-- /wp:group -->";

	$stappen = array(
		array( 'We brengen de situatie in kaart', 'We starten met een strategische marketing sessie. Daarin kijken we naar je huidige marketing, doelgroep, positionering, klantreis, zichtbaarheid en commerciële ambities. Het resultaat is een concrete marketing roadmap.' ),
		array( 'We versterken wat nog ontbreekt', 'Op basis van die marketing roadmap bepalen we wat eerst beter moet. Dat kan bijvoorbeeld gaan om positionering, branding, contentstrategie, social media, campagnes, SEO, lokale vindbaarheid of zichtbaarheid in AI.' ),
		array( 'We richten The Finest Impact in', 'Zodra de marketingbasis staat, bouwen we jouw eigen marketingomgeving. We vertalen je merk, doelgroep, tone of voice, aanbod, doelen en kennis naar The Finest Impact en richten de juiste agents, workflows, kwaliteitscontrole en koppelingen in.' ),
		array( 'We gaan ermee werken en optimaliseren', 'Daarna wordt The Finest Impact onderdeel van je dagelijkse marketing. Je team gebruikt de omgeving voor onder andere campagnes, content, klantcommunicatie, zichtbaarheid en analyse. Jullie kennis blijft leidend, terwijl The Finest Impact helpt om sneller, consistent en professioneler te werken. Zo ontstaat stap voor stap een marketingaanpak die niet alleen slimmer is ingericht, maar ook structureel blijft werken.' ),
	);

	$blok2 = "\n\n<!-- wp:group {\"align\":\"full\",\"backgroundColor\":\"klei\",\"style\":{\"spacing\":{\"padding\":{\"top\":\"var:preset|spacing|60\",\"bottom\":\"var:preset|spacing|60\",\"left\":\"var:preset|spacing|50\",\"right\":\"var:preset|spacing|50\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$blok2 .= '<div class="wp-block-group alignfull has-klei-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">' . "\n\n";
	$blok2 .= "<!-- wp:heading {\"level\":2,\"fontSize\":\"kop\"} -->\n<h2 class=\"wp-block-heading has-kop-font-size\">Hoe gaan we te werk?</h2>\n<!-- /wp:heading -->\n\n";
	$blok2 .= "<!-- wp:paragraph -->\n<p>We werken in vier duidelijke stappen. Zo bouwen we niet zomaar iets, maar zorgen we dat iedere keuze aansluit op jouw organisatie, ambities en marketingdoelen.</p>\n<!-- /wp:paragraph -->\n\n";
	$blok2 .= "<!-- wp:columns {\"align\":\"wide\",\"className\":\"fi-steps\"} -->\n<div class=\"wp-block-columns alignwide fi-steps\">\n\n";
	foreach ( $stappen as $i => $stap ) {
		$n = $i + 1;
		$blok2 .= "<!-- wp:column -->\n<div class=\"wp-block-column\">\n\n";
		$blok2 .= "<!-- wp:heading {\"level\":3,\"fontSize\":\"medium\"} -->\n<h3 class=\"wp-block-heading has-medium-font-size\">{$n}. {$stap[0]}</h3>\n<!-- /wp:heading -->\n\n";
		$blok2 .= "<!-- wp:paragraph {\"fontSize\":\"small\"} -->\n<p class=\"has-small-font-size\">{$stap[1]}</p>\n<!-- /wp:paragraph -->\n\n";
		$blok2 .= "</div>\n<!-- /wp:column -->\n\n";
	}
	$blok2 .= "</div>\n<!-- /wp:columns -->\n\n";
	$blok2 .= "</div>\n<!-- /wp:group -->";

	return $blok1 . $blok2 . "\n\n" . finest_faq_block();
}

function finest_contact_page_content() {
	$content = <<<'HTML'
<!-- wp:group {"align":"wide","className":"tfi-contact","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1120px"}} -->
<div class="wp-block-group alignwide tfi-contact" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Plan een kennismaking</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Tijdens een kennismaking kijken we eerst naar je huidige situatie en ambities. Daarna kunnen we heel concreet aangeven welke aanpak bij jouw organisatie past.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"className":"tfi-contact-grid"} -->
<div class="wp-block-columns tfi-contact-grid">

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Stuur een bericht</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[finest_contact_form]
<!-- /wp:shortcode -->

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Direct contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><a href="mailto:info@thefinestimpact.com">info@thefinestimpact.com</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Karin Boon, Head of Growth<br>+31 6 48 46 99 24</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Manon van Gasteren, Head of Marketing<br>+31 6 22 80 82 36</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->
HTML;
	return $content;
}

function finest_klantverhalen_intro_content() {
	$intro = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--50)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Wat gebeurt er wanneer marketing wél structureel wordt?</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Daar willen we niet alleen over vertellen. We willen het laten zien.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In onze klantverhalen delen we hoe opticiens The Finest Impact gebruiken, wat er verandert in hun dagelijkse marketing en welk resultaat dat oplevert. Van tijdsbesparing en meer zichtbaarheid tot betere campagnes, meer klantactivatie en commerciële groei.</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->
HTML;

	// Same inherit:false correction as finest_nieuws_intro_content() — see
	// that function's comment for why inherit:true is a silent no-posts
	// bug on a regular Page. Reuses the .finest-blog-grid card styling
	// (style.css) for visual consistency with the Nieuws overview, even
	// though klantverhaal has no category taxonomy of its own.
	$grid = <<<'HTML'
<!-- wp:query {"queryId":1,"query":{"postType":"klantverhaal","perPage":9,"orderBy":"date","order":"desc","inherit":false},"align":"wide","className":"finest-blog-grid"} -->
<div class="wp-block-query alignwide finest-blog-grid">

<!-- wp:post-template {"className":"finest-blog-grid__track"} -->
<!-- wp:group {"className":"finest-blog-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-blog-card">
<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"finest-card","className":"finest-blog-card__media"} /-->
<!-- wp:post-title {"isLink":true,"level":2,"fontSize":"medium","className":"finest-blog-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":18,"className":"finest-blog-card__excerpt"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"className":"finest-no-results"} -->
<p class="finest-no-results">Nog geen klantverhalen gepubliceerd. In de WordPress-versie is dit een automatische lijst (query op het "Klantverhaal" post type) — zodra er verhalen worden toegevoegd in wp-admin, verschijnen ze hier vanzelf als kaarten met uitgelichte foto, titel en samenvatting.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"className":"finest-pagination"} -->
<!-- wp:query-pagination-previous {"label":"Vorige"} /-->
<!-- wp:query-pagination-numbers /-->
<!-- wp:query-pagination-next {"label":"Volgende"} /-->
<!-- /wp:query-pagination -->

</div>
<!-- /wp:query -->
HTML;

	return $intro . "\n\n" . $grid;
}

/**
 * Category "pills" row for the Nieuws overview — real links to each
 * nieuws_categorie archive (templates/archive.html), built from
 * get_terms() rather than hardcoded.
 *
 * This renders at provisioning time (finest_provision_content(), run on
 * theme activation), not on every page load — see finest_resync_nieuws_page()
 * below, which re-runs it and saves the refreshed content whenever a
 * nieuws_categorie term is created, renamed, or deleted, so a category
 * added later in wp-admin still shows up with zero manual edits. Without
 * that hook this would go stale the moment taxonomy changed after first
 * activation.
 */
function finest_category_pills( $taxonomy ) {
	$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return '';
	}
	$links = '';
	foreach ( $terms as $term ) {
		$link = get_term_link( $term );
		// hierarchical taxonomies can return WP_Error (e.g. term_link_parent_loop);
		// esc_url() on a WP_Error object is a PHP 8 fatal, not a graceful empty
		// string, so this term must be skipped before it ever reaches esc_url().
		if ( is_wp_error( $link ) ) {
			continue;
		}
		// Root-relative, not absolute: this markup is saved into post_content, and an
		// absolute URL would pin every pill to whichever domain the theme happened to be
		// activated on (a staging site, a temporary host) after the site moves.
		$url   = esc_url( wp_make_link_relative( $link ) );
		$name  = esc_html( $term->name );
		$links .= "<a class=\"finest-pill\" href=\"{$url}\">{$name}</a>\n";
	}
	if ( ! $links ) {
		return '';
	}
	return <<<HTML
<!-- wp:html -->
<div class="finest-pills">
{$links}</div>
<!-- /wp:html -->
HTML;
}

/**
 * finest_category_pills() wrapped in its own padded group, exactly as it's
 * embedded in finest_nieuws_intro_content() -- pulled out so
 * finest_resync_nieuws_pills() (inc/provisioning.php) can insert this same
 * markup from scratch when a term is added after provisioning and no pills
 * block exists yet to splice into (e.g. the Nieuws page had zero
 * nieuws_categorie terms at first activation). Returns '' if there's
 * nothing to show, same as finest_category_pills() itself.
 */
function finest_category_pills_wrap( $taxonomy ) {
	$pills = finest_category_pills( $taxonomy );
	if ( ! $pills ) {
		return '';
	}
	$wrap  = "<!-- wp:group {\"style\":{\"spacing\":{\"padding\":{\"bottom\":\"var:preset|spacing|50\"}}},\"layout\":{\"type\":\"constrained\"}} -->\n";
	$wrap .= '<div class="wp-block-group" style="padding-bottom:var(--wp--preset--spacing--50)">' . "\n\n";
	$wrap .= $pills;
	$wrap .= "\n\n</div>\n<!-- /wp:group -->";
	return $wrap;
}

function finest_nieuws_intro_content() {
	$intro = <<<'HTML'
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40)">

<!-- wp:heading {"level":1,"fontSize":"display","className":"fi-reveal-lines"} -->
<h1 class="wp-block-heading has-display-font-size fi-reveal-lines">Blijf voor op wat er in de optiek gebeurt</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>De optiekwereld verandert snel. Nieuwe merken komen op, retailconcepten veranderen, technologie ontwikkelt zich en consumenten verwachten steeds meer. The Finest News volgt wat er gebeurt in Nederland én daarbuiten. Van nieuwe eyewear merken en opvallende winkels tot internationale trends, technologie, AI, events, marketing en ontwikkelingen in de markt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Maar we brengen niet alleen het nieuws. We kijken vooral naar de vraag: wat betekent dit voor jou als opticien?</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Welke ontwikkelingen zijn interessant?</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Welke trends moet je in de gaten houden?</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Waar liggen kansen voor jouw winkel, merk of marketing?</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>The Finest News. Voor opticiens die niet willen volgen, maar vooruit willen kijken.</strong></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->
HTML;

	$pills_wrap = finest_category_pills_wrap( 'nieuws_categorie' );

	// inherit:false (the default — stated explicitly so the next person
	// doesn't "helpfully" add inherit:true back): this is a normal static
	// Page, not the designated "Posts page", so there is no main post
	// query here to inherit. A Query Loop with inherit:true on a page like
	// this silently falls back to the page's own single-page query — i.e.
	// it would render zero posts. className values below are the CSS
	// hooks for the editorial card grid in style.css (.finest-blog-grid).
	$grid = <<<'HTML'
<!-- wp:query {"queryId":2,"query":{"postType":"post","perPage":9,"orderBy":"date","order":"desc","inherit":false},"align":"wide","className":"finest-blog-grid"} -->
<div class="wp-block-query alignwide finest-blog-grid">

<!-- wp:post-template {"className":"finest-blog-grid__track"} -->
<!-- wp:group {"className":"finest-blog-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group finest-blog-card">
<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"finest-card","className":"finest-blog-card__media"} /-->
<!-- wp:post-terms {"term":"nieuws_categorie","fontSize":"label","className":"finest-blog-card__cat"} /-->
<!-- wp:post-title {"isLink":true,"level":2,"fontSize":"medium","className":"finest-blog-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":18,"className":"finest-blog-card__excerpt"} /-->
<!-- wp:post-date {"fontSize":"label","className":"finest-blog-card__date"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"className":"finest-no-results"} -->
<p class="finest-no-results">Nog geen artikelen gepubliceerd. In de WordPress-versie is dit de normale blogfunctie (reguliere posts + categorie "Nieuws categorie") — nieuwe berichten verschijnen hier automatisch, inclusief RSS-feed.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"className":"finest-pagination"} -->
<!-- wp:query-pagination-previous {"label":"Vorige"} /-->
<!-- wp:query-pagination-numbers /-->
<!-- wp:query-pagination-next {"label":"Volgende"} /-->
<!-- /wp:query-pagination -->

</div>
<!-- /wp:query -->
HTML;

	return $intro . "\n\n" . $pills_wrap . "\n\n" . $grid;
}

require_once __DIR__ . '/content-legal.php';
require_once __DIR__ . '/content-blog.php';
