<?php
/**
 * Server hints for speed: compression and browser caching of static files.
 *
 * On Apache hosts the theme writes one marked block to .htaccess (the same
 * way WordPress writes its rewrite rules): gzip/deflate for text files and a
 * long browser cache for versioned CSS, JS, fonts and images. Both are plain
 * mod_deflate / mod_expires rules wrapped in <IfModule>, so a host without
 * the module ignores them.
 *
 * Safety net: after writing, the theme requests one of its own files. If the
 * server answers with an error (or not at all), the previous .htaccess is put
 * back immediately and the block is not tried again until the setting is
 * saved. Switching to another theme removes the block.
 *
 * Switch off with Settings > General > "Snelheidsregels", or with the filter
 * `finest_server_hints_enabled`.
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

/** Marker name inside .htaccess. */
const FINEST_HTACCESS_MARKER = 'Finest Spotlight speed';

/** Version of the rules: bump it to rewrite the block on sites that already have one. */
const FINEST_SERVER_HINTS_VERSION = '1';

/** The rules, one per line. */
function finest_server_hint_rules() {
	return array(
		'<IfModule mod_deflate.c>',
		'AddOutputFilterByType DEFLATE text/css text/javascript application/javascript application/x-javascript application/json application/ld+json application/xml text/xml application/rss+xml image/svg+xml image/x-icon text/plain font/ttf font/otf',
		'</IfModule>',
		'<IfModule mod_expires.c>',
		'ExpiresActive On',
		'ExpiresByType text/css "access plus 1 year"',
		'ExpiresByType text/javascript "access plus 1 year"',
		'ExpiresByType application/javascript "access plus 1 year"',
		'ExpiresByType font/woff2 "access plus 1 year"',
		'ExpiresByType font/woff "access plus 1 year"',
		'ExpiresByType image/webp "access plus 1 month"',
		'ExpiresByType image/avif "access plus 1 month"',
		'ExpiresByType image/jpeg "access plus 1 month"',
		'ExpiresByType image/png "access plus 1 month"',
		'ExpiresByType image/gif "access plus 1 month"',
		'ExpiresByType image/svg+xml "access plus 1 month"',
		'</IfModule>',
	);
}

/** Is the feature switched on (setting default: on)? */
function finest_server_hints_enabled() {
	return (bool) apply_filters( 'finest_server_hints_enabled', '0' !== (string) get_option( 'finest_server_hints', '1' ) );
}

/** Path of the .htaccess to edit, or '' when this host is not a writable Apache setup. */
function finest_htaccess_path() {
	global $is_apache;
	if ( ! $is_apache || ! function_exists( 'get_home_path' ) ) {
		return '';
	}
	$file = get_home_path() . '.htaccess';
	if ( file_exists( $file ) ? ! wp_is_writable( $file ) : ! wp_is_writable( dirname( $file ) ) ) {
		return '';
	}
	return $file;
}

/**
 * Does the server still answer after the change? Requests a theme file.
 *
 * @return bool
 */
function finest_server_hints_check() {
	$result = wp_remote_head(
		FINEST_THEME_URI . '/style.css',
		array(
			'timeout'     => 10,
			'redirection' => 3,
		)
	);
	$ok     = ! is_wp_error( $result ) && (int) wp_remote_retrieve_response_code( $result ) < 400;
	return (bool) apply_filters( 'finest_server_hints_check', $ok );
}

/**
 * Write (or refresh) the block, verify, and roll back if the server objects.
 *
 * @return string 'written' | 'unchanged' | 'skipped' | 'reverted'
 */
function finest_server_hints_apply() {
	$file = finest_htaccess_path();
	if ( '' === $file ) {
		return 'skipped';
	}
	require_once ABSPATH . 'wp-admin/includes/misc.php';

	$before = file_exists( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local server config file.
	if ( ! insert_with_markers( $file, FINEST_HTACCESS_MARKER, finest_server_hint_rules() ) ) {
		return 'skipped';
	}
	$after = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local server config file.
	if ( $after === $before ) {
		return 'unchanged';
	}
	if ( ! finest_server_hints_check() ) {
		file_put_contents( $file, $before ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- restoring the file exactly as it was.
		update_option( 'finest_server_hints_state', 'reverted' );
		return 'reverted';
	}
	update_option( 'finest_server_hints_state', 'active:' . FINEST_SERVER_HINTS_VERSION );
	return 'written';
}

/** Remove the block (switching off, or leaving the theme). */
function finest_server_hints_remove() {
	$file = finest_htaccess_path();
	if ( '' === $file || ! file_exists( $file ) ) {
		return;
	}
	$content = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local server config file.
	$marker  = preg_quote( FINEST_HTACCESS_MARKER, '/' );
	$clean   = preg_replace( '/\n?# BEGIN ' . $marker . '.*?# END ' . $marker . '[ \t]*\n?/s', "\n", $content );
	if ( null !== $clean && $clean !== $content ) {
		file_put_contents( $file, rtrim( $clean ) . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- removing our own block.
	}
	update_option( 'finest_server_hints_state', 'off' );
}

/** Keep the file in step with the setting and the rules version (admin only, cheap check). */
function finest_server_hints_sync() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$state = (string) get_option( 'finest_server_hints_state', '' );
	if ( finest_server_hints_enabled() ) {
		if ( 'active:' . FINEST_SERVER_HINTS_VERSION === $state || 'reverted' === $state ) {
			return; // current, or tried and refused by the server: do not try again.
		}
		finest_server_hints_apply();
	} elseif ( 'off' !== $state && '' !== $state ) {
		finest_server_hints_remove();
	}
}
add_action( 'admin_init', 'finest_server_hints_sync' );

/** Saving the setting gives a refused block another try. */
function finest_server_hints_reset_on_save( $value ) {
	update_option( 'finest_server_hints_state', '' );
	return '0' === (string) $value ? '0' : '1';
}

/** Leaving the theme: take the rules out again. */
function finest_server_hints_on_switch() {
	finest_server_hints_remove();
}
add_action( 'switch_theme', 'finest_server_hints_on_switch' );

/** Settings > General: the switch. */
function finest_server_hints_settings() {
	register_setting(
		'general',
		'finest_server_hints',
		array(
			'type'              => 'string',
			'default'           => '1',
			'sanitize_callback' => 'finest_server_hints_reset_on_save',
		)
	);
	add_settings_field(
		'finest_server_hints',
		__( 'Snelheidsregels', 'finest-spotlight' ),
		static function () {
			$state = (string) get_option( 'finest_server_hints_state', '' );
			printf(
				'<label><input type="checkbox" name="finest_server_hints" value="1" %1$s> %2$s</label><p class="description">%3$s</p>',
				checked( '0' !== (string) get_option( 'finest_server_hints', '1' ), true, false ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- checked() returns a safe attribute.
				esc_html__( 'Compressie en browsercache voor CSS, JS, lettertypen en afbeeldingen (via .htaccess)', 'finest-spotlight' ),
				esc_html(
					'reverted' === $state
						? __( 'De server weigerde deze regels; ze zijn teruggedraaid. Opslaan probeert het opnieuw.', 'finest-spotlight' )
						: ( '' === finest_htaccess_path() ? __( 'Niet beschikbaar: dit is geen Apache-server met een beschrijfbare .htaccess. Vraag je hostingpartij om compressie en cache aan te zetten.', 'finest-spotlight' ) : __( 'Het thema schrijft één blok in .htaccess en controleert daarna of de site nog antwoordt.', 'finest-spotlight' ) )
				)
			);
		},
		'general',
		'default'
	);
}
add_action( 'admin_init', 'finest_server_hints_settings' );
