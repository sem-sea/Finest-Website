<?php
/**
 * Open Graph, Twitter Card and JSON-LD (schema.org) output for every page,
 * so links shared in WhatsApp/Slack/LinkedIn/etc. render a real preview
 * card: title, description, canonical URL and image, instead of a bare
 * link.
 *
 * Deliberately theme-level (no plugin): this is a small, fixed set of tags
 * derived from data WordPress already has (post title/excerpt/thumbnail,
 * site name/tagline), not a configurable SEO suite. If a dedicated SEO
 * plugin (Yoast, Rank Math, SEOPress, AIOSEO) is active it already does
 * this job — and usually more completely — so finest_seo_meta() below
 * bails out rather than emit duplicate/conflicting <meta> tags.
 */

defined( 'ABSPATH' ) || exit;

/**
 * True if a known SEO plugin is active and already handles social meta.
 */
function finest_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' )
		|| defined( 'RANK_MATH_VERSION' )
		|| defined( 'AIOSEO_VERSION' )
		|| defined( 'SEOPRESS_VERSION' )
		|| class_exists( 'RankMath' );
}

/**
 * The theme's own default share image (assets/img/social/og-image.jpg),
 * used whenever the current page has no featured image. 400×210 — small
 * enough to stay fast, large enough to satisfy every major OG consumer's
 * minimum (WhatsApp/Facebook want at least 200×200; Twitter's summary_large
 * image card wants at least a 2:1-ish ratio, which this already is).
 */
function finest_default_og_image() {
	return array(
		'url'    => FINEST_THEME_URI . '/assets/img/social/og-image.jpg',
		'width'  => 400,
		'height' => 210,
	);
}

/**
 * Resolve the best image for the current request: the post/page's own
 * featured image when one is set, otherwise the theme default above.
 * Always returns url/width/height so the og:image:width/height tags (which
 * materially improve how fast/reliably crawlers render the preview) are
 * never left out.
 */
function finest_seo_image() {
	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		if ( $post_id && has_post_thumbnail( $post_id ) ) {
			$thumb_id = get_post_thumbnail_id( $post_id );
			$src      = wp_get_attachment_image_src( $thumb_id, 'large' );
			if ( $src ) {
				return array(
					'url'    => $src[0],
					'width'  => (int) $src[1],
					'height' => (int) $src[2],
				);
			}
		}
	}
	return finest_default_og_image();
}

/**
 * Plain-text description for the current request: an explicit excerpt when
 * the editor set one, otherwise the opening words of the content, otherwise
 * the site tagline. Always stripped of tags/shortcodes and capped to a
 * sane length — social platforms truncate anyway, but a hard cap keeps the
 * raw meta content attribute from ballooning on very long posts.
 */
function finest_seo_description() {
	if ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			if ( ! empty( $post->post_excerpt ) ) {
				return wp_strip_all_tags( $post->post_excerpt );
			}
			$content = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			if ( $content ) {
				return wp_trim_words( $content, 30, '…' );
			}
		}
	}
	return get_bloginfo( 'description' );
}

/**
 * Page title for the meta tags: deliberately NOT wp_title()/the_title()
 * (those differ per template and already drive the <title> tag via core's
 * 'title-tag' support) — wp_get_document_title() is the one function that
 * returns the exact string core itself put in <title>, so the OG/Twitter
 * title always matches what the browser tab already shows.
 */
function finest_seo_title() {
	return wp_get_document_title();
}

/**
 * The canonical URL for the current request. wp_get_canonical_url()
 * already covers the full page-2-of-an-archive / query-var edge cases
 * core itself handles for <link rel="canonical">; this only adds the
 * front-page and 404 cases it intentionally leaves out.
 */
function finest_seo_canonical() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_singular() ) {
		$canonical = wp_get_canonical_url();
		if ( $canonical ) {
			return $canonical;
		}
	}
	global $wp;
	return home_url( add_query_arg( array(), $wp->request ) );
}

/**
 * Print Open Graph + Twitter Card meta tags. Every dynamic value goes
 * through esc_attr()/esc_url(): this prints straight into HTML attributes
 * built from user-editable post titles/excerpts, so unescaped output here
 * would be a stored XSS hole.
 */
function finest_seo_meta() {
	if ( finest_seo_plugin_active() || is_404() || is_search() ) {
		return;
	}

	$title       = finest_seo_title();
	$description = finest_seo_description();
	$canonical   = finest_seo_canonical();
	$image       = finest_seo_image();
	$site_name   = get_bloginfo( 'name' );
	$locale      = get_locale() ? str_replace( '-', '_', get_locale() ) : 'nl_NL';
	$type        = is_singular( 'post' ) ? 'article' : 'website';
	?>
	<meta property="og:type" content="<?php echo esc_attr( $type ); ?>">
	<meta property="og:site_name" content="<?php echo esc_attr( $site_name ); ?>">
	<meta property="og:locale" content="<?php echo esc_attr( $locale ); ?>">
	<meta property="og:url" content="<?php echo esc_url( $canonical ); ?>">
	<meta property="og:title" content="<?php echo esc_attr( $title ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:image" content="<?php echo esc_url( $image['url'] ); ?>">
<?php if ( ! empty( $image['width'] ) && ! empty( $image['height'] ) ) : ?>
	<meta property="og:image:width" content="<?php echo (int) $image['width']; ?>">
	<meta property="og:image:height" content="<?php echo (int) $image['height']; ?>">
<?php endif; ?>
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="<?php echo esc_attr( $title ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $description ); ?>">
	<meta name="twitter:image" content="<?php echo esc_url( $image['url'] ); ?>">
	<link rel="canonical" href="<?php echo esc_url( $canonical ); ?>">
	<?php
}
add_action( 'wp_head', 'finest_seo_meta', 1 );

/**
 * JSON-LD ProfessionalService schema, once per page, site-wide (not just
 * the front page): every page is a legitimate entry point from a search
 * result or shared link, and repeating the same organisation markup on
 * every page is the pattern Google's own docs recommend over a single
 * sitewide script tag that only the homepage happens to load.
 *
 * wp_json_encode() is used (not raw json_encode()) specifically because,
 * unlike json_encode(), it leaves forward slashes escaped by default
 * (no JSON_UNESCAPED_SLASHES flag passed): that turns a literal
 * "</script>" inside any string value into "<\/script>", which is what
 * actually prevents a crafted post title/excerpt from closing this
 * <script> tag early and injecting markup after it.
 */
function finest_seo_schema() {
	if ( finest_seo_plugin_active() || is_404() || is_search() ) {
		return;
	}

	$image = finest_seo_image();

	$schema = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'ProfessionalService',
		'name'        => get_bloginfo( 'name' ),
		'url'         => home_url( '/' ),
		'image'       => $image['url'],
		'description' => get_bloginfo( 'description' ),
		'areaServed'  => 'NL',
		'serviceType' => 'Marketing voor opticiens',
	);

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}
add_action( 'wp_head', 'finest_seo_schema', 2 );
