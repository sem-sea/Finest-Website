<?php
/**
 * Spotlight home page: dark hero with photo, intro, three split sections
 * (full-height photo next to text), black closing band, Optiek Stories.
 *
 * All of it is plain core blocks (group, image, columns, buttons, query), so
 * the client can edit every word and swap every photo in the editor. The
 * markup of core/image and core/group is written exactly as their save()
 * functions emit it, so the block editor never reports "invalid content".
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

/**
 * One photo block, bare core/image markup (see finest_photo_block() for why
 * the <img> carries nothing but src, alt and the wp-image class).
 *
 * @param int    $id        Attachment ID.
 * @param string $css_class Extra class on the figure (also in the block comment).
 * @param string $alt       Alternative text; empty for decorative photos.
 */
function finest_spotlight_image( $id, $css_class, $alt = '' ) {
	if ( ! $id ) {
		return '';
	}
	$url = wp_get_attachment_image_url( $id, 'full' );
	if ( ! $url ) {
		return '';
	}
	$url       = esc_url( $url );
	$alt       = esc_attr( $alt );
	$css_class = esc_attr( $css_class );
	return <<<HTML
<!-- wp:image {"id":{$id},"sizeSlug":"full","linkDestination":"none","className":"{$css_class}"} -->
<figure class="wp-block-image size-full {$css_class}"><img src="{$url}" alt="{$alt}" class="wp-image-{$id}"/></figure>
<!-- /wp:image -->
HTML;
}

/**
 * A split section: a photo that fills the full height of one half, text in
 * the other half. Stacks (photo on top) below 900px, see style.css.
 *
 * @param int    $image_id  Attachment ID of the photo.
 * @param string $side      'left' or 'right': where the photo sits.
 * @param string $text_html Block markup for the text half.
 * @param string $alt       Alt text of the photo ('' = decorative).
 * @param string $modifier  Extra modifier class, e.g. 'fi-split--rule'.
 */
function finest_spotlight_split( $image_id, $side, $text_html, $alt = '', $modifier = '' ) {
	$side  = 'right' === $side ? 'right' : 'left';
	$class = trim( 'fi-split fi-split--media-' . $side . ' ' . $modifier );
	$media = finest_spotlight_image( $image_id, 'fi-split__media', $alt );
	return <<<HTML
<!-- wp:group {"align":"full","className":"{$class}"} -->
<div class="wp-block-group alignfull {$class}">

{$media}

<!-- wp:group {"className":"fi-split__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-split__text">

{$text_html}

</div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->
HTML;
}

/**
 * Button markup: primary (ice pill) or outline (pill with a line).
 */
function finest_spotlight_button( $label, $url, $outline = false, $arrow = false ) {
	$url   = esc_url( $url );
	$label = esc_html( $label ) . ( $arrow ? ' →' : '' );
	if ( $outline ) {
		return <<<HTML
<!-- wp:button {"className":"is-style-fi-outline"} -->
<div class="wp-block-button is-style-fi-outline"><a class="wp-block-button__link wp-element-button" href="{$url}">{$label}</a></div>
<!-- /wp:button -->
HTML;
	}
	return <<<HTML
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="{$url}">{$label}</a></div>
<!-- /wp:button -->
HTML;
}

/**
 * The whole home page.
 */
function finest_home_page_content() {
	$hero_id     = finest_ensure_photo( 'hero-sunglasses.jpg', 'Spotlight: hero, portret met zonnebril', 'spotlight' );
	$probleem_id = finest_ensure_photo( 'probleem.jpg', 'Spotlight: portret achter glas', 'spotlight' );
	$wat_is_id   = finest_ensure_photo( 'wat-is.jpg', 'Spotlight: portret met heldere bril', 'spotlight' );
	$opticien_id = finest_ensure_photo( 'opticiens.jpg', 'Spotlight: winkelinterieur met lounge', 'spotlight' );

	// ---- 1. Hero: dark band, text left, reeded photo right --------------
	$hero_media = finest_spotlight_image( $hero_id, 'fi-hero__media', '' );
	$hero_btn1  = finest_spotlight_button( 'Ontdek The Finest Impact', '/diensten/', false, true );
	$hero_btn2  = finest_spotlight_button( 'Plan een kennismaking', '/contact/', true );
	$hero       = <<<HTML
<!-- wp:group {"align":"full","backgroundColor":"nacht","textColor":"linnen","className":"fi-hero"} -->
<div class="wp-block-group alignfull fi-hero has-linnen-color has-nacht-background-color has-text-color has-background">

<!-- wp:group {"className":"fi-hero__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-hero__text">

<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">Own your spotlight</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"fontSize":"hero","className":"fi-hero__title fi-reveal-lines"} -->
<h1 class="wp-block-heading has-hero-font-size fi-hero__title fi-reveal-lines">Maximale marketingkracht. Zonder extra mensen.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"fi-hero__sub"} -->
<p class="fi-hero__sub">Het marketingteam voor opticiens.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"fi-hero__buttons"} -->
<div class="wp-block-buttons fi-hero__buttons">
{$hero_btn1}

{$hero_btn2}
</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:group -->

{$hero_media}

</div>
<!-- /wp:group -->
HTML;

	// ---- 2. Intro: statement left, text right ---------------------------
	$intro_btn = finest_spotlight_button( 'Plan een kennismaking', '/contact/' );
	$intro     = <<<HTML
<!-- wp:group {"align":"full","className":"fi-intro","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull fi-intro">

<!-- wp:columns {"align":"wide","className":"fi-intro__cols"} -->
<div class="wp-block-columns alignwide fi-intro__cols">

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:paragraph {"className":"fi-intro__lead"} -->
<p class="fi-intro__lead"><strong>The Finest Impact is een compleet marketingteam in één platform.</strong> Marketing voor jouw merk die klaar is voor de toekomst.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">The Finest Impact laat je marketing presteren.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
{$intro_btn}
</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">

<!-- wp:paragraph -->
<p>Meer zichtbaarheid. Meer continuïteit. Meer commerciële impact.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Van strategie en campagnes tot content, social media, e-mail, vindbaarheid en concurrentieanalyse. Het marketingteam is gepersonaliseerd voor jouw bedrijf en werkt samen vanuit jouw merk, jouw klanten en jouw commerciële doelen. Jij bepaalt de richting en houdt altijd de controle. De agents doen het uitvoerende werk.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Zo houd jij meer tijd over voor waar je écht goed in bent: klanten adviseren, brillen verkopen en de beste oogzorg bieden.</p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->

</div>
<!-- /wp:columns -->

</div>
<!-- /wp:group -->
HTML;

	// ---- 3. Herkenning: photo left ----------------------------------------
	$herkenning_btn  = finest_spotlight_button( 'Ontdek hoe het werkt', '/diensten/' );
	$herkenning_text = <<<HTML
<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Als opticien ligt je aandacht in de winkel. Bij je klanten, je collectie, je team en de oogzorg die je biedt.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Toch vraagt marketing iedere week opnieuw om aandacht.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Een nieuwe brillencollectie die onder de aandacht moet worden gebracht. Social media die bijgehouden moet worden. Een nieuwsbrief die nog verstuurd moet worden. Campagnes die op tijd moeten starten. En natuurlijk wil je die klant regelmatig terugbrengen naar de winkel.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In de praktijk ligt dat werk vaak bij één persoon die marketing naast alle andere werkzaamheden doet. Of verschillende marketingwerkzaamheden worden verdeeld over bureaus, freelancers en losse tools.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Voor je het weet wordt marketing iets wat gebeurt als er tijd over is en is de consistentie ver te zoeken. Vaak ontbreken niet de ideeën, maar de tijd en de capaciteit.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">En precies daar begint The Finest Impact.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
{$herkenning_btn}
</div>
<!-- /wp:buttons -->
HTML;
	$herkenning      = finest_spotlight_split( $probleem_id, 'left', $herkenning_text, '' );

	// ---- 4. Wat is The Finest Impact: photo right --------------------------
	$wat_is_text = <<<'HTML'
<!-- wp:paragraph {"className":"fi-eyebrow fi-eyebrow--dark"} -->
<p class="fi-eyebrow fi-eyebrow--dark">Wat is The Finest Impact?</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Alles wat je nodig hebt om marketing van de toekomst te runnen</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The Finest Impact brengt jouw marketing samen in één centrale omgeving: één dashboard waar jij iedere dag op kan inloggen om te zien wat er speelt. Misschien moet je iets doen, iets activeren of goedkeuren. Onder het genot van een kopje koffie heb jij het zo op orde en kan je focus naar de winkel.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Strategie, campagnes, content, social media, e-mailmarketing, vindbaarheid, marktinzichten en analyse werken niet langer los van elkaar, maar vanuit dezelfde kennis over jouw bedrijf, je concurrentie en je groeikansen. Goede marketing begint niet bij een losse post, advertentie of nieuwsbrief. Het begint bij weten wie je bent, wie je klanten zijn en wat je wilt bereiken. Daarom richten we The Finest Impact in rondom het DNA van jouw bedrijf.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Daardoor hoef je niet iedere campagne opnieuw vanaf nul te bedenken en hoef je niet steeds verschillende partijen te briefen. Een volledige campagneplanning, opgebouwd vanuit jouw doelstellingen, met 360 graden materialen voor de juiste kanalen, in een oogopslag en gemakkelijk aan te bewerken wanneer jij dat nodig vindt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Je marketing krijgt één lijn en één duidelijke richting.<br><strong>Meer marketingkracht. Zonder een groter marketingteam.</strong></p>
<!-- /wp:paragraph -->
HTML;
	$wat_is      = finest_spotlight_split( $wat_is_id, 'right', $wat_is_text, '' );

	// ---- 5. Speciaal voor opticiens: photo left -----------------------------
	$opticiens_text = <<<'HTML'
<!-- wp:paragraph {"className":"fi-eyebrow fi-eyebrow--dark"} -->
<p class="fi-eyebrow fi-eyebrow--dark">Speciaal voor opticiens</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Jij bent opticien en je wilt gewoon resultaat. Meer verkopen.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En dat snappen we. The Finest Impact is ontwikkeld voor opticiens die marketing professioneel willen aanpakken. Het doel is dat marketing consistent bijdraagt aan je bedrijf.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Jij kent je klanten. Jij weet welke collectie belangrijk is. Jij weet wat er in je winkel speelt. Jij bepaalt waar je naartoe wilt. Wij zorgen samen met ons platform dat die kennis wordt vertaald naar sterke marketing.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Menselijke expertise bepaalt de strategie en bewaakt de kwaliteit. Slimme AI-technologie zorgt voor snelheid, capaciteit en uitvoering.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size"><strong>Jij brengt de kennis van je bedrijf. The Finest Impact brengt de marketingkracht.</strong></p>
<!-- /wp:paragraph -->
HTML;
	$opticiens      = finest_spotlight_split( $opticien_id, 'left', $opticiens_text, '' );

	// ---- 6. Black closing band with the big wordmark ------------------------
	$slot_btn = finest_spotlight_button( 'Plan een kennismaking', '/contact/' );
	$slot     = <<<HTML
<!-- wp:group {"align":"full","backgroundColor":"zwart","textColor":"linnen","className":"fi-close is-style-fi-dark-section"} -->
<div class="wp-block-group alignfull fi-close is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background">

<!-- wp:group {"className":"fi-close__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-close__text">

<!-- wp:heading {"level":2,"fontSize":"display","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-display-font-size fi-reveal-lines">Own your spotlight.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Professionele marketing vraagt geen volledige marketingafdeling. Het vraagt marketing van de toekomst.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The Finest Impact combineert jouw kennis van je bedrijf met marketingexpertise en AI-technologie die het zware werk voor je doet.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Zodat je zichtbaar blijft, sneller commerciële kansen benut en meer uit je marketing haalt. Terwijl jij kunt blijven doen waar jij het verschil maakt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">The Finest Impact laat je marketing presteren.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
{$slot_btn}
</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="fi-close__mark" aria-hidden="true"><span class="finest-lockup finest-lockup--big"><span class="ll-the">the</span><span class="ll-finest">finest</span><span class="ll-impact">impact</span></span></div>
<!-- /wp:html -->

</div>
<!-- /wp:group -->
HTML;

	return implode( "\n\n", array( $hero, $intro, $herkenning, $wat_is, $opticiens, $slot, finest_stories_block() ) );
}
