<?php
/**
 * The Finest Impact theme bootstrap.
 *
 * Block theme: design tokens live in theme.json, page content lives in
 * native Gutenberg blocks (post_content), so content editors work with the
 * normal WordPress block editor: no ACF, no hardcoded PHP templates.
 */

defined( 'ABSPATH' ) || exit;

define( 'FINEST_THEME_VERSION', '1.5.0' );
define( 'FINEST_THEME_DIR', get_template_directory() );
define( 'FINEST_THEME_URI', get_template_directory_uri() );

/**
 * Theme support. Block themes get template-editing support implicitly, but
 * these still need to be declared explicitly.
 */
function finest_theme_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );

	add_editor_style( 'assets/css/editor.css' );

	register_nav_menus( array(
		'primary' => __( 'Hoofdmenu', 'finest-impact' ),
		'footer'  => __( 'Footer menu', 'finest-impact' ),
	) );

	// Without these, every wp:post-featured-image block that omits
	// sizeSlug (none were registered, so none could set one) falls back
	// to a slug WordPress can't resolve and silently serves the full,
	// original upload as both src and the base of its own srcset — on
	// every blog card grid, and on the single-post hero, the site's
	// actual LCP element. 'finest-card' matches the 4:5 crop the
	// .finest-blog-card__media CSS (style.css) already assumes;
	// 'finest-hero' is wide enough for the hero's 21:9 desktop crop
	// without upscaling. Both set `true` (hard crop) since the CSS
	// aspect-ratio is fixed either way — a soft/contained crop would just
	// waste bytes on padding the browser crops off again regardless.
	add_image_size( 'finest-card', 640, 800, true );
	add_image_size( 'finest-hero', 1600, 900, true );
}
add_action( 'after_setup_theme', 'finest_theme_setup' );

/**
 * core/post-featured-image's own link wrapper has no accessible-name
 * fallback: if an editor leaves an attachment's alt field blank (common,
 * and nothing server-side enforces it), the generated <a> around the
 * thumbnail has no text and no aria-label — a real, not hypothetical,
 * WCAG 2.4.4/4.1.2 failure on every blog card and the related-posts grid.
 * The post title link covers the same destination, but that's a second,
 * separate link elsewhere in the card, not a fallback for this one.
 * Forcing aria-label to the post title here matches the same pattern
 * already used for the team LinkedIn links (inc/content-pages.php).
 */
function finest_featured_image_link_label( $block_content, $block ) {
	if ( empty( $block['attrs']['isLink'] ) || false === strpos( $block_content, '<a ' ) ) {
		return $block_content;
	}
	$post_id = isset( $block['context']['postId'] ) ? (int) $block['context']['postId'] : get_the_ID();
	if ( ! $post_id ) {
		return $block_content;
	}
	$title = wp_strip_all_tags( get_the_title( $post_id ) );
	if ( ! $title ) {
		return $block_content;
	}
	return preg_replace(
		'/<a\s/',
		'<a aria-label="' . esc_attr( $title ) . '" ',
		$block_content,
		1
	);
}
add_filter( 'render_block_core/post-featured-image', 'finest_featured_image_link_label', 10, 2 );

/**
 * Fonts are self-hosted (theme.json fontFace) rather than loaded from
 * fonts.googleapis.com, avoiding sending EU visitors' IPs to a third party
 * on every page load (see Fase 8 / GDPR notes) and avoids FOUC from a
 * render-blocking external stylesheet.
 */
function finest_enqueue_assets() {
	wp_enqueue_style(
		'finest-impact-style',
		get_stylesheet_uri(),
		array(),
		// filemtime(), not the hand-maintained FINEST_THEME_VERSION constant:
		// style.css gets edited far more often than the theme's overall
		// version is bumped, and a stale cached stylesheet behind a browser/
		// CDN cache from a forgotten version bump is a real, recurring bug
		// class — tying the cache-buster to the file itself removes the
		// human step entirely.
		filemtime( FINEST_THEME_DIR . '/style.css' )
	);
}
add_action( 'wp_enqueue_scripts', 'finest_enqueue_assets' );

/**
 * Add the js-motion / reduced-motion class to <html> before first paint, so
 * the "about to reveal" CSS states in style.css (.fi-reveal, .fi-reveal-lines)
 * never flash visible-then-hidden. Must run at the very top of <head>
 * (priority 0), stay dependency-free and synchronous: this is not the place
 * for anything but this one check.
 */
function finest_print_motion_class() {
	?>
	<script>
	(function(){
		var d=document.documentElement;
		if(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches){
			d.classList.add('reduced-motion');
		}else{
			d.classList.add('js-motion');
		}
		d.classList.add('js-cta');
	})();
	</script>
	<?php
}
add_action( 'wp_head', 'finest_print_motion_class', 0 );

/**
 * Motion layer: GSAP + ScrollTrigger + SplitText, self-hosted (no CDN
 * dependency, see assets/js/vendor/), plus the theme's own motion.js (entry
 * reveals + the Optiek Stories pinned rail) and explainers.js (the four
 * scroll-driven canvas diagrams beside the homepage's explainer sections).
 * Both are a strict progressive enhancement over ordinary block content —
 * see motion.js's own header comment for the full fallback chain. Loaded
 * with the 'defer' script strategy (WP 6.3+) rather than a plain in_footer
 * boolean: defer still executes in document order after parsing, same as
 * in_footer placement effectively achieves, but makes the non-blocking
 * intent explicit and correct even if a future change moves the enqueue
 * call earlier in the page lifecycle.
 *
 * Lenis (smooth-scroll) was deliberately dropped from this stack — see
 * motion.js's header comment for why.
 */
function finest_enqueue_motion_assets() {
	$vendor_uri = FINEST_THEME_URI . '/assets/js/vendor/';
	$vendor_dir = FINEST_THEME_DIR . '/assets/js/vendor/';

	$vendor_files = array(
		'finest-gsap'          => array( 'gsap.min.js', array() ),
		'finest-scrolltrigger' => array( 'ScrollTrigger.min.js', array( 'finest-gsap' ) ),
		'finest-splittext'     => array( 'SplitText.min.js', array( 'finest-gsap' ) ),
	);

	foreach ( $vendor_files as $handle => $file ) {
		list( $filename, $deps ) = $file;
		$path = $vendor_dir . $filename;
		if ( ! file_exists( $path ) ) {
			continue;
		}
		wp_enqueue_script( $handle, $vendor_uri . $filename, $deps, filemtime( $path ), array( 'strategy' => 'defer' ) );
	}

	$own_scripts = array(
		'finest-motion'     => array( 'motion.js', array( 'finest-gsap', 'finest-scrolltrigger', 'finest-splittext' ) ),
		'finest-explainers' => array( 'explainers.js', array( 'finest-gsap', 'finest-scrolltrigger' ) ),
	);

	foreach ( $own_scripts as $handle => $file ) {
		list( $filename, $deps ) = $file;
		$path = FINEST_THEME_DIR . '/assets/js/' . $filename;
		if ( ! file_exists( $path ) ) {
			continue;
		}
		wp_enqueue_script( $handle, FINEST_THEME_URI . '/assets/js/' . $filename, $deps, filemtime( $path ), array( 'strategy' => 'defer' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'finest_enqueue_motion_assets' );

/**
 * Custom block pattern category so our patterns group together in the
 * inserter instead of scattering across "Featured" etc.
 */
function finest_register_pattern_categories() {
	register_block_pattern_category(
		'finest-impact',
		array( 'label' => __( 'The Finest Impact', 'finest-impact' ) )
	);
}
add_action( 'init', 'finest_register_pattern_categories' );

/**
 * WordPress auto-registers any .php file in the theme's patterns/ directory
 * that carries a "Title:"/"Slug:" header comment (since WP 6.0); no manual
 * register_block_pattern() calls needed for the ones designers/editors pick
 * from the inserter. We still expose finest_get_pattern_content() below so
 * provisioning can pull the exact same markup into a page's post_content.
 */

/**
 * Register the outline-button style variation used throughout the patterns
 * (register_block_style, not just a hardcoded className) so editors can
 * also pick it from the block style panel when adding new buttons.
 */
function finest_register_block_styles() {
	register_block_style(
		'core/button',
		array(
			'name'  => 'fi-outline',
			'label' => __( 'Outline', 'finest-impact' ),
		)
	);
}
add_action( 'init', 'finest_register_block_styles' );

require_once FINEST_THEME_DIR . '/inc/template-tags.php';
require_once FINEST_THEME_DIR . '/inc/provisioning.php';
require_once FINEST_THEME_DIR . '/inc/contact-form.php';
require_once FINEST_THEME_DIR . '/inc/seo.php';
require_once FINEST_THEME_DIR . '/inc/cta-bar.php';
