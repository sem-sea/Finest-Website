/*
 * Sticky header state. The header itself sticks with plain CSS
 * (position: sticky); this only toggles a class on <html> once the page has
 * scrolled, so CSS can compact the header and add a hairline shadow.
 * No dependencies, passive listener, one rAF per scroll burst.
 */
(function () {
	var root = document.documentElement;
	var ticking = false;

	function update() {
		ticking = false;
		var y = window.pageYOffset || root.scrollTop || 0;
		root.classList.toggle('is-scrolled', y > 12);
	}

	function onScroll() {
		if (!ticking) {
			ticking = true;
			window.requestAnimationFrame(update);
		}
	}

	window.addEventListener('scroll', onScroll, { passive: true });
	update();
})();
