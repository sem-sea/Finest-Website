<?php
/**
 * Spotlight extras: page transitions, sticky-header state, login link,
 * Optiek Stories topics + starter stories, and the "refresh the home page"
 * tool for sites that already ran the older theme.
 *
 * @package finest-spotlight
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------------
 * Login link ("Inloggen" in the header)
 * ---------------------------------------------------------------------- */

/** Settings > General > Inlog-URL. Empty hides the "Inloggen" menu item. */
function finest_register_login_setting() {
	register_setting(
		'general',
		'finest_login_url',
		array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	add_settings_field(
		'finest_login_url',
		__( 'Inlog-URL (knop "Inloggen")', 'finest-spotlight' ),
		'finest_login_setting_field',
		'general'
	);
}
add_action( 'admin_init', 'finest_register_login_setting' );

function finest_login_setting_field() {
	$value = (string) get_option( 'finest_login_url', '' );
	echo '<input type="url" class="regular-text" id="finest_login_url" name="finest_login_url" value="' . esc_attr( $value ) . '" placeholder="https://app.thefinestimpact.com" autocomplete="off">';
	echo '<p class="description">' . esc_html__( 'Waar de knop "Inloggen" in het menu naartoe gaat. Laat leeg om de knop te verbergen.', 'finest-spotlight' ) . '</p>';
}

/**
 * Point the "Inloggen" menu link at the saved URL; without a URL the item
 * is removed instead of linking to "#".
 *
 * @param string $block_content Rendered navigation link.
 * @param array  $block         Parsed block.
 * @return string
 */
function finest_filter_login_link( $block_content, $block ) {
	$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( false === strpos( $class, 'finest-nav-login' ) ) {
		return $block_content;
	}
	$url = (string) apply_filters( 'finest_login_url', get_option( 'finest_login_url', '' ) );
	if ( '' === $url ) {
		return '';
	}
	return preg_replace( '/href="#"/', 'href="' . esc_url( $url ) . '"', $block_content, 1 );
}
add_filter( 'render_block_core/navigation-link', 'finest_filter_login_link', 10, 2 );

/**
 * The wordmark in header/footer is static HTML with href="/": make it follow
 * the real home URL (sub-folder installs, staging URLs).
 *
 * @param string $block_content Rendered HTML block.
 * @return string
 */
function finest_filter_lockup_home_url( $block_content ) {
	if ( false === strpos( $block_content, 'finest-lockup' ) ) {
		return $block_content;
	}
	return str_replace( 'href="/"', 'href="' . esc_url( home_url( '/' ) ) . '"', $block_content );
}
add_filter( 'render_block_core/html', 'finest_filter_lockup_home_url' );

/* ------------------------------------------------------------------------
 * Page transitions (cross-document View Transitions, progressive)
 * ---------------------------------------------------------------------- */

/**
 * Opt this document in to cross-document view transitions. Browsers without
 * support (Firefox at the time of writing) ignore the at-rule and navigate
 * normally; visitors with "reduce motion" never get the animation. The header
 * gets its own transition name so it stays put while the page cross-fades.
 * Both pages of a navigation must opt in, which they do: every front-end
 * page prints this.
 */
function finest_print_page_transitions() {
	if ( is_admin() || is_customize_preview() || is_embed() || is_feed() ) {
		return;
	}
	$s = finest_motion_settings();
	if ( empty( $s['animations'] ) || empty( $s['pageTransitions'] ) ) {
		return;
	}
	?>
	<style id="finest-page-transitions">
	@media (prefers-reduced-motion: no-preference) {
		@view-transition { navigation: auto; }
		.wp-site-blocks > header.wp-block-template-part { view-transition-name: finest-header; }
		::view-transition-group(root) { animation-duration: 0.45s; }
		::view-transition-old(root) { animation: finest-vt-out 0.28s cubic-bezier(0.4, 0, 1, 1) both; }
		::view-transition-new(root) { animation: finest-vt-in 0.5s cubic-bezier(0.16, 1, 0.3, 1) both; }
		@keyframes finest-vt-out { to { opacity: 0; transform: translateY(-10px); } }
		@keyframes finest-vt-in { from { opacity: 0; transform: translateY(14px); } }
	}
	</style>
	<?php
}
add_action( 'wp_head', 'finest_print_page_transitions', 1 );

/** Sticky header state (shadow + compact height once the page scrolls). */
function finest_enqueue_header_script() {
	$path = FINEST_THEME_DIR . '/assets/js/header.js';
	if ( file_exists( $path ) ) {
		wp_enqueue_script( 'finest-header', FINEST_THEME_URI . '/assets/js/header.js', array(), filemtime( $path ), array( 'strategy' => 'defer' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'finest_enqueue_header_script' );

/* ------------------------------------------------------------------------
 * Optiek Stories: topics and starter stories
 * ---------------------------------------------------------------------- */

function finest_register_story_topics() {
	register_taxonomy(
		'klantverhaal_onderwerp',
		'klantverhaal',
		array(
			'labels'       => array(
				'name'          => __( 'Story-onderwerpen', 'finest-spotlight' ),
				'singular_name' => __( 'Story-onderwerp', 'finest-spotlight' ),
			),
			'hierarchical' => true,
			'public'       => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'optiek-stories' ),
		)
	);
}
add_action( 'init', 'finest_register_story_topics' );

/**
 * Four starter stories, as editable placeholders (title, topic, photo,
 * "volgt binnenkort"). Idempotent: a story that exists is left alone, so an
 * editor's changes or deletions are never fought.
 */
function finest_seed_spotlight_stories() {
	if ( ! post_type_exists( 'klantverhaal' ) ) {
		return;
	}
	$stories = array(
		array( 'zo-breng-je-een-nieuwe-collectie-in-drie-weken-onder-de-aandacht', 'Zo breng je een nieuwe collectie in drie weken onder de aandacht', 'Collecties', 'story-collecties.jpg', '2026-08-04 09:00:00' ),
		array( 'van-losse-posts-naar-een-lijn', 'Van losse posts naar één lijn: hoe een optiekketen zijn marketing ordende', 'Interview', 'story-interview.jpg', '2026-08-03 09:00:00' ),
		array( 'wat-klanten-aan-ai-vragen-als-ze-een-opticien-zoeken', 'Wat klanten aan AI vragen als ze een opticien zoeken', 'Zichtbaarheid', 'story-zichtbaarheid.jpg', '2026-08-02 09:00:00' ),
		array( 'oogzorg-vertellen-zonder-te-verkopen', 'Oogzorg vertellen zonder te verkopen: vijf formules die werken', 'Oogzorg', 'story-oogzorg.jpg', '2026-08-01 09:00:00' ),
	);
	foreach ( $stories as $s ) {
		list( $slug, $title, $topic, $image, $date ) = $s;
		$existing = get_posts( array(
			'name'           => $slug,
			'post_type'      => 'klantverhaal',
			'post_status'    => 'any',
			'posts_per_page' => 1,
		) );
		if ( ! empty( $existing ) ) {
			continue;
		}
		$id = wp_insert_post( array(
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_type'    => 'klantverhaal',
			'post_status'  => 'publish',
			'post_date'    => $date,
			'post_excerpt' => 'Dit verhaal volgt binnenkort.',
			'post_content' => "<!-- wp:paragraph -->\n<p>Dit verhaal volgt binnenkort.</p>\n<!-- /wp:paragraph -->",
		) );
		if ( is_wp_error( $id ) || ! $id ) {
			continue;
		}
		$term_id = finest_ensure_term( $topic, 'klantverhaal_onderwerp' );
		if ( $term_id ) {
			wp_set_post_terms( $id, array( $term_id ), 'klantverhaal_onderwerp' );
		}
		$photo = finest_ensure_photo( $image, 'Optiek Stories: ' . $title, 'spotlight' );
		if ( $photo ) {
			set_post_thumbnail( $id, $photo );
		}
	}
}

/* ------------------------------------------------------------------------
 * Refresh the pages for sites that already used the older theme
 * ---------------------------------------------------------------------- */

/** The page set as front page, or 0. */
function finest_spotlight_home_id() {
	$id = (int) get_option( 'page_on_front' );
	if ( ! $id ) {
		$page = get_page_by_path( 'home' );
		$id   = $page ? (int) $page->ID : 0;
	}
	return $id;
}

/**
 * Pages the theme creates, slug => content callback. 'home' is resolved
 * through the front page setting.
 */
function finest_spotlight_page_map() {
	return array(
		'home'                 => 'finest_home_page_content',
		'over-ons'             => 'finest_over_ons_page_content',
		'diensten'             => 'finest_diensten_page_content',
		'klantverhalen'        => 'finest_klantverhalen_intro_content',
		'nieuws'               => 'finest_nieuws_intro_content',
		'contact'              => 'finest_contact_page_content',
		'algemene-voorwaarden' => 'finest_algemene_voorwaarden_content',
		'privacyverklaring'    => 'finest_privacyverklaring_content',
	);
}

/** Post ID for a slug in the map (0 = page does not exist). */
function finest_spotlight_page_id( $slug ) {
	if ( 'home' === $slug ) {
		return finest_spotlight_home_id();
	}
	$page = get_page_by_path( $slug );
	return $page ? (int) $page->ID : 0;
}

/** True when nobody has edited the page since the theme created it. */
function finest_spotlight_page_unedited( $id ) {
	$post = get_post( $id );
	return $post && abs( strtotime( $post->post_modified_gmt ) - strtotime( $post->post_date_gmt ) ) < 120;
}

/**
 * Rewrite pages with the Spotlight composition. WordPress keeps the previous
 * content as a revision, so every change can be undone in the editor.
 *
 * @param string[] $slugs Slugs to rewrite.
 * @return string[] Slugs that were rewritten.
 */
function finest_spotlight_write_pages( array $slugs ) {
	require_once FINEST_THEME_DIR . '/inc/content-pages.php';
	finest_seed_spotlight_stories();
	$map  = finest_spotlight_page_map();
	$done = array();
	foreach ( $slugs as $slug ) {
		$id = isset( $map[ $slug ] ) ? finest_spotlight_page_id( $slug ) : 0;
		if ( ! $id ) {
			continue;
		}
		$result = wp_update_post( wp_slash( array(
			'ID'           => $id,
			'post_content' => call_user_func( $map[ $slug ] ),
		) ), true );
		if ( ! is_wp_error( $result ) ) {
			$done[] = $slug;
		}
	}
	return $done;
}

/** Kept for the home page notice of v2.0.0 and the patterns. */
function finest_spotlight_refresh_home() {
	$done = finest_spotlight_write_pages( array( 'home' ) );
	if ( $done ) {
		update_option( 'finest_spotlight_home', FINEST_THEME_VERSION );
		return true;
	}
	return false;
}

/**
 * Bring existing pages up to date: pages nobody has edited are rewritten
 * right away; edited ones are remembered in `finest_spotlight_pending` and
 * the admin notice offers the one-click refresh for them.
 */
function finest_spotlight_refresh_all( $force = false ) {
	$pending = array();
	$todo    = array();
	foreach ( array_keys( finest_spotlight_page_map() ) as $slug ) {
		$id = finest_spotlight_page_id( $slug );
		if ( ! $id ) {
			continue;
		}
		if ( $force || finest_spotlight_page_unedited( $id ) ) {
			$todo[] = $slug;
		} else {
			$pending[] = $slug;
		}
	}
	finest_spotlight_write_pages( $todo );
	update_option( 'finest_spotlight_pending', $pending );
	update_option( 'finest_spotlight_pages', FINEST_THEME_VERSION );
	update_option( 'finest_spotlight_home', FINEST_THEME_VERSION );
}

/** After switching to this theme from the older one. */
function finest_spotlight_on_switch() {
	if ( ! get_option( 'finest_content_provisioned' ) ) {
		return; // fresh install: provisioning writes the new pages itself.
	}
	if ( get_option( 'finest_spotlight_pages' ) === FINEST_THEME_VERSION ) {
		return;
	}
	finest_spotlight_refresh_all( false );
}
add_action( 'after_switch_theme', 'finest_spotlight_on_switch', 20 );

/**
 * Sites already on an earlier Spotlight version (2.0.0 only had the new
 * home page): update the sub pages once, on the first admin visit.
 */
function finest_spotlight_maybe_upgrade() {
	if ( ! get_option( 'finest_content_provisioned' ) || get_option( 'finest_spotlight_pages' ) === FINEST_THEME_VERSION ) {
		return;
	}
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	finest_spotlight_refresh_all( false );
}
add_action( 'admin_init', 'finest_spotlight_maybe_upgrade' );

/** Notice with the one-click refresh for pages that were edited and therefore left alone. */
function finest_spotlight_admin_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$pending = (array) get_option( 'finest_spotlight_pending', array() );
	if ( ! $pending ) {
		return;
	}
	$names = array();
	foreach ( $pending as $slug ) {
		$id = finest_spotlight_page_id( $slug );
		if ( $id ) {
			$names[] = get_the_title( $id );
		}
	}
	if ( ! $names ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=finest_refresh_home' ), 'finest_refresh_home' );
	echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'The Finest Impact Spotlight:', 'finest-spotlight' ) . '</strong> ' . esc_html( sprintf( /* translators: %s: page titles */ __( 'deze pagina\'s zijn aangepast en hebben nog de oude opbouw: %s.', 'finest-spotlight' ), implode( ', ', $names ) ) ) . ' <a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Pagina\'s vernieuwen', 'finest-spotlight' ) . '</a> ' . esc_html__( '(de oude versie blijft bewaard als revisie)', 'finest-spotlight' ) . '</p></div>';
}
add_action( 'admin_notices', 'finest_spotlight_admin_notice' );

function finest_spotlight_handle_refresh() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'Geen toegang.', 'finest-spotlight' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'finest_refresh_home' );
	$pending = (array) get_option( 'finest_spotlight_pending', array() );
	finest_spotlight_write_pages( $pending );
	update_option( 'finest_spotlight_pending', array() );
	update_option( 'finest_spotlight_pages', FINEST_THEME_VERSION );
	update_option( 'finest_spotlight_home', FINEST_THEME_VERSION );
	wp_safe_redirect( admin_url( 'edit.php?post_type=page' ) );
	exit;
}
add_action( 'admin_post_finest_refresh_home', 'finest_spotlight_handle_refresh' );

/* ------------------------------------------------------------------------
 * Performance: preload the two self-hosted variable fonts used above the fold
 * ---------------------------------------------------------------------- */
function finest_preload_fonts() {
	if ( is_admin() ) {
		return;
	}
	foreach ( array( 'jost-variable.woff2', 'hanken-grotesk-variable.woff2' ) as $file ) {
		if ( file_exists( FINEST_THEME_DIR . '/assets/fonts/' . $file ) ) {
			echo '<link rel="preload" href="' . esc_url( FINEST_THEME_URI . '/assets/fonts/' . $file ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
		}
	}
}
add_action( 'wp_head', 'finest_preload_fonts', 2 );

/* ------------------------------------------------------------------------
 * Block patterns for the Spotlight look (Patronen > Finest Spotlight)
 * ---------------------------------------------------------------------- */

/**
 * @return array slug => array( title, description, content )
 */
function finest_get_spotlight_patterns() {
	require_once FINEST_THEME_DIR . '/inc/content-pages.php'; // finest_stories_block(), finest_spotlight_hero().
	$hero  = esc_url( get_theme_file_uri( 'assets/img/spotlight/hero-sunglasses.jpg' ) );
	$left  = esc_url( get_theme_file_uri( 'assets/img/spotlight/probleem.jpg' ) );
	$right = esc_url( get_theme_file_uri( 'assets/img/spotlight/wat-is.jpg' ) );

	$primary = '<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contact/">Plan een kennismaking</a></div>
<!-- /wp:button -->';
	$outline = '<!-- wp:button {"className":"is-style-fi-outline"} -->
<div class="wp-block-button is-style-fi-outline"><a class="wp-block-button__link wp-element-button" href="/diensten/">Meer weten</a></div>
<!-- /wp:button -->';

	$split = static function ( $side, $img ) use ( $primary ) {
		$class = 'fi-split fi-split--media-' . $side;
		return '<!-- wp:group {"align":"full","className":"' . $class . '"} -->
<div class="wp-block-group alignfull ' . $class . '">

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"fi-split__media"} -->
<figure class="wp-block-image size-full fi-split__media"><img src="' . $img . '" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"fi-split__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-split__text">

<!-- wp:paragraph {"className":"fi-eyebrow fi-eyebrow--dark"} -->
<p class="fi-eyebrow fi-eyebrow--dark">Onderwerp</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"kop","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-kop-font-size fi-reveal-lines">Kop van deze sectie</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Een of twee alinea\'s tekst naast een foto die de volle hoogte van de sectie vult. Vervang de foto via de blokbalk (Vervangen).</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons">' . $primary . '</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->';
	};

	return array(
		'spotlight-hero'   => array(
			'title'       => __( 'Spotlight: hero (donker, foto rechts)', 'finest-spotlight' ),
			'description' => __( 'Donkere hero met tekst links en een foto met fijne verticale lijnen rechts. Bevat de H1 van de pagina.', 'finest-spotlight' ),
			'content'     => '<!-- wp:group {"align":"full","backgroundColor":"nacht","textColor":"linnen","className":"fi-hero"} -->
<div class="wp-block-group alignfull fi-hero has-linnen-color has-nacht-background-color has-text-color has-background">

<!-- wp:group {"className":"fi-hero__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-hero__text">

<!-- wp:paragraph {"className":"fi-eyebrow"} -->
<p class="fi-eyebrow">Own your spotlight</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"fontSize":"hero","className":"fi-hero__title fi-reveal-lines"} -->
<h1 class="wp-block-heading has-hero-font-size fi-hero__title fi-reveal-lines">Jouw krachtige kop in twee regels.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"fi-hero__sub"} -->
<p class="fi-hero__sub">Eén zin die uitlegt waar het om gaat.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"fi-hero__buttons"} -->
<div class="wp-block-buttons fi-hero__buttons">' . $primary . '

' . $outline . '</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:group -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"fi-hero__media"} -->
<figure class="wp-block-image size-full fi-hero__media"><img src="' . $hero . '" alt=""/></figure>
<!-- /wp:image -->

</div>
<!-- /wp:group -->',
		),
		'spotlight-page-hero'  => array(
			'title'       => __( 'Spotlight: paginakop (donker)', 'finest-spotlight' ),
			'description' => __( 'Donkere kop voor subpagina\'s: label, H1 en een inleidende zin. Voeg een foto toe voor de versie met foto.', 'finest-spotlight' ),
			'content'     => finest_spotlight_hero( 'Onderwerp', 'Kop van de pagina', 'Eén zin die uitlegt waar de pagina over gaat.' ),
		),
		'spotlight-split-left'  => array(
			'title'       => __( 'Spotlight: foto links, tekst rechts', 'finest-spotlight' ),
			'description' => __( 'Gesplitste sectie: foto over de volle hoogte links, tekst rechts. Onder 900px staat de foto boven de tekst.', 'finest-spotlight' ),
			'content'     => $split( 'left', $left ),
		),
		'spotlight-split-right' => array(
			'title'       => __( 'Spotlight: tekst links, foto rechts', 'finest-spotlight' ),
			'description' => __( 'Gesplitste sectie: tekst links, foto over de volle hoogte rechts. Onder 900px staat de foto boven de tekst.', 'finest-spotlight' ),
			'content'     => $split( 'right', $right ),
		),
		'spotlight-close'  => array(
			'title'       => __( 'Spotlight: zwarte afsluiter met logo', 'finest-spotlight' ),
			'description' => __( 'Zwarte band met slotboodschap, knop en het grote logo.', 'finest-spotlight' ),
			'content'     => '<!-- wp:group {"align":"full","backgroundColor":"zwart","textColor":"linnen","className":"fi-close is-style-fi-dark-section"} -->
<div class="wp-block-group alignfull fi-close is-style-fi-dark-section has-linnen-color has-zwart-background-color has-text-color has-background">

<!-- wp:group {"className":"fi-close__text","layout":{"type":"constrained"}} -->
<div class="wp-block-group fi-close__text">

<!-- wp:heading {"level":2,"fontSize":"display","className":"fi-reveal-lines"} -->
<h2 class="wp-block-heading has-display-font-size fi-reveal-lines">Own your spotlight.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Korte slotboodschap in een of twee zinnen.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons">' . $primary . '</div>
<!-- /wp:buttons -->

</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="fi-close__mark" aria-hidden="true"><span class="finest-lockup finest-lockup--big"><span class="ll-the">the</span><span class="ll-finest">finest</span><span class="ll-impact">impact</span></span></div>
<!-- /wp:html -->

</div>
<!-- /wp:group -->',
		),
		'spotlight-stories' => array(
			'title'       => __( 'Spotlight: Optiek Stories (raster van 4)', 'finest-spotlight' ),
			'description' => __( 'De vier nieuwste klantverhalen als kaarten. Werkt automatisch bij nieuwe verhalen.', 'finest-spotlight' ),
			'content'     => finest_stories_block(),
		),
	);
}

function finest_register_spotlight_patterns() {
	foreach ( finest_get_spotlight_patterns() as $slug => $pattern ) {
		register_block_pattern(
			'finest-spotlight/' . $slug,
			array(
				'title'       => $pattern['title'],
				'description' => $pattern['description'],
				'categories'  => array( 'finest-spotlight' ),
				'content'     => $pattern['content'],
			)
		);
	}
}
add_action( 'init', 'finest_register_spotlight_patterns', 21 );
