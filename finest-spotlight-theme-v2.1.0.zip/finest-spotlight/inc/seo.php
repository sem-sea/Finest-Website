<?php
/**
 * Open Graph, Twitter Card and JSON-LD (schema.org) output for every page,
 * so links shared in WhatsApp/Slack/LinkedIn/etc. render a real preview
 * card: title, description, canonical URL and image, instead of a bare
 * link.
 *
 * Deliberately theme-level (no plugin): this is a small, fixed set of tags
 * derived from data WordPress already has (post title/excerpt/thumbnail,
 * site name/tagline), not a configurable SEO suite. If a dedicated SEO
 * plugin (Yoast, Rank Math, SEOPress, AIOSEO) is active it already does
 * this job — and usually more completely — so finest_seo_meta() below
 * bails out rather than emit duplicate/conflicting <meta> tags.
 */

defined( 'ABSPATH' ) || exit;

/**
 * True if a known SEO plugin is active and already handles social meta.
 */
function finest_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' )
		|| defined( 'RANK_MATH_VERSION' )
		|| defined( 'AIOSEO_VERSION' )
		|| defined( 'SEOPRESS_VERSION' )
		|| class_exists( 'RankMath' );
}

/**
 * The theme's own default share image (assets/img/social/og-image-v2.jpg),
 * used whenever the current page has no featured image and no title card of
 * its own. 1200×630 (1.91:1, the size WhatsApp, LinkedIn, Facebook and X all
 * render as a full-width card) with large type so the lockup and tagline stay
 * readable when a chat app shrinks it to a thumbnail. The "-v2" in the name is
 * deliberate: those platforms cache previews per image URL, so a new filename
 * is what makes them show the new image.
 */
function finest_default_og_image() {
	return array(
		'url'    => FINEST_THEME_URI . '/assets/img/social/og-image-v2.jpg',
		'width'  => 1200,
		'height' => 630,
	);
}

/**
 * Resolve the best image for the current request: the post/page's own
 * featured image when one is set, otherwise the theme default above.
 * Always returns url/width/height so the og:image:width/height tags (which
 * materially improve how fast/reliably crawlers render the preview) are
 * never left out.
 */
function finest_seo_image() {
	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		// A title card shipped with the theme (assets/img/social/og-<slug>.jpg,
		// 1200×630) beats the featured image: the cards carry the headline in
		// large type, which stays legible as a small chat thumbnail, whereas the
		// featured photos are square and crop badly. Editor-written posts have no
		// card and fall through to their own featured image.
		$slug = $post_id ? get_post_field( 'post_name', $post_id ) : '';
		if ( $slug && file_exists( FINEST_THEME_DIR . '/assets/img/social/og-' . $slug . '.jpg' ) ) {
			return array(
				'url'    => FINEST_THEME_URI . '/assets/img/social/og-' . $slug . '.jpg',
				'width'  => 1200,
				'height' => 630,
			);
		}
		if ( $post_id && has_post_thumbnail( $post_id ) ) {
			$thumb_id = get_post_thumbnail_id( $post_id );
			$src      = wp_get_attachment_image_src( $thumb_id, 'large' );
			if ( $src ) {
				return array(
					'url'    => $src[0],
					'width'  => (int) $src[1],
					'height' => (int) $src[2],
				);
			}
		}
	}
	return finest_default_og_image();
}

/**
 * Plain-text description for the current request: an explicit excerpt when
 * the editor set one, otherwise the opening words of the content, otherwise
 * the site tagline. Always stripped of tags/shortcodes and capped to a
 * sane length — social platforms truncate anyway, but a hard cap keeps the
 * raw meta content attribute from ballooning on very long posts.
 */
/**
 * First real paragraph(s) of a post, as plain text. Headings, the legal
 * "Concept" notice and shortcodes are skipped, so the fallback description
 * reads like a sentence instead of "eyebrow + title + lead" glued together.
 */
function finest_seo_paragraph_text( $post_content ) {
	$parts = array();
	$walk  = function ( $blocks ) use ( &$walk, &$parts ) {
		foreach ( $blocks as $block ) {
			if ( 'core/paragraph' === $block['blockName'] ) {
				$text = trim( wp_strip_all_tags( $block['innerHTML'] ) );
				if ( strlen( $text ) > 25 && 0 !== strpos( $text, 'Concept:' ) ) {
					$parts[] = $text;
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$walk( $block['innerBlocks'] );
			}
		}
	};
	$walk( parse_blocks( $post_content ) );
	return implode( ' ', array_slice( $parts, 0, 2 ) );
}

function finest_seo_description() {
	if ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			if ( ! empty( $post->post_excerpt ) ) {
				return wp_strip_all_tags( $post->post_excerpt );
			}
			$content = finest_seo_paragraph_text( $post->post_content );
			if ( '' === $content ) {
				$content = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			}
			if ( $content ) {
				return wp_trim_words( $content, 30, '…' );
			}
		}
	}
	if ( is_category() || is_tag() || is_tax() ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$text = trim( wp_strip_all_tags( term_description( $term->term_id, $term->taxonomy ) ) );
			if ( $text ) {
				return $text;
			}
			/* translators: %s: category name */
			return sprintf( __( 'Artikelen in de categorie %s van The Finest News: trends, merken en ontwikkelingen in de optiek.', 'finest-spotlight' ), $term->name );
		}
	}
	return get_bloginfo( 'description' );
}

/**
 * Language of the site's content. All copy shipped with this theme is Dutch, so
 * a site left on the WordPress default (English) would otherwise announce
 * lang="en-US" and og:locale en_US for Dutch text (wrong for screen readers
 * and search engines). Dutch locales and multilingual plugins are left alone.
 */
function finest_site_locale() {
	$locale = (string) get_locale();
	if ( 0 === strpos( $locale, 'nl' ) ) {
		return $locale;
	}
	if ( defined( 'ICL_SITEPRESS_VERSION' ) || defined( 'POLYLANG_VERSION' ) || defined( 'TRP_PLUGIN_VERSION' ) ) {
		return $locale ? $locale : 'nl_NL';
	}
	return 'nl_NL';
}

function finest_force_html_lang( $output ) {
	$locale = finest_site_locale();
	if ( 0 !== strpos( $locale, 'nl' ) ) {
		return $output;
	}
	return preg_replace( '/lang="[^"]*"/', 'lang="' . esc_attr( str_replace( '_', '-', $locale ) ) . '"', $output );
}
add_filter( 'language_attributes', 'finest_force_html_lang' );

/**
 * Page title for the meta tags: deliberately NOT wp_title()/the_title()
 * (those differ per template and already drive the <title> tag via core's
 * 'title-tag' support) — wp_get_document_title() is the one function that
 * returns the exact string core itself put in <title>, so the OG/Twitter
 * title always matches what the browser tab already shows.
 */
function finest_seo_title() {
	return wp_get_document_title();
}

/**
 * The canonical URL for the current request. wp_get_canonical_url()
 * already covers the full page-2-of-an-archive / query-var edge cases
 * core itself handles for <link rel="canonical">; this only adds the
 * front-page and 404 cases it intentionally leaves out.
 */
function finest_seo_canonical() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_singular() ) {
		$canonical = wp_get_canonical_url();
		if ( $canonical ) {
			return $canonical;
		}
	}
	global $wp;
	return home_url( add_query_arg( array(), $wp->request ) );
}

/**
 * Print Open Graph + Twitter Card meta tags. Every dynamic value goes
 * through esc_attr()/esc_url(): this prints straight into HTML attributes
 * built from user-editable post titles/excerpts, so unescaped output here
 * would be a stored XSS hole.
 */
function finest_seo_meta() {
	if ( finest_seo_plugin_active() || is_404() || is_search() ) {
		return;
	}

	$title       = finest_seo_title();
	$description = finest_seo_description();
	$canonical   = finest_seo_canonical();
	$image       = finest_seo_image();
	$site_name   = get_bloginfo( 'name' );
	$locale      = str_replace( '-', '_', finest_site_locale() );
	$type        = is_singular( 'post' ) ? 'article' : 'website';
	?>
	<meta name="description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:type" content="<?php echo esc_attr( $type ); ?>">
	<meta property="og:site_name" content="<?php echo esc_attr( $site_name ); ?>">
	<meta property="og:locale" content="<?php echo esc_attr( $locale ); ?>">
	<meta property="og:url" content="<?php echo esc_url( $canonical ); ?>">
	<meta property="og:title" content="<?php echo esc_attr( $title ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:image" content="<?php echo esc_url( $image['url'] ); ?>">
<?php if ( ! empty( $image['width'] ) && ! empty( $image['height'] ) ) : ?>
	<meta property="og:image:width" content="<?php echo (int) $image['width']; ?>">
	<meta property="og:image:height" content="<?php echo (int) $image['height']; ?>">
<?php endif; ?>
<?php if ( 'article' === $type ) : ?>
<?php
	// Open Graph's article:* properties — what LinkedIn/Facebook and a
	// number of AI crawlers read for recency/attribution, separate from
	// (and not covered by) the generic og:* tags above.
	$post           = get_queried_object();
	$published_time = get_the_date( 'c', $post );
	$modified_time  = get_the_modified_date( 'c', $post );
	$author_name    = get_the_author_meta( 'display_name', $post->post_author );
	$nieuws_terms   = get_the_terms( $post, 'nieuws_categorie' );
	?>
	<meta property="article:published_time" content="<?php echo esc_attr( $published_time ); ?>">
	<meta property="article:modified_time" content="<?php echo esc_attr( $modified_time ); ?>">
<?php if ( $author_name ) : ?>
	<meta property="article:author" content="<?php echo esc_attr( $author_name ); ?>">
<?php endif; ?>
<?php if ( $nieuws_terms && ! is_wp_error( $nieuws_terms ) ) : ?>
	<meta property="article:section" content="<?php echo esc_attr( $nieuws_terms[0]->name ); ?>">
<?php endif; ?>
<?php endif; ?>
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="<?php echo esc_attr( $title ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $description ); ?>">
	<meta name="twitter:image" content="<?php echo esc_url( $image['url'] ); ?>">
	<link rel="canonical" href="<?php echo esc_url( $canonical ); ?>">
	<?php
}
add_action( 'wp_head', 'finest_seo_meta', 1 );

/**
 * JSON-LD ProfessionalService schema, once per page, site-wide (not just
 * the front page): every page is a legitimate entry point from a search
 * result or shared link, and repeating the same organisation markup on
 * every page is the pattern Google's own docs recommend over a single
 * sitewide script tag that only the homepage happens to load.
 *
 * wp_json_encode() is used (not raw json_encode()) specifically because,
 * unlike json_encode(), it leaves forward slashes escaped by default
 * (no JSON_UNESCAPED_SLASHES flag passed): that turns a literal
 * "</script>" inside any string value into "<\/script>", which is what
 * actually prevents a crafted post title/excerpt from closing this
 * <script> tag early and injecting markup after it.
 */
function finest_seo_schema() {
	if ( finest_seo_plugin_active() || is_404() || is_search() ) {
		return;
	}

	// A single Nieuws post is its own, more specific entity (BlogPosting,
	// below) — the sitewide ProfessionalService markup is for every other
	// page, where there's no more specific type to use instead.
	if ( is_singular( 'post' ) ) {
		finest_seo_schema_article();
		return;
	}

	$image = finest_seo_image();

	$schema = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'ProfessionalService',
		'name'        => get_bloginfo( 'name' ),
		'url'         => home_url( '/' ),
		'image'       => $image['url'],
		'description' => get_bloginfo( 'description' ),
		'areaServed'  => 'NL',
		'serviceType' => 'Marketing voor opticiens',
	);

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}
add_action( 'wp_head', 'finest_seo_schema', 2 );

/**
 * BlogPosting JSON-LD for a single Nieuws article — headline, dates,
 * author and publisher in the shape Google's Article rich results and
 * AI answer engines (which lean on this exact markup to extract and
 * attribute a source) both expect. author.name falls back to the site
 * name only if the post's author account has no display name set, which
 * shouldn't happen in practice but must never produce an empty string in
 * the JSON.
 */
function finest_seo_schema_article() {
	$post = get_queried_object();
	if ( ! ( $post instanceof WP_Post ) ) {
		return;
	}

	$image       = finest_seo_image();
	$author_name = get_the_author_meta( 'display_name', $post->post_author );

	$schema = array(
		'@context'         => 'https://schema.org',
		'@type'            => 'BlogPosting',
		'mainEntityOfPage' => array(
			'@type' => 'WebPage',
			'@id'   => get_permalink( $post ),
		),
		'headline'         => get_the_title( $post ),
		'description'      => finest_seo_description(),
		'image'            => $image['url'],
		'datePublished'    => get_the_date( 'c', $post ),
		'dateModified'     => get_the_modified_date( 'c', $post ),
		'author'           => array(
			'@type' => 'Person',
			'name'  => $author_name ? $author_name : get_bloginfo( 'name' ),
		),
		'publisher'        => array(
			'@type' => 'Organization',
			'name'  => get_bloginfo( 'name' ),
			'logo'  => array(
				'@type' => 'ImageObject',
				'url'   => FINEST_THEME_URI . '/assets/img/logo/logo-thefinestimpact1.png',
			),
		),
	);

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}

/**
 * BreadcrumbList JSON-LD for the Nieuws section only (a single article or
 * its category archive) — Home > Nieuws > [categorie] > [artikel]. Scoped
 * deliberately to this one section rather than every template: the rest
 * of the site is a flat one-level structure (Home, Over ons, Diensten,
 * Contact) where a breadcrumb trail has nothing useful to add.
 */
function finest_seo_breadcrumbs_schema() {
	if ( finest_seo_plugin_active() || is_404() || is_search() ) {
		return;
	}
	if ( ! is_singular( 'post' ) && ! is_tax( 'nieuws_categorie' ) ) {
		return;
	}

	$position = 1;
	$items    = array(
		array(
			'@type'    => 'ListItem',
			'position' => $position++,
			'name'     => 'Home',
			'item'     => home_url( '/' ),
		),
	);

	$nieuws_page = get_page_by_path( 'nieuws' );
	if ( $nieuws_page ) {
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $position++,
			'name'     => get_the_title( $nieuws_page ),
			'item'     => get_permalink( $nieuws_page ),
		);
	}

	if ( is_singular( 'post' ) ) {
		$post_id = get_queried_object_id();
		$terms   = get_the_terms( $post_id, 'nieuws_categorie' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term_link = get_term_link( $terms[0] );
			if ( ! is_wp_error( $term_link ) ) {
				$items[] = array(
					'@type'    => 'ListItem',
					'position' => $position++,
					'name'     => $terms[0]->name,
					'item'     => $term_link,
				);
			}
		}
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $position++,
			'name'     => get_the_title( $post_id ),
			'item'     => get_permalink( $post_id ),
		);
	} else {
		// is_tax( 'nieuws_categorie' ): the category archive itself.
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $position++,
			'name'     => single_term_title( '', false ),
			'item'     => finest_seo_canonical(),
		);
	}

	$schema = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $items,
	);

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}
add_action( 'wp_head', 'finest_seo_breadcrumbs_schema', 3 );
