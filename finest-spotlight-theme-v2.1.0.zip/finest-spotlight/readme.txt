=== Finest Spotlight ===
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 2.1.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Block theme for The Finest Impact in the "Spotlight" look: black sticky header, dark hero with a reeded photo, split photo/text sections, ice-blue pill buttons, black closing band and an Optiek Stories grid. Everything is native Gutenberg blocks, so every word and photo can be changed in the editor.

== Installation ==

1. Appearance > Themes > Add New > Upload Theme, choose the zip, install and activate.
2. First activation on a production site: the theme creates the pages (Home, Diensten, Over ons, Klantverhalen, Nieuws, Contact, Algemene voorwaarden, Privacyverklaring), the Nieuws categories, 9 starter articles, 4 starter Optiek Stories, the media-library images and the menu. The teaser page ("Binnenkort online") is switched ON by default on production sites, so visitors never see an unfinished site. Switch it off under Appearance > Teaserpagina when you are ready.
3. Coming from the older theme "The Finest Impact"? Activate this theme: pages nobody has edited (home, Over ons, Diensten, Klantverhalen, Nieuws, Contact, legal pages) are replaced by the Spotlight compositions automatically; edited ones are left alone and a notice offers "Pagina's vernieuwen" (the old version stays available as a revision). Other pages and all settings (WhatsApp, company details, teaser, motion) are kept.
4. Settings > General: WhatsApp-nummer (empty hides the WhatsApp button), Inlog-URL (where "Inloggen" in the menu goes; empty hides the button) and Bedrijfsgegevens (shown on the legal pages; have those reviewed by a lawyer).
5. Contact form: the built-in form works out of the box. With the plugin Contact Form 7 (and Flamingo to keep submissions) the theme creates a ready-made form in the house style.
6. Set Settings > General > Site Language to Nederlands. On first activation (production sites only) the theme switches off "Discourage search engines from indexing this site"; staging/local sites (WP_ENVIRONMENT_TYPE) and later re-activations are left alone.
7. Hero photo: the default is a placeholder portrait. Open the home page in the editor, select the photo in the hero and choose Replace.

== What is in the Spotlight look ==

* Sticky black header with a wordmark, a compact state after scrolling and a full-screen menu below 1024px (44px tap targets, Escape closes it).
* Page transitions: a soft cross-fade between pages via cross-document View Transitions (Chrome, Edge, Safari; other browsers load pages as usual; never for visitors who ask for reduced motion). Appearance > Beweging > Paginaovergangen.
* Smooth scrolling (Lenis) and scroll animations (GSAP) with their own settings page, both off for visitors with "reduce motion".
* Block patterns under Finest Spotlight: hero, photo left/right sections, black closing band, Optiek Stories grid.
* Performance: self-hosted variable fonts (preloaded), no third-party requests, layout shift near zero.
* Accessibility: skip link, visible focus rings, landmarks without duplicates, contrast checked with axe-core on every template (0 violations).

== Security notes ==

* The built-in form checks a nonce, a honeypot, field lengths and rate limits (3 per IP per 10 minutes, 30 per hour site-wide, counted for valid submissions only). Reply-To carries the e-mail address only.
* No third-party scripts, fonts or cookies are loaded by the theme. The WhatsApp button is a plain link that only leaves the site when clicked.
* Behind a proxy or CDN make sure PHP sees the visitor's real IP, otherwise the per-IP limit applies to everyone at once.
* Set security headers (HSTS, X-Content-Type-Options, frame-ancestors, Referrer-Policy) at the host or CDN; a theme should not set them.
* On cached pages the built-in form's nonce can expire; exclude the Contact page from page caching or use Contact Form 7.

== Credits ==

* Fonts: Jost and Hanken Grotesk, SIL Open Font License 1.1 (assets/fonts/OFL.txt).
* Smooth scrolling: Lenis 1.1.14, (c) darkroom.engineering, MIT licence (assets/js/vendor/lenis.min.js).
* Animation: GSAP 3.15.0 with ScrollTrigger and SplitText, (c) GreenSock, used under the GSAP Standard License, https://gsap.com/standard-license (assets/js/vendor/).
* Photographs and logos: provided by The Finest Impact.

== Changelog ==

= 2.1.0 =
* All sub pages in the Spotlight look: Over ons, Diensten (with a black four-step band), Contact, Klantverhalen, Nieuws, the legal pages, search, archive, 404 and single articles now start with the dark page header (with or without a reeded photo) and use the same sections as the home page.
* Existing sites: pages nobody has edited are rewritten once automatically; edited pages are left alone and an admin notice offers "Pagina's vernieuwen" (old versions stay available as revisions).
* New block pattern "Spotlight: paginakop (donker)".

= 2.0.0 =
* New look "Spotlight" (see above). New theme folder finest-spotlight; can be installed next to the old theme.
* New home page composition, Optiek Stories grid with topics (taxonomy "Story-onderwerpen") and 4 starter stories.
* Header and footer rebuilt (no more nested header/footer landmarks).
* Page transitions (View Transitions), sticky-header state, Inlog-URL setting, patterns for the new sections.
* Team section now shows 3 team members; text "vier oprichters" removed from the Over ons description.
* Footer headings are h2 (no heading-level skip); step copy contrast fixed.

== Earlier versions (theme "The Finest Impact") ==

= 1.5.19 =
* Team on the "Over ons" page: Bo Seerden removed from the default content (3 team members now). Existing sites keep their current page content: remove the card in the editor if needed.

= 1.5.18 =
* First activation on a production site now starts with the teaser page ON (Weergave > Teaserpagina), so the unfinished site is never shown; switch it off when you are ready. Not on staging/local, not when already configured, not on later re-activations or updates; opt out with the finest_enable_teaser_on_first_activation filter.

= 1.5.17 =
* Teaser page: full-bleed background photo like the homepage hero (default: the homepage photo; choose another from the media library or switch it off).

= 1.5.16 =
* New: Weergave > Teaserpagina. One switch closes the website for visitors behind a branded "binnenkort online" page (HTTP 503 + Retry-After, noindex, never cached). Logged-in editors and anyone with the secret preview link (?voorbeeld=...) still see the real site; wp-admin, wp-login, the REST API and robots.txt are untouched. A red badge in the admin bar reminds you while it is on.

= 1.5.15 =
* Headings with the line animation no longer lose the tails of g, y, p and j (the animation's clipping mask was cut at the line height).
* New settings page Weergave > Beweging: animations on/off, soft scrolling on/off and its duration, text/photo animations, the sideways Optiek Stories rail and the progress line.

= 1.5.14 =
* News cards (Nieuws, archive, related posts): left-aligned text, same photo height, regular-weight titles, excerpt in related cards.
* Articles end with the "Benieuwd wat dit voor jouw winkel betekent?" contact box; the Nieuws intro text now matches the demo.

= 1.5.13 =
* 11 ready-made sections in the inserter (Patronen > The Finest Impact): hero, page intro, four text + diagram variants, four steps, FAQ, team cards, black call-to-action band, latest news.
* New pages (default template) now let full-width sections (hero, bands) run edge to edge like the seeded pages.
* Animation is now a choice in the block Styles panel (headings: "Animatie: regel voor regel"; images: "Animatie: onthullen"), no CSS class needed.

= 1.5.12 =
* Smooth wheel/trackpad scrolling (Lenis 1.1.14, MIT, bundled in assets/js/vendor/): off for touch, off with reduced motion, paused while the mobile menu is open, anchor links glide, page scrolls natively if the file does not load.
* The menu item of the page you are on is now shown in full strength and bold (also for posts: Nieuws; klantverhalen: Klantverhalen).

= 1.5.11 =
* Content no longer touches the screen edge on mobile (side padding set once in theme.json).
* FAQ accordion now shows its + / minus, hairlines and spacing like the demo.
* Header: wordmark left, menu right with "Inloggen" as a plain link (no oversized button); hero text inset and wraps at 760px; hero full-height on desktop.
* Outlined buttons on black bands (a black button on black was invisible); footer wordmark lockup + full-width hairline; Diensten steps as a 4-column grid; contact intro aligned with its heading.

= 1.5.10 =
* First activation on a production site now turns off "Discourage search engines" (Settings > Reading). Skipped on staging/local/development, when already indexable, via the finest_enable_indexing_on_first_activation filter, and on every later re-activation.
= 1.5.9 =
* Every page now has an editable search description (block editor sidebar > Summary > Excerpt), filled in for the seeded pages; better automatic fallback; description for news categories.
* lang and og:locale are Dutch (nl-NL) for the Dutch copy even if the site language is still English.
= 1.5.8 =
* Compatibility declared from what was actually tested: WordPress 6.8.5 and 7.1.3 (PHP 8.4); PHP 8.1+ checked statically. Requires at least 6.8, tested up to 7.1.
= 1.5.7 =
* Fix: first activation could create every page and post twice when another request (e.g. wp-cron) hit the site during the one-time setup. Setup now runs under a lock.
= 1.5.6 =
* Legal pages filled in (terms: duration, liability, governing law; privacy: legal basis, recipients, retention, rights, complaint route). Company details (legal name, KvK, btw, address) are settings under Settings > General and appear through a shortcode; empty values never show placeholders to visitors.
= 1.5.5 =
* Security hardening and packaging: capability check before first-run provisioning, escaping/sanitising fixes found by the WordPress coding standards security sniffs, licence files, folder name finest-impact.
= 1.5.4 =
* Contact form in the house style (Contact Form 7 + built-in fallback), loaders and states, footer link colour fix.
= 1.5.3 =
* Manon's photo. = 1.5.2 = Karin's photo and sharper team photos. = 1.5.1 = New share images. = 1.5.0 = Contact bar (Neem contact op + WhatsApp).
