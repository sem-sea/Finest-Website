<?php
/**
 * Small, pure helper functions shared across templates and provisioning.
 * Keep logic here instead of duplicating it per template (Fase 4 rule).
 */

defined( 'ABSPATH' ) || exit;

/**
 * "Meer uit The Finest News" at the bottom of templates/single.html: a real
 * core/query block (not hardcoded links), scoped to the className
 * finest-related-posts. On its own, a Query Loop block can't express
 * "posts sharing a taxonomy term with the post currently being viewed" —
 * that's not something the block's own UI (or its stored query attrs) can
 * represent, since it depends on which single post is being rendered. This
 * filter is core's own supported extension point for exactly that case
 * (query_loop_block_query_vars, since WP 5.9): it runs once per Query
 * block render and only touches the block carrying our className, so every
 * other Query Loop in the theme (the Nieuws/Klantverhalen overview grids,
 * the archive/search templates) is completely unaffected.
 *
 * Falls back to "latest posts, excluding this one" when the current post
 * has no nieuws_categorie terms set yet, rather than an empty tax_query
 * that would silently match nothing.
 */
function finest_related_posts_query_vars( $query, $block ) {
	if ( ! is_singular( 'post' ) ) {
		return $query;
	}
	$class = isset( $block->parsed_block['attrs']['className'] ) ? $block->parsed_block['attrs']['className'] : '';
	if ( false === strpos( (string) $class, 'finest-related-posts' ) ) {
		return $query;
	}

	$post_id = get_the_ID();
	$query['post__not_in'] = array( $post_id );

	$terms = get_the_terms( $post_id, 'nieuws_categorie' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		$query['tax_query'] = array(
			array(
				'taxonomy' => 'nieuws_categorie',
				'field'    => 'term_id',
				'terms'    => wp_list_pluck( $terms, 'term_id' ),
			),
		);
	}

	return $query;
}
add_filter( 'query_loop_block_query_vars', 'finest_related_posts_query_vars', 10, 2 );
