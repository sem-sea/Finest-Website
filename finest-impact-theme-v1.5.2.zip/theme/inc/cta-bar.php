<?php
/**
 * Subtle contact bar: "Neem contact op" (contact page) + WhatsApp, so a
 * visitor can pick the channel they prefer.
 *
 * Rendered from wp_footer rather than a template part so it appears on every
 * template (front page, pages, posts, archives) without touching each one,
 * and so the WhatsApp number can come from a setting instead of being baked
 * into block markup. No cookies, no third-party scripts: the WhatsApp button
 * is a plain wa.me link that only leaves the site when it is clicked.
 *
 * Mobile: a slim full-width bar at the bottom (thumb zone) that appears after
 * the first screen and steps aside over the footer. Desktop: the same two
 * buttons as a small floating pair bottom-right. Without JavaScript the bar is
 * simply always visible (the hidden state is only applied under html.js-cta,
 * which the head script sets).
 */

defined( 'ABSPATH' ) || exit;

/** Default WhatsApp number (international format, digits only). */
define( 'FINEST_WHATSAPP_DEFAULT', '31648469924' );

/**
 * Normalise whatever an editor typed into wa.me's format: digits only,
 * international, no leading + or 00. "06 12 34 56 78" becomes 31612345678.
 */
function finest_normalize_whatsapp_number( $raw ) {
	$digits = preg_replace( '/\D+/', '', (string) $raw );
	if ( '' === $digits ) {
		return '';
	}
	if ( 0 === strpos( $digits, '00' ) ) {
		$digits = substr( $digits, 2 );
	} elseif ( 0 === strpos( $digits, '0' ) ) {
		$digits = '31' . substr( $digits, 1 );
	}
	return ( strlen( $digits ) >= 8 && strlen( $digits ) <= 15 ) ? $digits : '';
}

/**
 * Saved setting wins (an empty saved value deliberately hides the WhatsApp
 * button); the filter allows a mu-plugin / wp-config style override.
 */
function finest_whatsapp_number() {
	$stored = get_option( 'finest_whatsapp_number', FINEST_WHATSAPP_DEFAULT );
	return (string) apply_filters( 'finest_whatsapp_number', finest_normalize_whatsapp_number( $stored ) );
}

/** Settings → Algemeen → WhatsApp-nummer. */
function finest_register_whatsapp_setting() {
	register_setting(
		'general',
		'finest_whatsapp_number',
		array(
			'type'              => 'string',
			'default'           => FINEST_WHATSAPP_DEFAULT,
			'sanitize_callback' => 'finest_normalize_whatsapp_number',
		)
	);
	add_settings_field(
		'finest_whatsapp_number',
		__( 'WhatsApp-nummer', 'finest-impact' ),
		'finest_whatsapp_setting_field',
		'general'
	);
}
add_action( 'admin_init', 'finest_register_whatsapp_setting' );

function finest_whatsapp_setting_field() {
	$value = get_option( 'finest_whatsapp_number', FINEST_WHATSAPP_DEFAULT );
	echo '<input type="text" class="regular-text" id="finest_whatsapp_number" name="finest_whatsapp_number" value="' . esc_attr( $value ) . '" inputmode="tel" autocomplete="off" placeholder="+31612345678">';
	echo '<p class="description">' . esc_html__( 'Nummer voor de WhatsApp-knop (internationaal, bijv. +31612345678). Laat leeg om de WhatsApp-knop te verbergen.', 'finest-impact' ) . '</p>';
}

/** The bar is pointless on the contact page itself, and on non-HTML views. */
function finest_cta_bar_should_render() {
	if ( is_admin() || is_feed() || is_embed() || is_404() || is_search() ) {
		return false;
	}
	if ( is_page( 'contact' ) ) {
		return false;
	}
	return (bool) apply_filters( 'finest_show_cta_bar', true );
}

function finest_render_cta_bar() {
	if ( ! finest_cta_bar_should_render() ) {
		return;
	}

	$contact_page = get_page_by_path( 'contact' );
	$contact_url  = $contact_page ? get_permalink( $contact_page ) : home_url( '/contact/' );
	$wa_number    = finest_whatsapp_number();
	$wa_url       = '';
	if ( '' !== $wa_number ) {
		$wa_url = 'https://wa.me/' . $wa_number . '?text=' . rawurlencode( 'Hallo The Finest Impact, ik heb een vraag.' );
	}
	?>
	<aside class="finest-cta-bar" id="finest-cta-bar" aria-label="<?php esc_attr_e( 'Contact opnemen', 'finest-impact' ); ?>">
		<div class="finest-cta-bar__inner">
			<a class="finest-cta-btn finest-cta-btn--primary" href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Neem contact op', 'finest-impact' ); ?></a>
			<?php if ( $wa_url ) : ?>
				<a class="finest-cta-btn finest-cta-btn--wa" href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'WhatsApp (opent in een nieuw tabblad)', 'finest-impact' ); ?>">
					<svg class="finest-cta-btn__icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
					<span>WhatsApp</span>
				</a>
			<?php endif; ?>
		</div>
	</aside>
	<script>
	(function(){
		var bar=document.getElementById('finest-cta-bar');
		if(!bar||!('IntersectionObserver' in window)){return;}
		var root=document.documentElement,past=false,atFooter=false;
		function apply(){
			var show=past&&!atFooter;
			bar.classList.toggle('is-visible',show);
			root.classList.toggle('has-cta-bar',show);
		}
		function onScroll(){
			var p=(window.pageYOffset||root.scrollTop)>window.innerHeight*0.6;
			if(p!==past){past=p;apply();}
		}
		var footer=document.querySelector('.wp-site-blocks > footer');
		if(footer){
			new IntersectionObserver(function(e){atFooter=e[0].isIntersecting;apply();}).observe(footer);
		}
		window.addEventListener('scroll',onScroll,{passive:true});
		onScroll();
	})();
	</script>
	<?php
}
add_action( 'wp_footer', 'finest_render_cta_bar', 5 );
