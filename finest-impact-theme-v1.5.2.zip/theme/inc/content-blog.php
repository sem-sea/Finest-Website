<?php
/**
 * Nine seed articles for The Finest News (nieuws_categorie taxonomy +
 * core `post`), provisioned once on theme activation so the Nieuws
 * overview and every single-post template have real, cross-linked
 * content from the start instead of an empty "no articles yet" state.
 *
 * These are editorial starter content, not reporting: general marketing
 * and industry commentary in the brand's own voice, written to be
 * genuinely useful as a first set of real posts. None of them states a
 * specific statistic, named competitor, dated event or regulatory change
 * as fact — anywhere this topic would normally cite one, the copy stays
 * deliberately general, because none of that could be verified here. A
 * client can publish these as-is, or treat them as a scaffold and replace
 * them via the ordinary wp-admin post editor — finest_ensure_post()
 * (inc/provisioning.php) never touches a post that already exists, so
 * editing or deleting any of these in wp-admin is permanent and safe from
 * being silently re-added on the next activation.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Turn a list of {type, text} blocks into Gutenberg block markup:
 * 'paragraph' (default) or 'quote' (the pull-quote treatment single.html
 * and style.css already style via .wp-block-quote).
 */
function finest_build_article_body( array $blocks ) {
	$out = array();
	foreach ( $blocks as $block ) {
		$text = esc_html( $block['text'] );
		if ( isset( $block['type'] ) && 'quote' === $block['type'] ) {
			$out[] = "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">\n<!-- wp:paragraph -->\n<p>{$text}</p>\n<!-- /wp:paragraph -->\n</blockquote>\n<!-- /wp:quote -->";
		} else {
			$out[] = "<!-- wp:paragraph -->\n<p>{$text}</p>\n<!-- /wp:paragraph -->";
		}
	}
	return implode( "\n\n", $out );
}

/**
 * The nine articles, keyed by a short internal slug used only to wire up
 * $related_map below — never shown to a visitor.
 */
function finest_demo_articles() {
	return array(

		'contentplanning' => array(
			'slug'     => 'contentplanning-verschil-voor-opticiens',
			'title'    => 'Waarom consistente contentplanning hét verschil maakt voor onafhankelijke opticiens',
			'category' => 'Marketing',
			'date'     => '2026-10-02 09:00:00',
			'excerpt'  => 'Niet de ideeën ontbreken, maar het ritme. Hoe een vaste contentplanning opticiens helpt om zichtbaar te blijven — zonder dat het een volgende to-do wordt.',
			'image'    => 'the_finest_impact1.jpg',
			'blocks'   => array(
				array( 'text' => 'Veel opticiens herkennen het probleem: er is genoeg om over te vertellen — nieuwe collecties, acties, verhalen van klanten — maar de content komt er in de praktijk niet uit. Niet omdat de ideeën ontbreken, maar omdat er geen tijd en geen vast ritme is.' ),
				array(
					'type' => 'quote',
					'text' => 'Consistentie wint het uiteindelijk van perfectie. Een opticien die elke week iets deelt, bouwt sneller vertrouwen op dan een opticien die wacht op het perfecte moment.',
				),
				array( 'text' => 'Een contentplanning hoeft niet ingewikkeld te zijn. Het draait om drie vragen: wat wil je deze maand onder de aandacht brengen, wie wil je daarmee bereiken en via welk kanaal landt dat het best? Vanuit die basis ontstaat een ritme dat volhoudbaar is, ook in drukke weken.' ),
				array( 'text' => 'Bij The Finest Impact vertalen we die planning naar concrete content: social posts, nieuwsbrieven en campagnes die aansluiten op wat er in jouw winkel speelt. Niet als eenmalige actie, maar als vast onderdeel van hoe je bedrijf zich laat zien.' ),
				array( 'text' => 'Het resultaat is geen volgend account vol losse posts, maar een merk dat herkenbaar, actueel en aanwezig is — precies op de momenten dat het telt.' ),
			),
		),

		'ai-personalisatie' => array(
			'slug'     => 'ai-gedreven-personalisatie-optiekmarketing',
			'title'    => 'AI-gedreven personalisatie: de volgende stap in optiekmarketing',
			'category' => 'Trends & innovatie',
			'date'     => '2026-09-28 09:00:00',
			'excerpt'  => 'Van aanbevelingen op maat tot slimme campagnes: wat betekent de opmars van AI concreet voor de marketing van een optiekzaak?',
			'image'    => 'fotografie-website2.jpg',
			'blocks'   => array(
				array( 'text' => 'De term "personalisatie" wordt al jaren gebruikt in marketing, maar in de optiek bleef het lang beperkt tot een aanhef met de juiste voornaam in een nieuwsbrief. Dat verandert. Met slimmere tools kun je nu daadwerkelijk aansluiten op waar een klant in zijn aankoopreis staat.' ),
				array(
					'type' => 'quote',
					'text' => 'Personalisatie is geen trucje om meer te verkopen. Het is simpelweg relevanter zijn voor de klant die al interesse heeft getoond.',
				),
				array( 'text' => 'Denk aan een klant die een maand geleden een nieuwe zonnebril paste, maar niet kocht. In plaats van een algemene actie-mail kun je die klant gericht herinneren aan precies dat model, of aan een vergelijkbare collectie. Klein verschil, groot effect op betrokkenheid.' ),
				array( 'text' => 'Dat vraagt wel om de juiste basis: klantdata die op orde is, en systemen die met elkaar praten. Zonder die basis blijft "AI-personalisatie" een containerbegrip zonder resultaat.' ),
				array( 'text' => 'Bij The Finest Impact zetten we die technologie in waar het daadwerkelijk verschil maakt — niet als doel op zich, maar als manier om sneller te doen wat een goede verkoper aan de balie ook zou doen: aansluiten op wat de klant nodig heeft.' ),
			),
		),

		'merkverhaal' => array(
			'slug'     => 'merkverhaal-grote-optiekmerken',
			'title'    => 'Hoe grote merken hun verhaal inzetten — en wat je daarvan kunt leren',
			'category' => 'Brands & People',
			'date'     => '2026-09-21 09:00:00',
			'excerpt'  => 'Groot of klein: een helder merkverhaal werkt. Drie lessen uit de manier waarop bekende optiekmerken zich positioneren.',
			'image'    => 'the_finest_impact1.jpg',
			'blocks'   => array(
				array( 'text' => 'Grote optiekmerken hebben vaak grotere budgetten, maar niet per definitie een beter verhaal. Wat opvalt bij merken die wél blijven hangen, is dat ze één ding heel consequent doen: ze vertellen steeds dezelfde kernboodschap, in allerlei vormen.' ),
				array( 'text' => 'De eerste les is herkenbaarheid boven volledigheid. Een merk dat op elk kanaal iets anders benadrukt, blijft vager dan een merk dat op elk kanaal dezelfde paar dingen herhaalt — net zo lang tot het vanzelfsprekend aanvoelt.' ),
				array(
					'type' => 'quote',
					'text' => 'Een sterk merkverhaal is niet het verhaal met de meeste woorden. Het is het verhaal dat het makkelijkst is om in één zin door te vertellen.',
				),
				array( 'text' => 'De tweede les is dat mensen verkopen, niet producten alleen. De merken die het beste werken, laten hun medewerkers, hun opticiens en hun klanten zien — niet alleen de collectie.' ),
				array( 'text' => 'De derde les is geduld. Een herkenbaar merk ontstaat niet in één campagne, maar in de optelsom van honderden kleine, consistente momenten. Dat is precies waar onafhankelijke opticiens, met hun persoonlijke karakter, van nature een voorsprong hebben op grote ketens — als ze dat verhaal maar laten zien.' ),
			),
		),

		'vakbeurs' => array(
			'slug'     => 'terugblik-optiekvakbeurs',
			'title'    => 'Terugblik: wat opticiens meenamen van de laatste optiekvakbeurs',
			'category' => 'Events & fairs',
			'date'     => '2026-09-15 09:00:00',
			'excerpt'  => 'Nieuwe collecties, nieuwe technologie en vooral veel gesprekken over marketing. Een overzicht van wat er speelde.',
			'image'    => 'fotografie-website2.jpg',
			'blocks'   => array(
				array( 'text' => 'Een vakbeurs is voor veel opticiens vooral een moment om nieuwe collecties te bekijken en leveranciers te spreken. Maar de gesprekken gaan steeds vaker net zo goed over marketing: hoe val je op in een winkelstraat die er steeds meer op elkaar begint te lijken?' ),
				array( 'text' => 'Een terugkerend thema is de rol van social media als verlengstuk van de winkel. Opticiens die goed scoren, laten niet alleen het eindproduct zien, maar ook het proces: het advies, de styling, het moment van passen.' ),
				array(
					'type' => 'quote',
					'text' => 'De winkelvloer en het scherm zijn geen twee aparte werelden meer. Ze zijn allebei onderdeel van hetzelfde klantcontact.',
				),
				array( 'text' => 'Een ander thema is technologie die klantcontact ondersteunt in plaats van vervangt: slimme tools voor advies op maat, niet als gimmick, maar als manier om sneller tot een beter advies te komen.' ),
				array( 'text' => 'De rode draad is steeds dezelfde: de basisprincipes van goed vakmanschap en persoonlijk advies veranderen niet. Wat verandert, is hoeveel kanalen een opticien tegelijk moet bedienen om dat vakmanschap zichtbaar te maken.' ),
			),
		),

		'winkelpodium' => array(
			'slug'     => 'winkel-als-podium-interieur',
			'title'    => 'De winkel als podium: vijf manieren waarop opticiens opvallen met hun interieur',
			'category' => 'Retail & store concepts',
			'date'     => '2026-09-09 09:00:00',
			'excerpt'  => 'Een winkel is meer dan een verkooppunt. Vijf voorbeelden van hoe optiekzaken van hun ruimte een merkervaring maken.',
			'image'    => 'the_finest_impact1.jpg',
			'blocks'   => array(
				array( 'text' => 'Een optiekwinkel is méér dan een verkooppunt — het is vaak de plek waar een klant voor het eerst echt kennismaakt met een merk. Opticiens die daar bewust mee omgaan, zien hun winkel niet als showroom, maar als podium.' ),
				array( 'text' => 'Eén manier is door de styling van de winkel mee te laten bewegen met wat er op social media gebeurt: dezelfde sfeer, dezelfde kleuren, dezelfde verhalen, zodat een klant die online al kennismaakte zich in de winkel meteen herkend voelt.' ),
				array( 'text' => 'Een tweede manier is ruimte maken voor beleving in plaats van alleen aanbod: een hoek voor rust bij het kiezen, goede verlichting die ook op foto\'s goed staat, een plek waar een klant graag een moment blijft.' ),
				array(
					'type' => 'quote',
					'text' => 'De beste winkels voelen niet aan als een verkoopvloer. Ze voelen aan als een plek waar je, toevallig, ook een bril kunt kopen.',
				),
				array( 'text' => 'Een derde manier is simpelweg laten zien wie er werkt: gezichten, namen, verhalen. Klanten kopen uiteindelijk niet alleen een montuur, maar vertrouwen in het advies van de persoon die ze tegenover zich hebben.' ),
			),
		),

		'zichttesten' => array(
			'slug'     => 'online-zichttesten-communicatie',
			'title'    => 'Online zichttesten in de etalage: wat vraagt dit van jouw communicatie?',
			'category' => 'Industrie news',
			'date'     => '2026-09-02 09:00:00',
			'excerpt'  => 'Online zichttesten winnen terrein. Wat betekent die verschuiving voor hoe jij als opticien je eigen expertise communiceert?',
			'image'    => 'fotografie-website2.jpg',
			'blocks'   => array(
				array( 'text' => 'Online zichttesten en verkoop van brillen op afstand winnen terrein, en dat roept bij veel opticiens een logische vraag op: wat betekent dat voor mijn eigen rol en voor hoe ik mezelf communiceer?' ),
				array( 'text' => 'Het makkelijke antwoord is "concurrentie". Het interessantere antwoord is dat het juist de waarde van persoonlijk advies scherper maakt. Een online test kan een eerste indicatie geven, maar vervangt geen opticien die de context van een klant kent.' ),
				array(
					'type' => 'quote',
					'text' => 'Hoe meer online mogelijk wordt, hoe duidelijker het verschil wordt tussen een snelle test en een goed advies.',
				),
				array( 'text' => 'Dat is precies het verhaal dat je zelf actief mag vertellen: niet in verdediging, maar in positionering. Leg uit wat er bij een goed oogonderzoek en een passend advies komt dat een online test niet kan bieden.' ),
				array( 'text' => 'Wie dat verhaal consequent communiceert — op de website, in de winkel en op social media — maakt van een ontwikkeling die als dreiging voelt, juist een aanleiding om de eigen expertise opnieuw voor het voetlicht te brengen.' ),
			),
		),

		'duitse-markt' => array(
			'slug'     => 'leren-van-duitse-optiekmarkt',
			'title'    => 'Wat Nederlandse opticiens kunnen leren van de Duitse optiekmarkt',
			'category' => 'Internationaal news',
			'date'     => '2026-08-26 09:00:00',
			'excerpt'  => 'Grotere ketens, andere verhoudingen — en toch herkenbare uitdagingen. Een blik over de grens.',
			'image'    => 'the_finest_impact1.jpg',
			'blocks'   => array(
				array( 'text' => 'De Duitse optiekmarkt is groter, consolideert sneller en wordt sterker gedomineerd door ketens dan de Nederlandse. Toch herkennen veel Nederlandse opticiens de uitdagingen die er spelen: prijsdruk, online concurrentie en de vraag hoe je als zelfstandige blijft opvallen.' ),
				array( 'text' => 'Wat opvalt, is dat de onafhankelijke optiekzaken die daar wél standhouden, zich niet proberen te meten met de schaal van de ketens, maar juist hun eigen rol aanscherpen: specialisatie, persoonlijk advies en een duidelijke niche.' ),
				array(
					'type' => 'quote',
					'text' => 'Je wint niet van een keten door groter te worden. Je wint door duidelijker te zijn in waar je wél en niet voor staat.',
				),
				array( 'text' => 'Een andere les is de manier waarop lokale aanwezigheid wordt ingezet: niet als nostalgisch verkoopargument, maar als concreet voordeel — snelheid, bereikbaarheid, een vast gezicht dat je kent.' ),
				array( 'text' => 'De Nederlandse markt is anders, maar de onderliggende vraag is hetzelfde: hoe blijf je relevant als zelfstandige opticien in een markt die steeds verder schaalt? Het antwoord ligt zelden bij harder concurreren op prijs, en vaker bij scherper kiezen waar je voor staat.' ),
			),
		),

		'emailmarketing' => array(
			'slug'     => 'emailmarketing-campagnes-die-werken',
			'title'    => 'E-mailmarketing voor opticiens: drie campagnes die wél geopend worden',
			'category' => 'Marketing',
			'date'     => '2026-08-19 09:00:00',
			'excerpt'  => 'Een nieuwsbrief versturen is niet het probleem. Hem geopend én gelezen krijgen wel. Drie aanpakken die werken.',
			'image'    => 'fotografie-website2.jpg',
			'blocks'   => array(
				array( 'text' => 'Een nieuwsbrief versturen kost weinig moeite. Een nieuwsbrief die ook daadwerkelijk geopend en gelezen wordt, is een ander verhaal. Drie aanpakken die in de praktijk goed blijven werken, hebben één ding gemeen: ze gaan niet alleen over de zender, maar over de ontvanger.' ),
				array( 'text' => 'De eerste aanpak is de seizoensgebonden herinnering: niet "wij hebben een actie", maar "dit is het moment om je zonnebril te checken voordat de zomer begint". Relevantie op het juiste moment werkt beter dan frequentie.' ),
				array(
					'type' => 'quote',
					'text' => 'De beste e-mail is niet de e-mail met de beste aanbieding. Het is de e-mail die precies op tijd in de inbox valt.',
				),
				array( 'text' => 'De tweede aanpak is de persoonlijke follow-up: een korte, oprechte e-mail na een afspraak of aankoop, zonder verkoopdoel, die alleen vraagt of alles naar wens is. Dat soort mails wordt opvallend vaak beantwoord.' ),
				array( 'text' => 'De derde aanpak is het delen van kennis in plaats van aanbiedingen: een korte uitleg over hoe je een montuur het beste onderhoudt, of wat er verandert in brillenglazen. Dat bouwt vertrouwen op, ook als er niets te koop wordt aangeboden.' ),
			),
		),

		'socialmedia2026' => array(
			'slug'     => 'social-media-2026-lokale-opticiens',
			'title'    => 'Social media in 2026: wat werkt nog voor lokale opticiens?',
			'category' => 'Trends & innovatie',
			'date'     => '2026-08-12 09:00:00',
			'excerpt'  => 'Minder bereik, meer concurrentie. Wat verschuift er in de aanpak van optiekzaken die nog wél resultaat zien?',
			'image'    => 'the_finest_impact1.jpg',
			'blocks'   => array(
				array( 'text' => 'Social media voor lokale ondernemers is de afgelopen jaren veranderd van "leuk om te doen" naar "noodzakelijk, maar lastiger dan ooit". Organisch bereik daalt, en de concurrentie om aandacht groeit. Toch zijn er optiekzaken die er nog steeds resultaat uit halen.' ),
				array( 'text' => 'Wat zij gemeen hebben, is dat ze zijn gestopt met posten om te posten. In plaats daarvan kiezen ze een beperkt aantal terugkerende contentvormen — een klantverhaal, een stylingtip, een blik achter de schermen — en herhalen die consequent.' ),
				array(
					'type' => 'quote',
					'text' => 'Minder bereik betekent niet minder kans. Het betekent dat elke post het moet verdienen om gezien te worden.',
				),
				array( 'text' => 'Een tweede verschuiving is de rol van de medewerkers zelf: content die door een echt gezicht wordt gebracht, presteert in de praktijk vaak beter dan content vanuit een anoniem merkaccount.' ),
				array( 'text' => 'De zaken die nog wél resultaat zien, behandelen social media niet als los kanaal, maar als onderdeel van een bredere, consistente aanwezigheid — precies het principe waar The Finest Impact op is gebouwd.' ),
			),
		),

	);
}

/**
 * Who links to whom. Deliberately curated rather than random or
 * "every post links to every other post": each article points to two
 * genuinely related ones, so the link graph reads as topical clusters
 * (contentplanning ↔ e-mail ↔ social media; merkverhaal ↔ winkelpodium;
 * zichttesten ↔ de Duitse markt) rather than decoration.
 */
function finest_demo_article_related_map() {
	return array(
		'contentplanning'   => array( 'emailmarketing', 'socialmedia2026' ),
		'ai-personalisatie' => array( 'contentplanning', 'socialmedia2026' ),
		'merkverhaal'       => array( 'winkelpodium', 'contentplanning' ),
		'vakbeurs'          => array( 'merkverhaal', 'winkelpodium' ),
		'winkelpodium'      => array( 'merkverhaal', 'socialmedia2026' ),
		'zichttesten'       => array( 'contentplanning', 'duitse-markt' ),
		'duitse-markt'      => array( 'zichttesten', 'winkelpodium' ),
		'emailmarketing'    => array( 'contentplanning', 'ai-personalisatie' ),
		'socialmedia2026'   => array( 'ai-personalisatie', 'emailmarketing' ),
	);
}

/**
 * Create the nine articles (idempotent: finest_ensure_post() returns the
 * existing ID on every run after the first) and, once all nine exist,
 * append each one's "Lees ook" interlinks in a second pass.
 */
function finest_seed_demo_articles() {
	$articles = finest_demo_articles();

	$ids = array();
	foreach ( $articles as $key => $article ) {
		$id = finest_ensure_post( array(
			'slug'     => $article['slug'],
			'title'    => $article['title'],
			'content'  => finest_build_article_body( $article['blocks'] ),
			'excerpt'  => $article['excerpt'],
			'date'     => $article['date'],
			'category' => $article['category'],
			'image'    => $article['image'],
		) );
		if ( $id ) {
			$ids[ $key ] = $id;
		}
	}

	foreach ( finest_demo_article_related_map() as $key => $related_keys ) {
		if ( empty( $ids[ $key ] ) ) {
			continue;
		}
		$related = array();
		foreach ( $related_keys as $related_key ) {
			if ( ! empty( $ids[ $related_key ] ) ) {
				$related[] = array(
					'id'    => $ids[ $related_key ],
					'title' => $articles[ $related_key ]['title'],
				);
			}
		}
		finest_append_read_also( $ids[ $key ], $related );
	}
}
